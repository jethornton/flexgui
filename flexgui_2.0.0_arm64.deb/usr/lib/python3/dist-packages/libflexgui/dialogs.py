import os, shutil, subprocess

from PyQt6.QtWidgets import QDialog, QDialogButtonBox, QVBoxLayout, QLabel
from PyQt6.QtWidgets import QMessageBox, QPlainTextEdit, QComboBox
from PyQt6.QtWidgets import QSpinBox, QDoubleSpinBox
from PyQt6.QtGui import QPixmap, QTextCursor
from PyQt6.QtCore import Qt, QTimer

import linuxcnc as emc
import hal

from libflexgui import numpad
from libflexgui import gcode_pad
from libflexgui import keyboard_pad
from libflexgui import tool_change
from libflexgui import touchoff
from libflexgui import tool_touchoff
from libflexgui import utilities
from libflexgui import search

def spinbox_numbers(parent, obj):
	if obj.isEnabled():
		dialog = numpad.number_pad(parent.lib_path)
		dialog.numbers_le.setText(f'{obj.value()}')

		with open(parent.popup_qss,'r') as fh:
			dialog.setStyleSheet(fh.read())

		if parent.settings.contains(f'POPUP/{obj.objectName()}_pos'):
			dialog.move(parent.settings.value(f'POPUP/{obj.objectName()}_pos'))
		if parent.settings.contains(f'POPUP/{obj.objectName()}_size'):
			dialog.resize(parent.settings.value(f'POPUP/{obj.objectName()}_size'))

		result = dialog.exec()

		if result and utilities.is_number(dialog.retval()):
			if isinstance(obj, QSpinBox): # return an int
				obj.setValue(utilities.string_to_int(dialog.retval()))
			elif isinstance(obj, QDoubleSpinBox): # return a float
				obj.setValue(utilities.string_to_float(dialog.retval()))

		if dialog.exit_pos is not None: # save last position
			parent.settings.setValue(f'POPUP/{obj.objectName()}_pos', dialog.exit_pos)
		if dialog.exit_size is not None: # save last size
			parent.settings.setValue(f'POPUP/{obj.objectName()}_size', dialog.exit_size)

def numbers(parent, obj): # obj is the qlineedit that is to receive
	if obj.isEnabled():
		dialog = numpad.number_pad(parent.lib_path)
		dialog.numbers_le.setText(obj.text())

		with open(parent.popup_qss,'r') as fh:
			dialog.setStyleSheet(fh.read())

		if parent.settings.contains(f'POPUP/{obj.objectName()}_pos'):
			dialog.move(parent.settings.value(f'POPUP/{obj.objectName()}_pos'))
		if parent.settings.contains(f'POPUP/{obj.objectName()}_size'):
			dialog.resize(parent.settings.value(f'POPUP/{obj.objectName()}_size'))

		result = dialog.exec()

		if result and utilities.is_number(dialog.retval()):
			obj.setText(dialog.retval())

		if dialog.exit_pos is not None: # save last position
			parent.settings.setValue(f'POPUP/{obj.objectName()}_pos', dialog.exit_pos)
		if dialog.exit_size is not None: # save last size
			parent.settings.setValue(f'POPUP/{obj.objectName()}_size', dialog.exit_size)

def gcode(parent, obj):
	if obj.isEnabled():
		dialog = gcode_pad.gcode_pad(parent.lib_path)
		dialog.gcode_le.setText(obj.text())

		with open(parent.popup_qss,'r') as fh:
			dialog.setStyleSheet(fh.read())

		if parent.settings.contains(f'POPUP/{obj.objectName()}_pos'):
			dialog.move(parent.settings.value(f'POPUP/{obj.objectName()}_pos'))
		if parent.settings.contains(f'POPUP/{obj.objectName()}_size'):
			dialog.resize(parent.settings.value(f'POPUP/{obj.objectName()}_size'))

		result = dialog.exec()
		if result:
			obj.setText(dialog.retval())

		if dialog.exit_pos is not None: # save last position
			parent.settings.setValue(f'POPUP/{obj.objectName()}_pos', dialog.exit_pos)
		if dialog.exit_size is not None: # save last size
			parent.settings.setValue(f'POPUP/{obj.objectName()}_size', dialog.exit_size)

def keyboard(parent, obj):
	if obj.isEnabled():
		dialog = keyboard_pad.keyboard_pad(parent.lib_path)
		dialog.keyboard_le.setText(obj.text())

		with open(parent.popup_qss,'r') as fh:
			dialog.setStyleSheet(fh.read())

		# set size and position
		if parent.settings.contains(f'POPUP/{obj.objectName()}_pos'):
			dialog.move(parent.settings.value(f'POPUP/{obj.objectName()}_pos'))
		if parent.settings.contains(f'POPUP/{obj.objectName()}_size'):
			dialog.resize(parent.settings.value(f'POPUP/{obj.objectName()}_size'))

		result = dialog.exec()
		if result:
			obj.setText(dialog.retval())

		if dialog.exit_pos is not None: # save last position
			parent.settings.setValue(f'POPUP/{obj.objectName()}_pos', dialog.exit_pos)
		if dialog.exit_size is not None: # save last size
			parent.settings.setValue(f'POPUP/{obj.objectName()}_size', dialog.exit_size)

def manual_tool_change(parent):
	dialog = tool_change.app(parent)
	def dia_acc(pin):
		current_value = pin.get()
		#print(current_value)
		if current_value:
			dialog.accept()

	# Connect the 'value-changed' signal
	handler_id = parent.pin_watcher.connect('value-changed', dia_acc)

	if parent.theme: # use the theme
		stylesheet = os.path.join(parent.lib_path, f'{parent.theme}.qss')
	elif parent.qss_file: # use the configuration qss file
		stylesheet = os.path.join(parent.config_dir, f'{parent.qss_file}')
	else:
		stylesheet = os.path.join(parent.lib_path, 'touch.qss')
	with open(stylesheet,'r') as s:
		dialog.setStyleSheet(s.read())

	if parent.settings.contains('POPUP/manual_tool_change_pos'):
		dialog.move(parent.settings.value('POPUP/manual_tool_change_pos'))
	if parent.settings.contains('POPUP/manual_tool_change_size'):
		dialog.resize(parent.settings.value('POPUP/manual_tool_change_size'))

	result = dialog.exec()

	# disconnect the value-changed signal
	parent.pin_watcher.disconnect(handler_id)

	if result:
		hal.set_p('iocontrol.0.tool-changed','true')
	else:
		parent.command.abort()
		parent.command.wait_complete()

	if dialog.exit_pos is not None: # save last position
		parent.settings.setValue('POPUP/manual_tool_change_pos', dialog.exit_pos)
	if dialog.exit_size is not None: # save last size
		parent.settings.setValue('POPUP/manual_tool_change_size', dialog.exit_size)

def touchoff_selected(parent):
	dialog = touchoff.app(parent)

	if parent.theme: # use the theme
		stylesheet = os.path.join(parent.lib_path, f'{parent.theme}.qss')
	elif parent.qss_file: # use the configuration qss file
		stylesheet = os.path.join(parent.config_dir, f'{parent.qss_file}')
	else:
		stylesheet = os.path.join(parent.lib_path, 'touch.qss')
	with open(stylesheet,'r') as s:
		dialog.setStyleSheet(s.read())

	if parent.settings.contains('POPUP/touchoff_selected_pos'):
		dialog.move(parent.settings.value('POPUP/touchoff_selected_pos'))
	if parent.settings.contains('POPUP/touchoff_selected_size'):
		dialog.resize(parent.settings.value('POPUP/touchoff_selected_size'))

	axis = parent.axes_group.checkedButton().text()
	dialog.axis_lb.setText(f'Axis: {axis}')
	result = dialog.exec()

	if result == QDialog.DialogCode.Accepted:
		offset = dialog.coordinate_le.text()
		if not utilities.is_number(offset): # verified
			title = 'Operator Error!'
			msg = (f'{offset} is not a number.')
			error_msg_ok(parent, title, msg)
			return
		cs = dialog.coordinate_systems_cb.currentData()
		command = f'G10 L20 P{cs} {axis}{offset}'
		if utilities.ok_for_mdi(parent):
			parent.command.mode(emc.MODE_MDI)
			parent.command.wait_complete() # wait until mode switch executed
			parent.command.mdi(command)

	if dialog.exit_pos is not None: # save last position
		parent.settings.setValue('POPUP/touchoff_selected_pos', dialog.exit_pos)
	if dialog.exit_size is not None: # save last size
		parent.settings.setValue('POPUP/touchoff_selected_size', dialog.exit_size)

def tool_touchoff_selected(parent):
	# this is only enabled when a tool is in the spindle
	dialog = tool_touchoff.app(parent)

	if parent.theme: # use the theme
		stylesheet = os.path.join(parent.lib_path, f'{parent.theme}.qss')
	elif parent.qss_file: # use the configuration qss file
		stylesheet = os.path.join(parent.config_dir, f'{parent.qss_file}')
	else:
		stylesheet = os.path.join(parent.lib_path, 'touch.qss')
	with open(stylesheet,'r') as s:
		dialog.setStyleSheet(s.read())

	if parent.settings.contains('POPUP/tool_touchoff_selected_pos'):
		dialog.move(parent.settings.value('POPUP/tool_touchoff_selected_pos'))
	if parent.settings.contains('POPUP/tool_touchoff_selected_size'):
		dialog.resize(parent.settings.value('POPUP/tool_touchoff_selected_size'))

	axis = parent.axes_group.checkedButton().text()
	tool = parent.status.tool_in_spindle
	dialog.axis_lb.setText(f'Axis: {axis}')
	result = dialog.exec()
	if result == QDialog.DialogCode.Accepted:
		offset = dialog.offset_le.text()
		if not utilities.is_number(offset): # verified
			title = 'Operator Error!'
			msg = (f'{offset} is not a number.')
			error_msg_ok(parent, title, msg)
			return
		command = f'G10 L11 P{tool} {axis}{offset}'
		if utilities.ok_for_mdi(parent):
			parent.command.mode(emc.MODE_MDI)
			parent.command.wait_complete() # wait until mode switch executed
			parent.command.mdi(command)

	if dialog.exit_pos is not None: # save last position
		parent.settings.setValue('POPUP/tool_touchoff_selected_pos', dialog.exit_pos)
	if dialog.exit_size is not None: # save last size
		parent.settings.setValue('POPUP/tool_touchoff_selected_size', dialog.exit_size)

def find(parent):
	sr = search.FindDialog(parent)
	result = sr.exec()

def select_editor(parent, nc_file):
	dialog = QDialog(parent)
	dialog.setMinimumSize(300, 300)
	dialog.setWindowTitle('Select Editor')

	layout = QVBoxLayout(dialog)

	message = QLabel('The [DISPLAY] EDITOR in the ini file is\n'
	'not installed or no Text Editor was specified.\n'
	'Select the Editor you want to use or Cancel.')
	message.setObjectName('msg_lb')
	layout.addWidget(message)

	editors = QComboBox()
	editors.setObjectName('editors')
	editors.addItem('Select', False)

	editor_dict = {'Gedit':'gedit', 'Geany':'geany', 'Pyroom':'pyroom',
		'Pluma':'pluma', 'Scite':'scite', 'Kwrite':'kwrite',
		'Kate':'kate', 'Mousepad':'mousepad', 'Jedit':'jedit',
		'XED':'xed'}

	editor_list = []
	for key, value in editor_dict.items(): # get a list of installed editors
		if shutil.which(value) is not None:
			editors.addItem(key, value)

	layout.addWidget(editors)

	layout.addStretch(1)

	buttons = (QDialogButtonBox.StandardButton.Ok |
	QDialogButtonBox.StandardButton.Cancel)
	button_box = QDialogButtonBox(buttons)

	# Connect signals to Dialog's built-in accept/reject slots
	button_box.accepted.connect(dialog.accept)
	button_box.rejected.connect(dialog.reject)

	layout.addWidget(button_box)

	with open(os.path.join(parent.lib_path, 'messagebox.qss'),'r') as fh:
		dialog.setStyleSheet(fh.read())

	returnValue = dialog.exec()

	if returnValue == QDialog.DialogCode.Accepted:
		editor = editors.currentData()

		# Guard clause: Check if the user left it on the default 'Select' option
		if editor is False:
			print("User clicked OK but did not choose a valid editor.")
			return None

		print(f"User accepted. Selected command: {editor}")
		if shutil.which(editor) is not None:
			subprocess.Popen([editor, nc_file])

	else:
		print('User cancelled the dialog.')
		return None

def status_warning(parent, msg):
	parent.statusbar.setStyleSheet('''
		QStatusBar {background-color: red; color: white;}''')

	# Show the alert message
	parent.statusbar.showMessage(f"⚠️ {msg}")

	# Set a timer to clear the message and reset colors after 5000 milliseconds (5 seconds)
	QTimer.singleShot(5000, lambda: reset_status_bar(parent))

def reset_status_bar(parent):
	parent.statusbar.clearMessage()
	parent.statusbar.setStyleSheet('')  # Reset to default stylesheet

def error_msg_ok(parent, title, msg, info=None): # messagebox.qss added
	# dialogs.error_msg_ok(parent, title, msg, info)
	msg_box = QMessageBox(parent)
	msg_box.setIcon(QMessageBox.Icon.Warning)
	msg_box.setWindowTitle(title)
	msg_box.setText(msg)
	if info is not None:
		msg_box.setInformativeText(info)
	msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)

	with open(os.path.join(parent.lib_path, 'messagebox.qss'),'r') as fh:
		msg_box.setStyleSheet(fh.read())

	returnValue = msg_box.exec()
	if returnValue == QMessageBox.StandardButton.Ok:
		return True
	else:
		return False

def warn_msg_yes_no(parent, title, msg, info=None): # messagebox.qss added
	# dialogs.warn_msg_yes_no(parent, title, msg, info)
	#print('warn_msg_yes_no')
	msg_box = QMessageBox(parent)
	msg_box.setIcon(QMessageBox.Icon.Warning)
	msg_box.setWindowTitle(title)
	msg_box.setText(msg)
	if info is not None:
		msg_box.setInformativeText(info)

	msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

	with open(os.path.join(parent.lib_path, 'messagebox.qss'),'r') as fh:
		msg_box.setStyleSheet(fh.read())

	returnValue = msg_box.exec()
	if returnValue == QMessageBox.StandardButton.Yes:
		return True
	else:
		return False

def about_dialog(parent):
	dialog_box = QDialog(parent)
	dialog_box.setMinimumSize(300, 300)
	dialog_box.setWindowTitle('About')

	layout = QVBoxLayout(dialog_box)

	titleLabel =  QLabel()
	titleLabel.setText('FlexGUI')
	titleLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(titleLabel)

	imageLabel = QLabel()
	imageLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

	image_path = os.path.join(parent.lib_path, 'flexgui.jpg')
	pixmap = QPixmap(image_path)
	pixmap = pixmap.scaled(256, 256, Qt.AspectRatioMode.KeepAspectRatio)
	imageLabel.setPixmap(pixmap)
	layout.addWidget(imageLabel)

	authorLabel =  QLabel()
	authorLabel.setText('Author: John Thornton')
	authorLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(authorLabel)

	versionLabel =  QLabel()
	versionLabel.setText(f'Version: {parent.flex_version}')
	versionLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(versionLabel)

	aboutLabel =  QLabel()
	aboutLabel.setText('Flexible Graphical User Interface\nfor LinuxCNC')
	aboutLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(aboutLabel)

	websiteLabel =  QLabel()
	websiteLabel.setText("<a href='https://gnipsel.com/'>Authors Website</a>")
	websiteLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	websiteLabel.setOpenExternalLinks(True)
	layout.addWidget(websiteLabel)

	docsLabel =  QLabel()
	docsLabel.setText("<a href='https://gnipsel.com/linuxcnc/flexgui/index.html'>Documents</a>")
	docsLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	docsLabel.setOpenExternalLinks(True)
	layout.addWidget(docsLabel)

	repoLabel =  QLabel()
	repoLabel.setText("<a href='https://github.com/jethornton/flexgui'>Code Website</a>")
	repoLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	repoLabel.setOpenExternalLinks(True)
	layout.addWidget(repoLabel)

	videoLabel =  QLabel()
	videoLabel.setText("<a href='https://www.youtube.com/@Gnipsel/videos'>Youtube Videos</a>")
	videoLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	videoLabel.setOpenExternalLinks(True)
	layout.addWidget(videoLabel)

	from datetime import datetime
	year = datetime.today().year
	copyrightLabel =  QLabel()
	copyrightLabel.setText(f'Copyright © 1953-{year} John Thornton')
	copyrightLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(copyrightLabel)

	layout.addStretch()

	buttonBox = QDialogButtonBox()
	buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Ok)
	buttonBox.setCenterButtons(True)
	buttonBox.accepted.connect(dialog_box.close)
	layout.addWidget(buttonBox)

	dialog_box.exec()

def quick_reference_dialog(parent):
	dialog_box = QDialog(parent)
	dialog_box.setMinimumSize(300, 300)
	dialog_box.setWindowTitle('Keyboard Shortcuts')

	layout = QVBoxLayout(dialog_box)

	titleLabel =  QLabel()
	titleLabel.setText('FlexGUI')
	titleLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
	layout.addWidget(titleLabel)

	shortcutsLabel =  QLabel()
	if len(parent.shortcuts) > 0:
		shortcutsLabel.setText('  \n'.join(parent.shortcuts))
	else:
		shortcutsLabel.setText('No Keyboard Shortcuts Found')
	layout.addWidget(shortcutsLabel)

	layout.addStretch()

	buttonBox = QDialogButtonBox()
	buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Ok)
	buttonBox.setCenterButtons(True)
	buttonBox.accepted.connect(dialog_box.close)
	layout.addWidget(buttonBox)

	dialog_box.exec()

def help_dialog(parent):
	if parent.help_dialog is not None:
		if not parent.help_dialog.isVisible():
			parent.help_dialog = None

	if parent.help_dialog is None:
		btn = parent.sender()
		file_name = btn.property('file')
		if file_name is not None:
			help_file = os.path.join(parent.config_path, file_name)
		else: # verified
			title = 'Configuration Error'
			msg = ('The property "file" is blank or missing.')
			info = 'The Help Dialog can not be launched!'
			error_msg_ok(parent, title, msg, info)
			return

		topic = btn.property('topic')
		if topic is None:
			topic = 'FlexGUI Help'

		width = btn.property('horz_size') or 250
		if isinstance(width, str):
			width = int(width)
		height = btn.property('vert_size') or 250
		if isinstance(height, str):
			height = int(height)
		'''
		x_pos = btn.property('x_pos') or 100
		if isinstance(x_pos, str):
			x_pos = int(x_pos)
		y_pos = btn.property('y_pos') or 100
		if isinstance(y_pos, str):
			y_pos = int(y_pos)
		'''

		if os.path.isfile(help_file):
			parent.help_dialog = QDialog(parent)
			parent.help_dialog.setWindowTitle(topic)
			parent.help_dialog.resize(width, height)
			layout = QVBoxLayout(parent.help_dialog)

			text_edit = QPlainTextEdit()
			layout.addWidget(text_edit)

			buttonBox = QDialogButtonBox()
			buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Close)
			buttonBox.setCenterButtons(True)
			buttonBox.rejected.connect(parent.help_dialog.close)
			layout.addWidget(buttonBox)

			with open(help_file) as f:
				lines = f.readlines()
			for line in lines:
				text_edit.appendPlainText(line.rstrip())

			# Create a cursor object
			cursor = text_edit.textCursor()
			# Move the cursor to the beginning of the document
			cursor.movePosition(QTextCursor.MoveOperation.Start)
			# Set the cursor back to the text edit
			text_edit.setTextCursor(cursor)

			parent.help_dialog.show()
		else: # verified
			title = 'Missing File'
			msg = (f'The help file {file_name} was not found in the configuration '
			f'directory {parent.config_path}')
			info = 'The Help Dialog can not be launched!'
			error_msg_ok(parent, title, msg, info)

