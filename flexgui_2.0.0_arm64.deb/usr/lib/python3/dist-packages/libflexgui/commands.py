import threading

import linuxcnc as emc

from libflexgui import dialogs
from libflexgui import utilities

def home(parent):
	#print('home')
	joint = int(parent.sender().objectName()[-1])
	if parent.status.homed[joint] == 0: # joint not homed
		parent.command.home(joint)

def home_all(parent):
	#print('home_all')
	parent.command.home(-1)

def unhome(parent):
	#print('unhome')
	joint = int(parent.sender().objectName()[-1])
	if parent.status.homed[joint] == 1: # joint is homed
		if parent.status.motion_mode != emc.TRAJ_MODE_FREE:
			parent.command.teleop_enable(False)
			parent.command.wait_complete()
		parent.command.unhome(joint)

def unhome_all(parent):
	#print('unhome_all')
	if parent.status.motion_mode != emc.TRAJ_MODE_FREE:
		parent.command.teleop_enable(False)
		parent.command.wait_complete()
	parent.command.unhome(-1)

def run_mdi(parent, cmd=''):
	if cmd:
		mdi_command = cmd
	else:
		if 'mdi_command_le' in parent.child_names:
			mdi_command = parent.mdi_command_le.text()
	if mdi_command:
		parent.mdi_command = mdi_command
		if parent.status.task_state == emc.STATE_ON:
			if parent.status.task_mode == emc.MODE_MANUAL:
				parent.command.mode(emc.MODE_MDI)
				parent.command.wait_complete()
				parent.command.mdi(mdi_command)
				parent.plotter.update()
	else: # verified
		title = 'Operator Error'
		msg = 'No MDI command was found!'
		dialogs.error_msg_ok(parent, title, msg)

def add_mdi(parent): # when you click on the mdi history list widget
	parent.mdi_command_le.setText(f'{parent.mdi_history_lw.currentItem().text()}')

def mdi_button(parent):
	cmd = parent.sender().property('command')
	run_mdi(parent, cmd)

def jog_check(parent):
	if parent.jog_vel_sl.value() > 0.0:
		return True
	else: # verified
		title = 'Operator Error'
		msg = ('Can not jog at Zero Velocity!')
		dialogs.error_msg_ok(parent, title, msg)
		return False

def set_jog_override(parent):
	if 'override_limits_cb' in parent.child_names:
		parent.override_limits_cb.setChecked(False)
		parent.override_limits_cb.setEnabled(False)

def jog(parent): # only do jog check if button is down
	jog_command = parent.sender().objectName().split('_')
	joint = int(jog_command[-1])
	increment = parent.jog_modes_cb.currentData()
	joint_jog_mode = True if parent.motion_mode == emc.TRAJ_MODE_FREE else False
	vel = parent.jog_vel_sl.value() / 60
	if 'minus' in jog_command:
		vel = -vel
	if parent.sender().isDown():
		if jog_check(parent):
			if increment:
				parent.command.jog(emc.JOG_INCREMENT, joint_jog_mode, joint, vel, increment)
			else:
				parent.command.jog(emc.JOG_CONTINUOUS, joint_jog_mode, joint, vel)
	else:
		parent.command.jog(emc.JOG_STOP, joint_jog_mode, joint)
		set_jog_override(parent)

def jog_selected(parent):
	joint = int(parent.axes_group.checkedButton().objectName().split('_')[-1])
	direction = parent.sender().objectName().split('_')[-1]
	vel = parent.jog_vel_sl.value() / 60
	if direction == 'minus':
		vel = -vel
	increment = parent.jog_modes_cb.currentData()
	joint_jog_mode = True if parent.motion_mode == emc.TRAJ_MODE_FREE else False

	if parent.sender().isDown():
		if jog_check(parent):
			if increment:
				parent.command.jog(emc.JOG_INCREMENT, joint_jog_mode, joint, vel, increment)
			else:
				parent.command.jog(emc.JOG_CONTINUOUS, joint_jog_mode, joint, vel)
	else:
		parent.command.jog(emc.JOG_STOP, joint_jog_mode, joint)
		set_jog_override(parent)

def keyboard_jog(parent, action, axis=None, direction=None):
	vel = parent.jog_vel_sl.value() / 60
	increment = parent.jog_modes_cb.currentData()
	if direction == 'neg':
		vel = -vel
	joint_jog_mode = True if parent.motion_mode == emc.TRAJ_MODE_FREE else False

	if parent.status.task_mode == emc.MODE_MANUAL and action:
		if jog_check(parent):
			if increment:
				parent.command.jog(emc.JOG_INCREMENT, joint_jog_mode, axis, vel, increment)
			else:
				parent.command.jog(emc.JOG_CONTINUOUS, joint_jog_mode, axis, vel)
	elif axis == None: # stop all jogging
		for i in range(parent.status.joints):
			parent.command.jog(emc.JOG_STOP, joint_jog_mode, i)
	else:
		parent.command.jog(emc.JOG_STOP, joint_jog_mode, axis)
		set_jog_override(parent)

def change_cs(parent):
	cs = parent.sender().objectName()[-1]
	cd_dict = {'1': 'G54', '2': 'G55', '3': 'G56', '4': 'G57', '5': 'G58',
		'6': 'G59', '7': 'G59.1', '8': 'G59.2', '9': 'G59.3', }
	cmd = cd_dict[cs]
	run_mdi(parent, cmd)

def clear_axis_offset(parent, axis):
	cmd = f'G10 L2 P0 {axis}0'
	run_mdi(parent, cmd)

def clear_cs(parent):
	cs = parent.sender().objectName().split("_")[-1]
	axes = ''
	for axis in parent.axis_letters:
		axes += f'{axis}0 '
	if int(cs) < 10:
		cmd = f'G10 L2 P{cs} {axes}'
	elif int(cs) == 10:
		cmd = 'G92.1'
	elif int(cs) == 11:
		cmd = 'G10 L2 P0 R0'
	run_mdi(parent, cmd)

def tool_change(parent):
	parent.status.poll()
	tool_len = len(parent.status.tool_table)
	tools = [0]
	for i in range(1, tool_len):
		tools.append(parent.status.tool_table[i][0])
	if parent.sender().objectName().split('_')[-1].isdigit(): # tool button
		parent.new_tool_number = int(parent.sender().objectName().split('_')[-1])
		parent.tool_button = True
		if 'tool_change_cb' in parent.child_names:
			if parent.new_tool_number in tools:
				parent.tool_change_cb.setCurrentIndex(parent.tool_change_cb.findData(parent.new_tool_number))
	else: # using tool change cb
		parent.new_tool_number = parent.tool_change_cb.currentData()
	if parent.new_tool_number not in tools: # verified
		title = 'Tool Change Aborted'
		msg = (f'Tool {parent.new_tool_number} is not in the Tool Table.')
		info = 'Tool Change Aborted!'
		dialogs.error_msg_ok(parent, title, msg, info)
		return

	if parent.new_tool_number != parent.status.tool_in_spindle:
		cmd = f'M6 T{parent.new_tool_number}'
		run_mdi(parent, cmd)

	else: # verified
		title = 'Tool Change Aborted'
		msg = (f'Tool "{parent.new_tool_number}" is already in the Spindle.')
		info = 'Tool Change Aborted!'
		dialogs.error_msg_ok(parent, title, msg, info)

def touchoff(parent):
	#print('touchoff')
	if 'touchoff_system_cb' in parent.child_names:
		coordinate_system = parent.touchoff_system_cb.currentData()
	else:
		coordinate_system = 0
	axis = parent.sender().objectName()[-1].upper()
	btn = parent.sender()

	if btn.property('source') is not None:
		source = btn.property('source')
		offset = getattr(parent, source).text()
	elif 'touchoff_le' in parent.child_names:
		offset = parent.touchoff_le.text()

	cmd = f'G10 L20 P{coordinate_system} {axis}{offset}'
	run_mdi(parent, cmd)

def tool_touchoff(parent):
	parent.status.poll()
	axis = parent.sender().objectName()[-1].upper()
	cur_tool = parent.status.tool_in_spindle
	btn = parent.sender()

	if btn.property('source') is not None:
		source = btn.property('source')
		offset = getattr(parent, source).text()
	elif 'tool_touchoff_le' in parent.child_names:
		offset = parent.tool_touchoff_le.text()

	if offset == '': # verified
		title = 'Error'
		msg = ('The Tool Touchoff Offset can not be blank!')
		dialogs.error_msg_ok(parent, title, msg)
		return

	if cur_tool > 0:
		cmd = f'G10 L10 P{cur_tool} {axis}{offset} G43'
		run_mdi(parent, cmd)

def spindle_control(parent, spindle, action, value=None):
	#print(f'spindle {spindle} action {action} value {value}')
	rpm = getattr(parent, f'spindle_rpm_{spindle}')
	min_rpm =  getattr(parent, f'spindle_{spindle}_min_fwd_rpm')
	max_rpm =  getattr(parent, f'spindle_{spindle}_max_fwd_rpm')
	increment = getattr(parent, f'spindle_{spindle}_rpm_increment')
	override = parent.status.spindle[spindle]['override']

	match action:
		case 'fwd':
			rpm_override = rpm * override
			if min_rpm <= rpm_override <= max_rpm:
				parent.command.spindle(emc.SPINDLE_FORWARD, float(rpm), spindle)
			else: # verified
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}. Spindle will not start!')
				dialogs.status_warning(parent, msg)

		case 'rev':
			#print(f'Spindle:{spindle} Action:{action}')
			rpm_override = rpm * override
			if min_rpm <= rpm_override <= max_rpm:
				parent.command.spindle(emc.SPINDLE_REVERSE, float(rpm), spindle)
			else: # verified
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}. Spindle will not start!')
				dialogs.status_warning(parent, msg)

		case 'stop':
			#print(f'Spindle:{spindle} Action:{action}')
			parent.command.spindle(emc.SPINDLE_OFF, spindle)

		case 'plus':
			#print(f'Spindle:{spindle} Action:{action}')
			rpm = rpm + increment
			rpm_override = rpm * override

			if min_rpm <= rpm_override >= max_rpm: # verified
				if rpm * override > max_rpm:
					rpm = int(max_rpm / override)
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}')
				dialogs.status_warning(parent, msg)
			setattr(parent, f'spindle_rpm_{spindle}', rpm)

			if parent.status.spindle[spindle]['direction'] == 1:
				parent.command.spindle(emc.SPINDLE_FORWARD, float(rpm), spindle)
			elif parent.status.spindle[spindle]['direction'] == -1:
				parent.command.spindle(emc.SPINDLE_REVERSE, float(rpm), spindle)

		case 'minus':
			#print(f'Spindle:{spindle} Action:{action}')
			rpm = rpm - increment
			rpm_override = rpm * override

			if min_rpm <= rpm_override <= max_rpm:
				setattr(parent, f'spindle_rpm_{spindle}', rpm)
			else: # verified
				if rpm * override <= min_rpm:
					rpm = int(min_rpm / override)
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}')
				dialogs.status_warning(parent, msg)

			if parent.status.spindle[spindle]['direction'] == 1:
				parent.command.spindle(emc.SPINDLE_FORWARD, float(rpm), spindle)
			elif parent.status.spindle[spindle]['direction'] == -1:
				parent.command.spindle(emc.SPINDLE_REVERSE, float(rpm), spindle)

		case 'speed': # called by spindle spinboxes and slider
			#print(f'Spindle:{spindle} Action:{action}')
			sender = parent.sender()
			rpm = sender.value()
			object_type = sender.objectName().split('_')[-1]
			rpm_override = rpm * override

			# make sure the rpm is within limits
			if min_rpm < rpm_override > max_rpm: # verified
				rpm = int(max_rpm / override)
				sender.setValue(rpm)
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}')
				dialogs.status_warning(parent, msg)

			setattr(parent, f'spindle_rpm_{spindle}', rpm)
			if parent.status.spindle[spindle]['direction'] == 1:
				parent.command.spindle(emc.SPINDLE_FORWARD, float(rpm), spindle)
			elif parent.status.spindle[spindle]['direction'] == -1:
				parent.command.spindle(emc.SPINDLE_REVERSE, float(rpm), spindle)

		case 'preset':
			#print(f'Spindle:{spindle} Action:{action} Value:{value}')
			rpm = value
			rpm_override = rpm * override

			if min_rpm < rpm_override > max_rpm: # verified
				rpm = int(max_rpm / override)
				sender.setValue(rpm)
				msg = (f'RPM {rpm_override:.0f} Exceeds Spindle {spindle} Limits '
				f'{min_rpm}-{max_rpm}')
				dialogs.status_warning(parent, msg)

			setattr(parent, f'spindle_rpm_{spindle}', rpm)
			if parent.status.spindle[spindle]['direction'] == 1:
				parent.command.spindle(emc.SPINDLE_FORWARD, float(rpm), spindle)
			elif parent.status.spindle[spindle]['direction'] == -1:
				parent.command.spindle(emc.SPINDLE_REVERSE, float(rpm), spindle)

		case 'set_s_word': # use MDI to set the S word
			run_mdi(parent, f'S{rpm} ${spindle}')

		case _:
			print('Unknown Action')

	# if spindle speed slider or spinbox value is not == to rpm change it.
	if ('spindle_speed_sb' in parent.child_names
	and parent.spindle_speed_sb.isEnabled()):
		if parent.spindle_speed_sb.value() != rpm:
			parent.spindle_speed_sb.blockSignals(True)
			parent.spindle_speed_sb.setValue(rpm)
			parent.spindle_speed_sb.blockSignals(False)

	if ('spindle_speed_sl' in parent.child_names
	and parent.spindle_speed_sl.isEnabled()):
		if parent.spindle_speed_sl.value() != rpm:
			parent.spindle_speed_sl.blockSignals(True)
			parent.spindle_speed_sl.setValue(rpm)
			parent.spindle_speed_sl.blockSignals(False)

	if f'spindle_speed_{spindle}_sb' in parent.child_names:
		if getattr(parent, f'spindle_speed_{spindle}_sb').value() != rpm:
			getattr(parent, f'spindle_speed_{spindle}_sb').blockSignals(True)
			getattr(parent, f'spindle_speed_{spindle}_sb').setValue(rpm)
			getattr(parent, f'spindle_speed_{spindle}_sb').blockSignals(False)

	if f'spindle_speed_{spindle}_sl' in parent.child_names:
		if getattr(parent, f'spindle_speed_{spindle}_sl').value() != rpm:
			getattr(parent, f'spindle_speed_{spindle}_sl').blockSignals(True)
			getattr(parent, f'spindle_speed_{spindle}_sl').setValue(rpm)
			getattr(parent, f'spindle_speed_{spindle}_sl').blockSignals(False)

def spindle_override(parent, spindle=0, value=0):
	sender = parent.sender()
	parent.status.poll()
	rpm = parent.status.spindle[spindle]['speed']
	override = value / 100
	min_rpm =  getattr(parent, f'spindle_{spindle}_min_fwd_rpm')
	max_rpm =  getattr(parent, f'spindle_{spindle}_max_fwd_rpm')
	override_rpm = int(rpm * override)
	if min_rpm <= override_rpm <= max_rpm or rpm == 0:
		parent.command.spindleoverride(float(value / 100), spindle)
	else: # verified
		if override_rpm < min_rpm:
			min_override = int((min_rpm / rpm) * 100)
			if min_override >= sender.minimum():
				sender.setValue(min_override)
		elif override_rpm > max_rpm:
			max_override = int((max_rpm / rpm) * 100)
			if max_override <= sender.maximum():
				sender.setValue(max_override)
		msg = (f'Override RPM {override_rpm:.0f} Exceeds Spindle {spindle} Limits '
		f'{min_rpm}-{max_rpm}')
		dialogs.status_warning(parent, msg)

def spindle_override_preset(parent, spindle, value):
	#value = int(parent.sender().objectName().split('_')[-1])
	# spindleoverride(float [, int])
	# Set spindle override factor. Defaults to spindle 0.

	parent.command.spindleoverride(float(value / 100), spindle)
	parent.command.wait_complete()

	if 'spindle_override_sl' in parent.child_names:
		parent.spindle_override_sl.setValue(value)

	if f'spindle_override_{spindle}_sl' in parent.child_names:
		getattr(parent, f'spindle_override_{spindle}_sl').setValue(value)

def flood_toggle(parent):
	parent.status.poll()
	if parent.sender().isChecked():
		if parent.status.task_state == emc.STATE_ON:
			parent.command.flood(emc.FLOOD_ON)
	else:
		if parent.status.task_state == emc.STATE_ON:
			parent.command.flood(emc.FLOOD_OFF)

def mist_toggle(parent):
	parent.status.poll()
	if parent.sender().isChecked():
		if parent.status.task_state == emc.STATE_ON:
			parent.command.mist(emc.MIST_ON)
	else:
		if parent.status.task_state == emc.STATE_ON:
			parent.command.mist(emc.MIST_OFF)

def optional_stop_toggle(parent):
	if parent.optional_stop_pb.isChecked():
		parent.command.set_optional_stop(True)
	else:
		parent.command.set_optional_stop(False)

def block_delete_toggle(parent):
	if parent.block_delete_pb.isChecked():
		parent.command.set_block_delete(True)
	else:
		parent.command.set_block_delete(False)

def feed_override_toggle(parent):
	if parent.feed_override_pb.isChecked():
		parent.command.set_feed_override(True)
	else:
		parent.command.set_feed_override(False)

def feed_override_preset(parent):
	value = int(parent.sender().objectName().split('_')[-1])
	parent.command.feedrate(float(value / 100))
	parent.command.wait_complete()
	if 'feed_override_sl' in parent.child_names:
		parent.feed_override_sl.setValue(value)

def rapid_override_preset(parent):
	value = int(parent.sender().objectName().split('_')[-1])
	parent.command.rapidrate(float(value / 100))
	parent.command.wait_complete()
	if 'rapid_override_sl' in parent.child_names:
		parent.rapid_override_sl.setValue(value)



