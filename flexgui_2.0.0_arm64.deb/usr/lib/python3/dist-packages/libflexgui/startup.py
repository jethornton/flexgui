import os, sys, shutil, re, importlib, gc
from functools import partial
from collections import deque

from PyQt6.QtWidgets import QWidget, QLineEdit
from PyQt6.QtWidgets import QSlider, QMenu, QRadioButton
from PyQt6.QtWidgets import QAbstractButton, QPushButton, QCheckBox
from PyQt6.QtWidgets import QLabel, QLCDNumber, QListView
from PyQt6.QtWidgets import QAbstractSpinBox, QDoubleSpinBox, QSpinBox
from PyQt6.QtWidgets import QProgressBar, QButtonGroup
from PyQt6.QtWidgets import QTabWidget, QVBoxLayout
from PyQt6.QtGui import QAction
from PyQt6.sip import isdeleted  # Import the sip module

import linuxcnc as emc
import hal
import hal_glib

import traceback

#from libflexgui import led
from libflexgui.led import Indicator
from libflexgui.led import IndicatorLabel
from libflexgui.led import IndicatorButton
from libflexgui.led import LEDButton
from libflexgui import actions
from libflexgui import commands
from libflexgui import dialogs
from libflexgui import utilities
from libflexgui import flexplot
from libflexgui import probe

AXES = ['x', 'y', 'z', 'a', 'b', 'c', 'u', 'v', 'w']

def set_screen(parent):
	if parent.settings.contains('GUI/window_size'):
		parent.resize(parent.settings.value('GUI/window_size'))
	if parent.settings.contains('GUI/window_position'):
		parent.move(parent.settings.value('GUI/window_position'))
	else:
		parent.move(0, 0) # if no settings move window to upper left corner

def setup_vars(parent):
	parent.program_units = False
	parent.g_codes = () # G Codes tuple
	parent.m_codes = () # M Codes tuple
	parent.homed = () # Homed Status tuple
	parent.program_paused = False
	parent.motion_line = -1
	parent.plot_units = False
	parent.probing = False
	parent.stop = False
	parent.step = False

	parent.number_le = []
	parent.nccode_le = []
	parent.keyboard_le = []
	parent.nc_viewer = []

	# put any variables in here that might be called during startup
	parent.selected_style = '''
		border-style: inset;
		border-width: 2px;
		border-radius: 1px;
		border-color: gray;
		border-style: solid;'''
	parent.deselected_style = 'border-color: transparent;'
	parent.program_units = False
	parent.plot_units = False

	parent.state_estop_names = {}
	parent.state_estop_reset_names = {}
	parent.state_on_names = {}

	parent.power_controls = [] # enabled when estop is closed
	parent.run_controls = [] # enabled when homed, manual, file loaded
	parent.step_controls = [] # enabled when homed, manual, file loaded
	parent.pause_controls = [] # enabled when program is running
	parent.resume_controls = [] # enabled when program is paused
	parent.file_open_controls = [] # disable when a program or mdi is running
	parent.file_save_controls = [] # disable if no file or program or mdi is running
	parent.file_edit_controls = [] # disable if no file or program or mdi is running
	parent.spindle_controls = [] # enabled when power on and in manual
	parent.mdi_controls = [] # enabled when power on, homed and in manual
	parent.probe_enable = [] # enabled when power on, homed and in manual
	parent.probe_controls = [] # enabled when probe enable  and in manual
	parent.jog_controls = [] # enabled when power on and in manual
	parent.coolant_controls = [] # enabled when power is on
	parent.tool_table_controls = [] # disable when a program or mdi is running
	parent.ladder_editor_control = [] # disable when a program or mdi is running
	parent.tool_change_controls = [] # enabled when power is on and in manual
	parent.tool_touchoff_controls = [] # enabled when tool is loaded and power is on and in manual
	parent.axis_touchoff_controls = [] # enabled when power on, homed, in manual
	parent.coordinate_system_controls = [] # enabled when power on and in manual
	parent.hal_controls = [] # enabled when estop on
	parent.on_controls = [] # enabled when power on
	parent.homed_controls = [] # enabled when power on, homed
	parent.home_controls = [] # disable when power is off
	parent.unhome_controls = [] # disable when power is off

def find_widget_index(layout, target_widget):
	for i in range(layout.count()):
		item = layout.itemAt(i)
		if item.widget() == target_widget:
			return i
		elif item.layout() is not None:
			# Recursively search in nested layouts
			nested_index = find_widget_index(item.layout(), target_widget)
			if nested_index is not None:
				return f"{layout} layout at index {i}, widget at index {nested_index}"
	return None

def find_widget_layout(layout, target_widget):
	for i in range(layout.count()):
		item = layout.itemAt(i)
		if item.widget() == target_widget:
			return layout
		elif item.layout() is not None:
			# Recursively search in nested layouts
			nested_index = find_widget_layout(item.layout(), target_widget)
			if nested_index is not None:
				return item.layout()
	return None

def set_hal_enables(parent, obj):
	obj_name = obj.objectName()
	always_on = obj.property('always_on')
	state_on = obj.property('state_on')
	all_homed = obj.property('all_homed')

	if always_on:
		return

	special_buttons = ['probing_enable_pb', 'tool_changed_pb']
	# all HAL objects are disabled when state estop unless always_on is true
	if state_on and not all_homed:
		parent.on_controls.append(obj_name)
	elif all_homed:
		parent.homed_controls.append(obj_name)
	elif obj_name not in special_buttons: # enable/disable with estop
			parent.hal_controls.append(obj_name)

def setup_hal_leds(parent):
	parent.hal_leds = {}
	for child in parent.findChildren(QLabel):
		if child.property('function') == 'hal_led':
			obj_name = child.objectName()
			pin_name = child.property('pin_name')

			if child.property('pin_name') in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL LED "{obj_name}" is missing the Dynamic '
				'Property "pin_name" or it is blank.')
				info = 'The LED will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				child.setProperty('function', '')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL LED "{obj_name}" pin name "{pin_name}" is already used in '
				'Flex GUI. The HAL pin can not be created.')
				info = f'The LED "{obj_name}" label will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				# set the function to an empty string to prevent trying to create a HAL pin
				child.setProperty('function', '')
				continue

			led_dict = {}
			led_dict['name'] = child.objectName()
			dia = child.property('diameter') or False
			if dia:
				led_dict['diameter'] = int(dia)
			else: # use the label size
				led_dict['diameter'] = min(child.width(), child.height())

			margins = child.contentsMargins()
			margin = max((margins.left() + margins.right()), (margins.top() + margins.bottom()))
			edge_margin = child.property('edge_margin')
			if edge_margin:
				led_dict['margin'] = max(margin, edge_margin)
			else:
				led_dict['margin'] = margin

			led_dict['on_color'] = child.property('on_color') or parent.led_on_color
			led_dict['off_color'] = child.property('off_color') or parent.led_off_color
			led_shape = child.property('led_shape') # validate shape
			if led_shape in ['square', 'round']:
				led_dict['shape'] = led_shape
			elif led_shape is None:
				led_dict['shape'] = 'round'
			elif led_shape is not None and led_shape not in ['square', 'round']:
				title = 'Configuration Error'
				msg = (f'The HAL LED Label"{obj_name}" Dynamic Property "led_shape" is '
				'blank or not one of "square" or "round".')
				info = f'The LED shape will be round.'
				dialogs.error_msg_ok(parent, title, msg, info)

			led_dict['shape'] = led_shape if led_shape == 'square' else 'round'
			led_dict['function'] = child.property('function')
			# set old object function to none so the hal pin is not duplicated
			child.setProperty('function', 'none')
			led_dict['pin_name'] = child.property('pin_name')

			new_led = Indicator(**led_dict)
			new_led.setProperty('function', led_dict['function'])
			new_led.setProperty('pin_name', led_dict['pin_name'])

			layout = child.parent().layout()
			if layout is not None:
				child_layout = find_widget_layout(layout, child)
				if child_layout is not None:
					child_layout.replaceWidget(child, new_led)
			else: # widget is not in a layout
				geometry = child.geometry()
				child_parent = child.parent()
				new_led.setParent(child_parent)
				new_led.setGeometry(geometry)

			child.deleteLater()
			gc.collect()
			new_led.setObjectName(led_dict['name'])
			setattr(parent, led_dict['name'], new_led) # give the new button the old name
			parent.hal_leds[led_dict['name']] = led_dict['pin_name']

def setup_hal_led_labels(parent):
	parent.hal_led_labels = {}
	for child in parent.findChildren(QLabel):
		if child.property('function') == 'hal_led_label':
			pin_name = child.property('pin_name')
			obj_name = child.objectName()

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL LED Label"{obj_name}" is missing the Dynamic '
				'Property "pin_name" or it is blank.')
				info = f'The LED "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				# set the function to an empty string to prevent trying to create a HAL pin
				child.setProperty('function', '')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL LED Label "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI. The HAL pin can not be created.')
				info = f'The LED "{obj_name}" label will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				# set the function to an empty string to prevent trying to create a HAL pin
				child.setProperty('function', '')
				continue

			led_dict = {}
			led_dict['name'] = child.objectName()
			led_dict['text'] = child.text()
			led_dict['diameter'] = child.property('led_diameter') or parent.led_diameter
			led_dict['top_offset'] = child.property('led_top_offset') or parent.led_top_offset
			led_dict['right_offset'] = child.property('led_right_offset') or parent.led_right_offset
			led_dict['on_color'] = child.property('led_on_color') or parent.led_on_color
			led_dict['off_color'] = child.property('led_off_color') or parent.led_off_color
			led_shape = child.property('led_shape') # validate shape
			led_dict['shape'] = led_shape if led_shape == 'square' else 'round'
			led_dict['function'] = child.property('function')
			# set old object function to none so the hal pin is not duplicated
			child.setProperty('function', 'none')
			led_dict['pin_name'] = child.property('pin_name')

			new_label = IndicatorLabel(**led_dict)
			new_label.setProperty('function', led_dict['function'])
			new_label.setProperty('pin_name', led_dict['pin_name'])

			layout = child.parent().layout()
			if layout is not None:
				child_layout = find_widget_layout(layout, child)
				if child_layout is not None:
					child_layout.replaceWidget(child, new_label)
			else: # widget is not in a layout
				geometry = child.geometry()
				child_parent = child.parent()
				new_label.setParent(child_parent)
				new_label.setGeometry(geometry)

			# copy style from old label to new label
			new_label.setAlignment(child.alignment())
			new_label.setSizePolicy(child.sizePolicy())
			new_label.setFrameShape(child.frameShape())
			new_label.setFrameShadow(child.frameShadow())
			new_label.setFont(child.font())

			child.deleteLater()
			gc.collect()
			new_label.setObjectName(led_dict['name'])
			setattr(parent, led_dict['name'], new_label) # give the new label the old name
			parent.hal_led_labels[led_dict['name']] = led_dict['pin_name']

def setup_hal_led_buttons(parent):
	##### HAL LED QPushButtons #####
	# find led buttons and get all properties
	for child in parent.findChildren(QPushButton):
		if child.property('function') == 'hal_led_button':
			obj_name = child.objectName()
			pin_name = child.property('pin_name')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL LED Button "{obj_name}" with this text "{child.text()}" '
				'is missing the Dynamic Property pin_name or it is blank.')
				info = f'The button "{obj_name}" will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				child.setProperty('function', '')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL LED Button "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI The HAL pin can not be created.')
				info = f'The button "{obj_name}" will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				child.setProperty('function', '')
				continue

			led_dict = {}
			led_dict['name'] = child.objectName()
			led_dict['text'] = child.text()
			skip_names = ['diameter', 'right_offset', 'top_offset', 'on_color', 'off_color']
			# get dynamic properties that are not specific to led
			for prop_name_bytes in child.dynamicPropertyNames():
				prop_name = prop_name_bytes.data().decode('utf-8')
				prop_value = child.property(prop_name)
				if prop_name not in skip_names: # add other properties not specific to led
					led_dict[prop_name] = prop_value
			led_dict['diameter'] = child.property('led_diameter') or parent.led_diameter
			led_dict['right_offset'] = child.property('led_right_offset') or parent.led_right_offset
			led_dict['top_offset'] = child.property('led_top_offset') or parent.led_top_offset
			led_dict['on_color'] = child.property('led_on_color') or parent.led_on_color
			led_dict['off_color'] = child.property('led_off_color') or parent.led_off_color
			led_shape = child.property('led_shape') # validate shape
			led_dict['shape'] = led_shape if led_shape == 'square' else 'round'
			new_button = LEDButton(**led_dict)

			# copy style from old button to new button
			new_button.setFont(child.font())
			new_button.setSizePolicy(child.sizePolicy())
			new_button.setMinimumSize(child.minimumSize())
			new_button.setMaximumSize(child.maximumSize())
			new_button.setStyleSheet(child.styleSheet())
			new_button.setCheckable(child.isCheckable())

			layout = child.parent().layout()
			if layout is not None:
				child_layout = find_widget_layout(layout, child)
				if child_layout is not None:
					child_layout.replaceWidget(child, new_button)
			else: # widget is not in a layout
				geometry = child.geometry()
				child_parent = child.parent()
				new_button.setParent(child_parent)
				new_button.setGeometry(geometry)

			# copy dynamic properties
			for prop_name_bytearray in child.dynamicPropertyNames():
				prop_name = prop_name_bytearray.data().decode('utf-8')
				prop_value = child.property(prop_name)
				# Set the property on the new button
				new_button.setProperty(prop_name, prop_value)

			child.deleteLater()
			gc.collect()
			new_button.setObjectName(led_dict['name'])
			setattr(parent, led_dict['name'], new_button) # give the new button the old name

	##### LED Indicator QPushButton #####
	hal_types = ['hal_pin', 'hal_led_button', 'hal_io', 'hal_avr_f', 'hal_msl',
	'hal_led', 'hal_led_label']
	for child in parent.findChildren(QPushButton):
		if child.property('led_indicator'):
			obj_name = child.objectName()
			pin_name = child.property('pin_name')
			btn_text = child.text()

			if child.property('function') in hal_types: # verified
				title = 'Configuration Error'
				msg = (f'The button "{obj_name}" and with the text of "{btn_text}" can not '
				'be a LED Indicator and a HAL pin. If it is a valid HAL pin the HAL '
				'connection will be made.')
				info = f'The button "{obj_name}" LED will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL LED Button "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI The HAL pin can not be created.')
				info = f'The button "{obj_name}" will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)
				child.setText('Error!')
				child.setProperty('function', '')
				continue

			btn_dict = {}
			btn_dict['name'] = child.objectName()
			btn_dict['text'] = child.text()
			skip_names = ['diameter', 'right_offset', 'top_offset', 'on_color', 'off_color']
			# get dynamic properties that are not specific to led
			for prop_name_bytes in child.dynamicPropertyNames():
				prop_name = prop_name_bytes.data().decode('utf-8')
				prop_value = child.property(prop_name)
				if prop_name not in skip_names: # add other properties not specific to led
					btn_dict[prop_name] = prop_value
			btn_dict['diameter'] = child.property('led_diameter') or parent.led_diameter
			btn_dict['right_offset'] = child.property('led_right_offset') or parent.led_right_offset
			btn_dict['top_offset'] = child.property('led_top_offset') or parent.led_top_offset
			btn_dict['on_color'] = child.property('led_on_color') or parent.led_on_color
			btn_dict['off_color'] = child.property('led_off_color') or parent.led_off_color
			led_shape = child.property('led_shape') # validate shape
			btn_dict['shape'] = led_shape if led_shape == 'square' else 'round'
			new_button = IndicatorButton(**btn_dict)

			layout = child.parent().layout()
			if layout is not None:
				child_layout = find_widget_layout(layout, child)
				if child_layout is not None:
					child_layout.replaceWidget(child, new_button)
			else: # widget is not in a layout
				geometry = child.geometry()
				child_parent = child.parent()
				new_button.setParent(child_parent)
				new_button.setGeometry(geometry)

			# copy dynamic properties
			for prop_name_bytearray in child.dynamicPropertyNames():
				prop_name = prop_name_bytearray.data().decode('utf-8')
				prop_value = child.property(prop_name)
				# Set the property on the new button
				new_button.setProperty(prop_name, prop_value)

			# copy style from old button to new button
			new_button.setFont(child.font())
			new_button.setSizePolicy(child.sizePolicy())
			new_button.setMinimumSize(child.minimumSize())
			new_button.setMaximumSize(child.maximumSize())
			new_button.setStyleSheet(child.styleSheet())
			new_button.setCheckable(child.isCheckable())

			child.deleteLater()
			gc.collect()
			new_button.setObjectName(btn_dict['name'])
			setattr(parent, btn_dict['name'], new_button) # give the new button the old name

'''
from this point on use parent.child_names to get the widgets because the LED
widgets are no longer QPushButton but led.LEDButton for example
'''
def find_children(parent): # get the object names of all widgets
	parent.child_names = []
	children = parent.findChildren(QWidget)
	for child in children:
		if child.objectName():
			parent.child_names.append(child.objectName())
	parent.actions = parent.findChildren(QAction)
	for action in parent.actions:
		if action.objectName():
			parent.child_names.append(action.objectName())
			if 'toolBar' in parent.child_names:
				widget_name = f'flex_{action.objectName()[6:].replace(" ", "_")}'
				# make sure the action is in the tool bar
				if parent.toolBar.widgetForAction(action) is not None:
					parent.toolBar.widgetForAction(action).setObjectName(widget_name)
					setattr(parent, widget_name, parent.toolBar.widgetForAction(action))
					parent.child_names.append(widget_name)
	menus = parent.findChildren(QMenu)
	for menu in menus:
		if menu.objectName():
			parent.child_names.append(menu.objectName())

def setup_menus(parent):
	menus = parent.findChildren(QMenu)
	parent.shortcuts = []
	for menu in menus:
		menu_list = menu.actions()
		for index, action in enumerate(menu_list):
			if action.objectName() == 'actionOpen':
				if index + 1 < len(menu_list):
					parent.menuRecent = QMenu('Recent', parent)
					parent.menuRecent.setObjectName('menuRecent')
					parent.child_names.append('menuRecent')
					parent.menuFile.insertMenu(menu_list[index + 1], parent.menuRecent)
					# if any files have been opened add them
					keys = parent.settings.allKeys()
					for key in keys:
						if key.startswith('recent_files'):
							path = parent.settings.value(key)
							name = os.path.basename(path)
							a = parent.menuRecent.addAction(name)
							a.triggered.connect(partial(getattr(actions, 'load_file'), parent, path))

			elif action.objectName() == 'actionHoming': # add homing actions
				action.setMenu(QMenu('Homing', parent))
				parent.child_names.append('actionHoming')

				# add Home All if the home sequence is set for all axes homey
				if utilities.home_all_check(parent):
					setattr(parent, 'actionHome_All', QAction('Home All', parent))
					getattr(parent, 'actionHome_All').setObjectName('actionHome_all')
					action.menu().addAction(getattr(parent, 'actionHome_All'))
					parent.child_names.append('actionHome_All')
					getattr(parent,'actionHome_All').triggered.connect(partial(commands.home_all, parent))

				# add Home menu item for each axis
				for i, axis in enumerate(parent.axis_letters):
					setattr(parent, f'actionHome_{i}', QAction(f'Home {axis}', parent))
					getattr(parent, f'actionHome_{i}').setObjectName(f'actionHome_{i}')
					action.menu().addAction(getattr(parent, f'actionHome_{i}'))
					parent.child_names.append(f'actionHome_{i}')
					getattr(parent, f'actionHome_{i}').triggered.connect(partial(commands.home, parent))

			# add the unhoming menu items
			elif action.objectName() == 'actionUnhoming':
				action.setMenu(QMenu('Unhoming', parent))
				setattr(parent, 'actionUnhome_All', QAction('Unhome All', parent))
				getattr(parent, 'actionUnhome_All').setObjectName('actionUnhome_All')
				action.menu().addAction(getattr(parent, 'actionUnhome_All'))
				getattr(parent,'actionUnhome_All').triggered.connect(partial(commands.unhome_all, parent))

				for i, axis in enumerate(parent.axis_letters):
					setattr(parent, f'actionUnhome_{i}', QAction(f'Unhome {axis}', parent))
					getattr(parent, f'actionUnhome_{i}').setObjectName(f'actionUnhome_{i}')
					action.menu().addAction(getattr(parent, f'actionUnhome_{i}'))
					parent.child_names.append(f'actionUnhome_{i}')
					getattr(parent, f'actionUnhome_{i}').triggered.connect(partial(commands.unhome, parent))

			elif action.objectName() == 'actionClear_Offsets':
				action.setMenu(QMenu('Clear Offsets', parent))
				cs = ['Current', 'G54', 'G55', 'G56', 'G57', 'G58', 'G59', 'G59.1',
				'G59.2', 'G59.3', 'G92', 'Rotation']
				for i, item in enumerate(cs):
					setattr(parent, f'actionClear_{i}', QAction(f'Clear {item}', parent))
					getattr(parent, f'actionClear_{i}').setObjectName(f'actionClear_{i}')
					action.menu().addAction(getattr(parent, f'actionClear_{i}'))
					getattr(parent, f'actionClear_{i}').triggered.connect(partial(commands.clear_cs, parent))

			if len(action.shortcut().toString()) > 0: # collect shortcuts for quick reference
				parent.shortcuts.append(f'{action.text()}\t{action.shortcut().toString()}')

def setup_actions(parent): # setup menu actions
	actions_dict = {
		'actionOpen': 'action_open',
		'actionEdit': 'action_edit',
		'actionReload': 'action_reload',
		'actionEdit_Tool_Table': 'action_edit_tool_table',
		'actionReload_Tool_Table': 'action_reload_tool_table',
		'actionLadder_Editor': 'action_ladder_editor',
		'actionQuit': 'action_quit',
		'actionE_Stop': 'action_estop',
		'actionPower': 'action_power',
		'actionRun': 'action_run',
		'actionRun_From_Line': 'action_run_from_line',
		'actionStep': 'action_step',
		'actionPause': 'action_pause',
		'actionResume': 'action_resume',
		'actionStop': 'action_stop',
		'actionSave_MDI': 'action_save_mdi',
		'actionClear_MDI_History': 'action_clear_mdi',
		'actionCopy_MDI_History': 'action_copy_mdi',
		'actionOverlay': 'action_toggle_overlay',
		'actionShow_HAL': 'action_show_hal',
		'actionHAL_Meter': 'action_hal_meter',
		'actionHAL_Scope': 'action_hal_scope',
		'actionAbout': 'action_about',
		'actionQuick_Reference': 'action_quick_reference',
		'actionClear_Live_Plot': 'action_clear_live_plot'}

	# if an action is found connect it to the function
	for key, value in actions_dict.items():
		if key in parent.child_names:
			getattr(parent, f'{key}').triggered.connect(partial(getattr(actions, f'{value}'), parent))

	save_actions = {'actionSave': 'action_save', 'actionSave_As': 'action_save_as'}

	for key, value in save_actions.items():
		if key in parent.child_names:
			if 'gcode_pte' in parent.child_names:
				getattr(parent, key).triggered.connect(partial(getattr(actions, value), parent))
			else: # verified
				getattr(parent, key).setEnabled(False)
				title = 'Configuration Error'
				msg = ('File Save controls require the "gcode_pte" Plain Text Edit.')
				info = f'The File Save control {key} will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)

	# special check for MDI
	if 'mdi_history_lw' in parent.child_names:
		if 'actionClear_MDI_History' in parent.child_names:
			parent.actionClear_MDI_History.setEnabled(False)
		if 'actionCopy_MDI_History' in parent.child_names:
			parent.actionCopy_MDI_History.setEnabled(False)

def update_check(parent):
	if 'feedrate_lb' in parent.child_names: # verified
		title = 'Object Name Changed'
		msg = ('The Feed Override Percent Label object name "feedrate_lb" has been '
		'changed to "feed_override_lb". Change the object name in the ui file.')
		info = 'The label will be disabled and will not function.'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.feedrate_lb.setEnabled(False)
		parent.feedrate_lb.setText('Error!')

def setup_enables(parent):

	# power controls
	for item in ['power_pb', 'actionPower']:
		if item in parent.child_names:
			parent.power_controls.append(item)

	# run controls
	for item in ['run_pb', 'actionRun', 'run_from_line_pb', 'actionRun_From_Line']:
		if item in parent.child_names:
			parent.run_controls.append(item)

	# step controls
	for item in ['step_pb', 'actionStep']:
		if item in parent.child_names:
			parent.step_controls.append(item)

	# pause controls
	for item in ['pause_pb', 'actionPause']:
		if item in parent.child_names:
			parent.pause_controls.append(item)

	# resume controls
	for item in ['resume_pb', 'actionResume']:
		if item in parent.child_names:
			parent.resume_controls.append(item)

	# jog controls
	for item in ['jog_selected_plus', 'jog_selected_minus']:
		if item in parent.child_names:
			parent.jog_controls.append(item)

	for i in range(parent.joints):
		if f'jog_plus_pb_{i}' in parent.child_names:
			parent.jog_controls.append(f'jog_plus_pb_{i}')
		if f'jog_minus_pb_{i}' in parent.child_names:
			parent.jog_controls.append(f'jog_minus_pb_{i}')

	# file open controls
	for item in ['open_pb', 'actionOpen', 'menuRecent']:
		if item in parent.child_names:
			parent.file_open_controls.append(item)

	# file open buttons
	for child in parent.findChildren(QPushButton):
		if child.property('function') == 'load_file':
			child.clicked.connect(partial(actions.load_file, parent))
			parent.file_open_controls.append(child.objectName())

	# file save controls
	if 'gcode_pte' in parent.child_names:
		for item in ['save_pb', 'actionSave', 'save_as_pb', 'actionSave_As']:
			if item in parent.child_names:
				parent.file_save_controls.append(item)

	# file edit controls
	for item in ['edit_pb', 'actionEdit', 'reload_pb', 'actionReload']:
		if item in parent.child_names:
			parent.file_edit_controls.append(item)

	# coolant controls
	for item in ['flood_pb', 'mist_pb']:
		if item in parent.child_names:
			parent.coolant_controls.append(item)

	# tool table controls
	for item in ['edit_tool_table_pb', 'reload_tool_table_pb',
	'actionEdit_Tool_Table', 'actionReload_Tool_Table']:
		if item in parent.child_names:
			parent.tool_table_controls.append(item)

	# classic ladder
	for item in ['edit_ladder_pb', 'actionLadder_Editor']:
		if item in parent.child_names:
			if hal.component_exists("classicladder_rt"):
				parent.ladder_editor_control.append(item)
			else:
				title = 'Configuration Error'
				msg = (f'The Classic Ladder control "{item}" was found but Classic '
				'Ladder is not loaded.')
				info = f'The "{item}" will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, item).setEnabled(False)

	# home controls
	for item in ['home_all_pb', 'actionHoming', 'actionHome_All']:
		if item in parent.child_names:
			parent.home_controls.append(item)

	for joint in range(parent.joints):
		if f'home_pb_{joint}' in parent.child_names:
			parent.home_controls.append(f'home_pb_{joint}')
		if f'actionHome_{joint}' in parent.child_names:
			parent.home_controls.append(f'actionHome_{joint}')

	# unhome controls
	for item in ['unhome_all_pb', 'actionUnhoming', 'actionUnhome_All']:
		if item in parent.child_names:
			parent.unhome_controls.append(item)

	for joint in range(parent.joints):
		if f'unhome_pb_{joint}' in parent.child_names:
			parent.unhome_controls.append(f'unhome_pb_{joint}')
		if f'actionUnhome_{joint}' in parent.child_names:
			parent.unhome_controls.append(f'actionUnhome_{joint}')

	# coordinate system controls
	for i in range(1, 10):
		if f'change_cs_{i}' in parent.child_names:
			parent.coordinate_system_controls.append(f'change_cs_{i}')
	for i in range(12):
		if f'clear_coord_{i}' in parent.child_names:
			parent.coordinate_system_controls.append(f'clear_coord_{i}')
	if 'actionClear_Offsets' in parent.child_names:
		parent.coordinate_system_controls.append('actionClear_Offsets')
	for i in range(12):
		if f'actionClear_{i}' in parent.child_names:
			parent.coordinate_system_controls.append(f'actionClear_{i}')

def setup_buttons(parent): # connect buttons to functions
	if 'estop_pb' in parent.child_names:
		parent.estop_pb.toggled.connect(partial(actions.action_estop, parent))
		parent.estop_pb.setCheckable(True)

		off_text = parent.estop_pb.property('off_text')
		if off_text is not None:
			parent.state_estop_names['estop_pb'] = off_text

		on_text = parent.estop_pb.property('on_text')
		if on_text is not None:
			parent.state_estop_reset_names['estop_pb'] = on_text

	if 'power_pb' in parent.child_names:
		parent.power_pb.toggled.connect(partial(actions.action_power, parent))
		parent.power_pb.setCheckable(True)

		on_text = parent.power_pb.property('on_text')
		if on_text is not None:
			parent.state_on_names['power_pb'] = on_text

		off_text = parent.power_pb.property('off_text')
		if off_text is not None:
			parent.state_estop_names['power_pb'] = off_text

		off_text = parent.power_pb.property('off_text')
		if off_text is not None:
			parent.state_estop_reset_names['power_pb'] = off_text

	if 'manual_mode_pb' in parent.child_names: # verified
		title = 'Depreciated Control'
		msg = ('The manual_mode_pb is no longer used. This was only used for '
		'testing in the early days.')
		info = 'The button will be disabled'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.manual_mode_pb.setEnabled(False)
		parent.manual_mode_pb.setText('Error!')

	command_buttons = {
	'abort_pb': 'abort', 'home_all_pb': 'home_all', 'home_pb_0': 'home',
	'home_pb_1': 'home', 'home_pb_2': 'home', 	'unhome_all_pb': 'unhome_all',
	'unhome_pb_0': 'unhome', 'unhome_pb_1': 'unhome', 'unhome_pb_2': 'unhome'
	}

	for key, value in command_buttons.items():
		if key in parent.child_names:
			getattr(parent, key).clicked.connect(partial(getattr(commands, value), parent))

	action_buttons = {
	'run_pb': 'action_run',
	'run_from_line_pb': 'action_run_from_line',
	'step_pb': 'action_step',
	'pause_pb': 'action_pause',
	'resume_pb': 'action_resume',
	'stop_pb': 'action_stop',
	'open_pb': 'action_open',
	'edit_pb': 'action_edit',
	'reload_pb': 'action_reload',
	'edit_tool_table_pb': 'action_edit_tool_table',
	'edit_ladder_pb': 'action_ladder_editor',
	'reload_tool_table_pb': 'action_reload_tool_table',
	'quit_pb': 'action_quit',
	'show_hal_pb': 'action_show_hal',
	'hal_meter_pb': 'action_hal_meter',
	'hal_scope_pb': 'action_hal_scope',
	'about_pb': 'action_about',
	'quick_reference_pb': 'action_quick_reference'
	}

	for key, value in action_buttons.items():
		if key in parent.child_names:
			getattr(parent, key).clicked.connect(partial(getattr(actions, value), parent))

	save_buttons = {'save_pb': 'action_save', 'save_as_pb': 'action_save_as'}

	for key, value in save_buttons.items():
		if key in parent.child_names:
			if 'gcode_pte' in parent.child_names:
				getattr(parent, key).clicked.connect(partial(getattr(actions, value), parent))
			else: # verified
				getattr(parent, key).setEnabled(False)
				title = 'Configuration Error'
				msg = ('File Save controls require the "gcode_pte" Plain Text Edit.')
				info = f'The File Save control {key} will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)

	mdi_history_buttons = {
	'clear_mdi_history_pb': 'action_clear_mdi',
	'copy_mdi_history_pb': 'action_copy_mdi',
	'save_mdi_history_pb': 'action_save_mdi',
	}

	for key, value in mdi_history_buttons.items():
		if key in parent.child_names:
			if 'mdi_history_lw' in parent.child_names:
				getattr(parent, key).clicked.connect(partial(getattr(actions, value), parent))
			else: # verified
				title = 'Configuration Error'
				msg = (f'The "{key}" button was found but the "mdi_history_lw" was not '
				'found.')
				info = f'The {key}" button will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, key).setEnabled(False)

	if 'errors_pte' in parent.child_names:
		if 'clear_errors_pb' in parent.child_names:
			parent.clear_errors_pb.clicked.connect(partial(utilities.clear_errors, parent))

		if 'copy_errors_pb' in parent.child_names:
			parent.copy_errors_pb.clicked.connect(partial(utilities.copy_errors, parent))

	if 'clear_info_pb' in parent.child_names:
		if 'info_pte' in parent.child_names:
			parent.clear_info_pb.clicked.connect(partial(utilities.clear_info, parent))

	# touch off coordinate system combo box
	if 'touchoff_system_cb' in parent.child_names:
		parent.touchoff_system_cb.setView(QListView())
		coordinate_systems = {'Current': 0, 'G54': 1, 'G55': 2, 'G56': 3, 'G57': 4,
			'G58': 5, 'G59': 6, 'G59.1': 7, 'G59.2': 8, 'G59.3': 9}
		for key, value in coordinate_systems.items():
			parent.touchoff_system_cb.addItem(key, value)

	# change coordinate system buttons
	for i in range(1, 10):
		name = f'change_cs_{i}'
		if name in parent.child_names:
			button = getattr(parent, name)
			button.clicked.connect(partial(commands.change_cs, parent))
			#parent.program_running_disabled.append(name)

	# Clear coordinate system buttons
	for i in range(12):
		name = f'clear_coord_{i}'
		if name in parent.child_names:
			button = getattr(parent, name)
			button.clicked.connect(partial(commands.clear_cs, parent))
			#parent.program_running_disabled.append(name)

	checkable_buttons = {'flood_pb': 'flood_toggle', 'mist_pb': 'mist_toggle',
		'optional_stop_pb': 'optional_stop_toggle',
		'block_delete_pb': 'block_delete_toggle',
		'feed_override_pb': 'feed_override_toggle',
}
	for key, value in checkable_buttons.items():
		if key in parent.child_names: # make sure checkable is set to true
			if not getattr(parent, key).isCheckable():
				getattr(parent, key).setCheckable(True)
			getattr(parent, key).clicked.connect(partial(getattr(commands, value), parent))

	# set the button checked states
	if 'feed_override_pb' in parent.child_names:
		parent.feed_override_pb.setChecked(parent.status.feed_override_enabled)

	# clear axis offset button setup
	for axis in AXES:
		name = f'clear_{axis}_pb'
		if name in parent.child_names:
			button = getattr(parent, name)
			button.clicked.connect(partial(commands.clear_axis_offset, parent, axis.upper()))

	# override preset buttons
	for item in parent.child_names:
		if item.startswith('feed_percent_'):
			button = getattr(parent, item)
			value = item.split('_')[-1]
			if utilities.is_int(value):
				button.clicked.connect(partial(commands.feed_override_preset, parent))
			else: # verified
				title = 'Object Name Error'
				msg = (f'The button named "{item}" with the button text of '
				f'"{button.text()}" the value "{value}" did not evaluate to an integer')
				info = 'The button will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				button.setText('Error!')
				getattr(parent, item).setEnabled(False)

		elif item.startswith('rapid_percent_'):
			button = getattr(parent, item)
			value = item.split('_')[-1]
			if utilities.is_int(value):
				if int(value) <= 100:
					button.clicked.connect(partial(commands.rapid_override_preset, parent))
				else: # verified
					title = 'Object Name Error'
					msg = (f'The button named "{item}" with the button text of '
					f'"{button.text()}". The value "{value}" is higher than the maximum '
					'of 100')
					info = 'The button will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					button.setText('Error!')
					getattr(parent, item).setEnabled(False)
			else: # verified
				title = 'Object Name Error'
				msg = (f'The button named "{item}" with the button text of '
				f'"{button.text()}" the value "{value}" did not evaluate to an integer')
				info = 'The button will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				button.setText('Error!')
				getattr(parent, item).setEnabled(False)

	# nc code search
	if 'search_pb' in parent.child_names:
		parent.search_pb.clicked.connect(partial(dialogs.find, parent))

	# flashing buttons
	parent.flashing_buttons = []
	for child in parent.findChildren(QPushButton):
		if isdeleted(child): # check if the QPushButton has been deleted
			continue
		if child.property('flash_state') in ['checked', 'unchecked']:
			if child.isCheckable():
				parent.flashing_buttons.append(child.objectName())
			else: # verified
				title = 'Configuration Error'
				msg = (f'The flashing button named "{child.objectName()}" with the text '
				f'of "{child.text()}" is not set to checkable.')
				info = 'This button will not flash.'
				dialogs.error_msg_ok(parent, title, msg, info)

def setup_status_labels(parent):
	parent.stat_dict = {'adaptive_feed_enabled': {0: False, 1: True},
	'motion_mode': {1: 'TRAJ_MODE_FREE', 2: 'TRAJ_MODE_COORD', 3: 'TRAJ_MODE_TELEOP'},
	'exec_state': {1: 'EXEC_ERROR', 2: 'EXEC_DONE', 3: 'EXEC_WAITING_FOR_MOTION',
		4: 'EXEC_WAITING_FOR_MOTION_QUEUE', 5: 'EXEC_WAITING_FOR_IO',
		7: 'EXEC_WAITING_FOR_MOTION_AND_IO', 8: 'EXEC_WAITING_FOR_DELAY',
		9: 'EXEC_WAITING_FOR_SYSTEM_CMD', 10: 'EXEC_WAITING_FOR_SPINDLE_ORIENTED',},
	'estop': {0: False, 1: True},
	'flood': {0: 'OFF', 1: 'ON'},
	'mist': {0: 'OFF', 1: 'ON'},
	'g5x_index': {1: 'G54', 2: 'G55', 3: 'G56', 4: 'G57', 5: 'G58', 6: 'G59',
		7: 'G59.1', 8: 'G59.2', 9: 'G59.3'},
	'interp_state': {1: 'INTERP_IDLE', 2: 'INTERP_READING',
		3: 'INTERP_PAUSED', 4: 'INTERP_WAITING'},
	'interpreter_errcode': {0: 'INTERP_OK', 1: 'INTERP_EXIT',
		2: 'INTERP_EXECUTE_FINISH', 3: 'INTERP_ENDFILE', 4: 'INTERP_FILE_NOT_OPEN',
		5: 'INTERP_ERROR'},
	'kinematics_type': {1: 'KINEMATICS_IDENTITY', 2: 'KINEMATICS_FORWARD_ONLY',
		3: 'KINEMATICS_INVERSE_ONLY', 4: 'KINEMATICS_BOTH'},
	'motion_mode': {1: 'TRAJ_MODE_FREE', 2: 'TRAJ_MODE_COORD', 3: 'TRAJ_MODE_TELEOP'},
	'motion_type': {0: 'MOTION_TYPE_NONE', 1: 'MOTION_TYPE_TRAVERSE',
		2: 'MOTION_TYPE_FEED', 3: 'MOTION_TYPE_ARC', 4: 'MOTION_TYPE_TOOLCHANGE',
		5: 'MOTION_TYPE_PROBING', 6: 'MOTION_TYPE_INDEXROTARY'},
	'state': {1: 'RCS_DONE', 2: 'RCS_EXEC', 3: 'RCS_ERROR'},
	'task_mode': {1: 'MODE_MANUAL', 2: 'MODE_AUTO', 3: 'MODE_MDI', },
	'task_state': {1: 'STATE_ESTOP', 2: 'STATE_ESTOP_RESET', 4: 'STATE_ON', },
	}

	status_items = ['active_queue', 'actual_position', 'ain', 'aout', 'axis',
	'adaptive_feed_enabled', 'axis_mask', 'block_delete', 'call_level', 'command',
	'current_line', 'debug', 'din', 'echo_serial_number', 'enabled', 'estop',
	'exec_state', 'feed_hold_enabled', 'feed_override_enabled', 'flood',
	'g5x_index', 'g5x_offset', 'homed', 'ini_filename', 'inpos', 'input_timeout',
	'interp_state', 'interpreter_errcode', 'joint', 'joint_actual_position',
	'joint_position', 'joints', 'kinematics_type', 'limit', 'lube', 'lube_level',
	'mist', 'motion_line', 'motion_mode', 'motion_type', 'optional_stop',
	'paused', 'pocket_prepped', 'position', 'probe_tripped', 'probe_val',
	'probed_position', 'probing', 'queue', 'queue_full', 'read_line', 'spindle',
	'spindles', 'state', 'task_mode', 'task_paused', 'task_state',
	'tool_in_spindle', 'tool_from_pocket', 'tool_offset', 'tool_table']

	# check for status labels in the ui key is label and value is status item
	parent.status_labels = {} # create an empty dictionary
	for item in status_items: # iterate the status items list
		if f'{item}_lb' in parent.child_names: # if the label is found
			parent.status_labels[f'{item}_lb'] = item # add the status and label

	# status exponent labels
	parent.status_exponent_labels = {}
	status_exponent_items = ['acceleration', 'max_acceleration', 'max_velocity']
	for item in status_exponent_items: # iterate the status items list
		if f'{item}_lb' in parent.child_names: # if the label is found
			parent.status_exponent_labels[f'{item}_lb'] = item # label & item

	# status float labels
	parent.status_float_labels = {}
	status_float_items = ['angular_units', 'current_vel',
	'cycle_time', 'delay_left', 'distance_to_go', 'linear_units',
	'rapidrate', 'rotation_xy']

	for item in status_float_items: # iterate the status items list
		if f'{item}_lb' in parent.child_names: # if the label is found
			p = getattr(parent, f'{item}_lb').property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_float_labels[item] = p # item & precision

	# check for joint labels in ui
	# reflects [JOINT_n]BACKLASH. Fails if not in the ini file
	for i in range(parent.joints):
		if f'joint_{i}_backlash_lb' in parent.child_names:
			backlash = parent.inifile.find(f'JOINT_{i}', 'BACKLASH') or False
			if backlash:
				getattr(parent, f'joint_{i}_backlash_lb').setText(backlash)
			else:
				getattr(parent, f'joint_{i}_backlash_lb').setText('N/A')

	joint_items = ['enabled', 'fault', 'ferror_current',
	'ferror_highmark', 'homed', 'homing', 'inpos', 'input', 'jointType',
	'max_ferror', 'max_hard_limit', 'max_position_limit', 'max_soft_limit',
	'min_ferror', 'min_hard_limit', 'min_position_limit', 'min_soft_limit',
	'output', 'override_limits']

	parent.status_joints = {} # create an empty dictionary
	for i in range(parent.joints):
		for item in joint_items:
			if f'joint_{i}_{item}_lb' in parent.child_names:
				parent.status_joints[f'joint_{i}_{item}_lb'] = item

	# joint float labels key is item value is [joint, precision]
	# joint[1]["homed"]
	joint_number_items = ['units', 'velocity']
	parent.status_joint_prec = {}
	for i in range(parent.joints):
		for item in joint_number_items:
			if f'joint_{i}_{item}_lb' in parent.child_names: # if the label is found
				p = getattr(parent, f'joint_{i}_{item}_lb').property('precision')
				p = p if p is not None else parent.default_precision
				parent.status_joint_prec[item] = [i, p] # add the label, tuple position & precision

	parent.status_position = {} # create an empty dictionary
	for i, axis in enumerate(AXES):
		label = f'actual_lb_{axis}'
		if label in parent.child_names:
			p = getattr(parent, label).property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_position[f'{label}'] = [i, p] # label , joint & precision

	# DRO labels
	parent.status_dro = {} # create an empty dictionary
	for i, axis in enumerate(AXES):
		label = f'dro_lb_{axis}'
		if label in parent.child_names:
			p = getattr(parent, label).property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_dro[f'{label}'] = [i, p] # add the label, tuple position & precision

	# G5x Offset Labels
	parent.status_g5x_offset = {} # create an empty dictionary
	for i, axis in enumerate(AXES):
		label = f'g5x_lb_{axis}'
		if label in parent.child_names:
			p = getattr(parent, label).property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_g5x_offset[f'{label}'] = [i, p] # add the label, tuple position & precision

	# G92 Offset Labels
	parent.status_g92 = {} # create an empty dictionary
	for i, axis in enumerate(AXES):
		label = f'g92_lb_{axis}'
		if label in parent.child_names:
			p = getattr(parent, label).property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_g92[f'{label}'] = [i, p] # add the label, tuple position & precision

	# Distance to Go Labels
	parent.status_dtg = {} # create an empty dictionary
	for i, axis in enumerate(AXES):
		label = f'dtg_lb_{axis}'
		if label in parent.child_names:
			p = getattr(parent, label).property('precision')
			p = p if p is not None else parent.default_precision
			parent.status_dtg[f'{label}'] = [i, p] # add the label, tuple position & precision

	parent.status_axes = {} # create an empty dictionary
	for i in range(parent.axis_count):
		for item in ['max_position_limit', 'min_position_limit', 'velocity']:
			label = f'axis_{i}_{item}_lb'
			if label in parent.child_names:
				p = getattr(parent, label).property('precision')
				p = p if p is not None else parent.default_precision
				parent.status_axes[label] = [i, item, p] # axis, status item, precision

	# two joint velocity
	if 'two_vel_lb' in parent.child_names: # verified
		title = 'Configuration Error'
		msg = ('The "two_vel_lb" label is depreciated. See the  Velocity Labels '
		'section of the Labels Documents for correct configuration.')
		info = 'The label will not function!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.two_vel_lb.setText('Error!')
		parent.two_vel_lb.setEnabled(False)

	parent.two_vel = {}

	for child in parent.findChildren(QLabel):
		if child.property('function') == 'two_joint_velocity':
			obj_name = child.objectName()
			joint_0 = child.property('joint_0')
			joint_1 = child.property('joint_1')

			if not isinstance(joint_0, int): # verified
				title = 'Configuration Error'
				msg = (f'The two joint velocity label {obj_name} "joint_0" property '
				'is missing or not an integer type. See the Velocity Labels section of '
				'the Labels Documents for correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			if not isinstance(joint_1, int): # verified
				title = 'Configuration Error'
				msg = (f'The two joint velocity label {obj_name} "joint_1" property '
				'is missing or not an integer type. See the Velocity Labels section of '
				'the Labels Documents for correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			if len(set([joint_0, joint_1])) != 2: # verified
				title = 'Configuration Error'
				msg = (f'The two joint velocity label {obj_name} the joints are not '
				'unique. See the Velocity Labels section of the Labels Documents for '
				'correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			p = child.property('precision')
			p = p if p is not None else parent.default_precision
			parent.two_vel[obj_name] = [joint_0, joint_1, p]

	# three joint velocity
	if 'three_vel_lb' in parent.child_names: # verified
		title = 'Configuration Error'
		msg = ('The "three_vel_lb" label is depreciated. See the  Velocity Labels '
		'section of the Labels Documents for correct configuration.')
		info = 'The label will not function!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.three_vel_lb.setText('Error!')
		parent.three_vel_lb.setEnabled(False)

	parent.three_vel = {}

	for child in parent.findChildren(QLabel):
		if child.property('function') == 'three_joint_velocity':
			obj_name = child.objectName()
			joint_0 = child.property('joint_0')
			joint_1 = child.property('joint_1')
			joint_2 = child.property('joint_2')

			if not isinstance(joint_0, int): # verified
				title = 'Configuration Error'
				msg = (f'The three joint velocity label {obj_name} "joint_0" property '
				'is missing or not an integer type. See the Velocity Labels section of '
				'the Labels Documents for correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			if not isinstance(joint_1, int): # verified
				title = 'Configuration Error'
				msg = (f'The three joint velocity label {obj_name} "joint_1" property '
				'is missing or not an integer type. See the Velocity Labels section of '
				'the Labels Documents for correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			if not isinstance(joint_2, int): # verified
				title = 'Configuration Error'
				msg = (f'The three joint velocity label {obj_name} "joint_2" property '
				'is missing or not an integer type. See the Velocity Labels section of '
				'the Labels Documents for correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			if len(set([joint_0, joint_1, joint_2])) != 3: # verified
				title = 'Configuration Error'
				msg = (f'The three joint velocity label "{obj_name}" the joints are '
				'not unique. See the Velocity Labels section of the Labels Documents '
				'for the correct configuration.')
				info = 'The label will not function!'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)
				continue

			p = child.property('precision')
			p = p if p is not None else parent.default_precision
			parent.three_vel[obj_name] = [joint_0, joint_1, joint_2, p]

	# joint velocity joint_velocity_n_lb parent.status.joint[0]['velocity']
	parent.joint_vel_sec = {}
	for i in range(parent.status.joints):
		if f'joint_{i}_vel_sec_lb' in parent.child_names: # if the label is found
			p = getattr(parent, f'joint_{i}_vel_sec_lb').property('precision')
			p = p if p is not None else parent.default_precision
			parent.joint_vel_sec[f'joint_{i}_vel_sec_lb'] = [i, p] # add the label, tuple position & precision

	# joint[0]['velocity'] joint_0_vel_min_lb
	parent.joint_vel_min = {}
	for i in range(parent.status.joints):
		if f'joint_{i}_vel_min_lb' in parent.child_names: # if the label is found
			p = getattr(parent, f'joint_{i}_vel_min_lb').property('precision')
			p = p if p is not None else parent.default_precision
			parent.joint_vel_min[f'joint_{i}_vel_min_lb'] = [i, p] # add the label, tuple position & precision

	override_items = {'feed_override_lb': 'feedrate' , 'rapid_override_lb': 'rapidrate'}

	parent.overrides = {}
	for key, value in override_items.items():
		if key in parent.child_names:
			parent.overrides[key] = value

	# Digital I/0
	parent.status_dio = {}
	for i in range(parent.dio):
		for item in ['din', 'dout']:
			label = f'{item}_{i}_lb'
			if label in parent.child_names:
				parent.status_dio[label] = [item, i] # add label and stat
				parent.stat_dict[f'{item}[{i}]'] = {0: False, 1: True}

	# Analog I/O
	parent.status_aio = {}
	for i in range(parent.aio):
		for item in ['ain', 'aout']:
			label = f'{item}_{i}_lb'
			if label in parent.child_names:
				p = getattr(parent, f'{item}_{i}_lb').property('precision')
				p = p if p is not None else parent.default_precision
				parent.status_aio[label] = [item, i, p] # add label, stat and precision

	# check for tool table labels in the ui , 'comment'
	# id and orientation are integers and the rest are floats
	parent.current_tool_intergers = {}
	parent.current_tool_floats = {}
	tool_table_intergers = ['id', 'orientation']
	tool_table_floats = ['xoffset', 'yoffset', 'zoffset', 'aoffset',
		'boffset', 'coffset', 'uoffset', 'voffset', 'woffset', 'diameter',
		'frontangle', 'backangle']

	for item in tool_table_intergers:
		if f'tool_{item}_lb' in parent.child_names:
			parent.current_tool_intergers[f'tool_{item}_lb'] = item

	for item in tool_table_floats:
		if f'tool_{item}_lb' in parent.child_names:
			prec = getattr(parent, f'tool_{item}_lb').property('precision')
			prec = prec if prec is not None else parent.default_precision
			parent.current_tool_floats[f'tool_{item}_lb'] = [item, prec]

	parent.current_tool_info = ()

	# add file name if loaded from the ini
	if 'file_lb' in parent.child_names:
		gcode_file = parent.status.file or False
		if gcode_file:
			parent.file_lb.setText(os.path.basename(gcode_file))
			if 'start_line_lb' in parent.child_names:
				parent.start_line_lb.setText('0')
		else:
			parent.file_lb.setText('N/A')
			if 'start_line_lb' in parent.child_names:
				parent.start_line_lb.setText('n/a')

	parent.home_status = []
	for i in range(9):
		if f'home_lb_{i}' in parent.child_names:
			parent.home_status.append(f'home_lb_{i}')

	# Special case in case you want to use the label to annotate
	# multiple places in the UI.
	parent.program_units_labels = []
	for child in parent.child_names:
		if child.startswith('program_units_lb'):
			parent.program_units_labels.append(child)

		# These don't change and only need to be set once during startup
		if child.startswith('machine_units_lb'):
			suffix = getattr(parent, child).property('suffix') or ''
			getattr(parent, child).setText(f'{parent.units}{suffix}')

def setup_list_widgets(parent):
	if 'file_lw' in parent.child_names:
		utilities.read_dir(parent) # this is called from actions as well
		parent.file_lw.itemClicked.connect(partial(actions.file_selector, parent))

def setup_plain_text_edits(parent):
	# for gcode_pte update
	parent.motion_line = -1
	if 'gcode_pte' in parent.child_names:
		parent.gcode_pte.viewport().setObjectName('gcode_pte_viewport')
		parent.gcode_pte.setCenterOnScroll(True)
		parent.gcode_pte.ensureCursorVisible()
		parent.gcode_pte.viewport().installEventFilter(parent)
		parent.gcode_pte.cursorPositionChanged.connect(partial(utilities.update_qcode_pte, parent))
		parent.last_line = parent.status.motion_line
		parent.gcode_pte.textChanged.connect(partial(utilities.nc_code_changed, parent))
		if 'start_line_lb' in parent.child_names:
			parent.nc_viewer.append('gcode_pte_viewport')

def setup_stacked_widgets(parent):
	for child in parent.findChildren(QPushButton):
		if child.property('change_page'):
			child.clicked.connect(partial(utilities.change_page, parent))
		elif child.property('next_page'):
			child.clicked.connect(partial(utilities.next_page, parent))
		elif child.property('previous_page'):
			child.clicked.connect(partial(utilities.previous_page, parent))

def setup_line_edits(parent):
	for child in parent.findChildren(QLineEdit):
		if child.property('input') == 'number': # enable the number pad
			parent.number_le.append(child.objectName())
			child.installEventFilter(parent)
		elif child.property('input') == 'nccode': # enable the nc code pad
			parent.nccode_le.append(child.objectName())
			child.installEventFilter(parent)
		elif child.property('input') == 'keyboard': # enable the keyboard pad
			parent.keyboard_le.append(child.objectName())
			child.installEventFilter(parent)

def setup_spin_boxes(parent):
	parent.touch_sb = []
	for child in parent.findChildren(QAbstractSpinBox):
		if child.property('input') == 'number' or parent.touch_spinbox: # enable the number pad
			sb_child = child.findChild(QLineEdit)
			sb_child.setObjectName(f'{child.objectName()}_child')
			parent.touch_sb.append(sb_child.objectName())
			sb_child.installEventFilter(parent)

def load_postgui(parent): # load post gui hal and tcl files if found
	if parent.postgui_halfiles:
		for f in parent.postgui_halfiles:
			if os.path.exists(os.path.join(parent.config_path, f)):
				if f.lower().endswith('.tcl'):
					res = os.spawnvp(os.P_WAIT, "haltcl", ["haltcl", "-i", parent.ini_path, f])
				else:
					res = os.spawnvp(os.P_WAIT, "halcmd", ["halcmd", "-i", parent.ini_path, "-f", f])
				if res: raise SystemExit(res)
			else: # verified
				title = 'Configuration Error'
				msg = (f'The POSTGUI_HALFILE "{f}" was not found in the configuration '
				'directory.')
				info = 'The post gui file is not loaded!'
				dialogs.error_msg_ok(parent, title, msg, info)

def setup_mdi(parent):
	# mdi_command_le is required to run mdi commands
	# run_mdi_pb and mdi_history_lw are optional
	parent.mdi_command = ''

	if 'mdi_command_le' in parent.child_names:
		parent.mdi_command_le.returnPressed.connect(partial(commands.run_mdi, parent))
	if 'run_mdi_pb' in parent.child_names:
		parent.run_mdi_pb.clicked.connect(partial(commands.run_mdi, parent))
		parent.mdi_controls.append('run_mdi_pb')

	if 'mdi_history_lw' in parent.child_names:
		path = os.path.dirname(parent.status.ini_filename)
		mdi_file = os.path.join(path, 'mdi_history.txt')
		if os.path.exists(mdi_file): # load mdi history
			with open(mdi_file, 'r') as f:
				history_list = f.readlines()
				for item in history_list:
					parent.mdi_history_lw.addItem(item.strip())
		parent.mdi_history_lw.itemSelectionChanged.connect(partial(commands.add_mdi, parent))

def setup_mdi_buttons(parent):
	for child in parent.findChildren(QPushButton):
		if child.property('function') == 'mdi':
			if child.property('command'):
				obj_name = child.objectName()
				child.clicked.connect(partial(commands.mdi_button, parent))
				if not obj_name.startswith('probe_'):
					parent.mdi_controls.append(obj_name)
			else: # verified
				title = 'Configuration Error'
				msg = (f'The MDI Button "{child.text()}" does not have the Dynamic '
				'Property "command" with a MDI command')
				info = f'"{child.text()}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setText('Error!')
				child.setEnabled(False)

def setup_jog(parent):
	# keyboard jog
	parent.kb_jog_cb_enabled = False
	parent.kb_jog_ctrl_enabled = False

	if 'keyboard_jog_cb' in parent.child_names and not parent.ctrl_kb_jogging:
		parent.keyboard_jog_cb.toggled.connect(partial(utilities.jog_toggled, parent))
		if parent.keyboard_jog_cb.isChecked():
			parent.kb_jog_cb_enabled = True
		else:
			parent.kb_jog_cb_enabled = False
	elif parent.ctrl_kb_jogging and not 'keyboard_jog_cb' in parent.child_names:
		parent.kb_jog_ctrl_enabled = True
	elif 'keyboard_jog_cb' in parent.child_names and parent.ctrl_kb_jogging:
		title = 'Configuration Error'
		msg = ('The Keyboard Jog checkbox "keyboard_jog_cb" and the ini entry '
		'KEYBOARD_JOG were both found. Only one type of keyboard jog can be used.')
		info = 'Keyboard jog is disabled!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.keyboard_jog_cb.setEnabled(False)
		parent.kb_jog_ctrl_enabled = False
		parent.kb_jog_cb_enabled = False

	if parent.kb_jog_focus and 'keyboard_jog_cb' not in parent.child_names:
		title = 'Configuration Error'
		msg = ('Auto keyboard jog focus handling requires the '
		'"keyboard_jog_cb" checkbox.')
		info = 'Keyboard jog is disabled!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.kb_jog_focus = False

	if parent.kb_jog_focus and parent.ctrl_kb_jogging:
		title = 'Configuration Error'
		msg = ('Auto keyboard jog focus handling and control-based keyboard '
		'jogging are both enabled. Both auto focus handling and control-based '
		'keyboard jog can not be used together.')
		info = 'Keyboard jog is disabled!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.kb_jog_focus = False
		parent.kb_jog_ctrl_enabled = False

	required_jog_items = ['jog_vel_sl', 'jog_modes_cb']
	parent.jog_buttons = []
	for i in range(parent.joints):
		if f'jog_plus_pb_{i}' in parent.child_names:
			parent.jog_buttons.append(f'jog_plus_pb_{i}')
		if f'jog_minus_pb_{i}' in parent.child_names:
			parent.jog_buttons.append(f'jog_minus_pb_{i}')

	if len(parent.jog_buttons) > 0:
		for item in required_jog_items:
			# don't make the connection if all required widgets are not present
			if item not in parent.child_names:
				title = 'Configuration Error'
				msg = (f'The "{item}" is required to jog but was not found.')
				info = 'Jog Buttons will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				for item in parent.jog_buttons:
					getattr(parent, item).setEnabled(False)
				return

		# ok to connect if we get this far
		for item in parent.jog_buttons: # connect jog buttons
			getattr(parent, item).pressed.connect(partial(getattr(commands, 'jog'), parent))
			getattr(parent, item).released.connect(partial(getattr(commands, 'jog'), parent))

	if 'jog_vel_sl' in parent.child_names:
		if parent.min_jog_vel:
			parent.jog_vel_sl.setMinimum(int(float(parent.min_jog_vel) * 60))
			if 'min_jog_vel_lb' in parent.child_names:
				parent.min_jog_vel_lb.setText(f'{int(float(parent.min_jog_vel) * 60)}')

		if parent.default_jog_vel:
			parent.jog_vel_sl.blockSignals(True)
			parent.jog_vel_sl.setValue(int(float(parent.default_jog_vel) * 60))
			parent.jog_vel_sl.blockSignals(False)

		if parent.max_jog_vel:
			parent.jog_vel_sl.setMaximum(int(float(parent.max_jog_vel) * 60))
			if 'max_jog_vel_lb' in parent.child_names:
				parent.max_jog_vel_lb.setText(f'{int(float(parent.max_jog_vel) * 60)}')
		elif parent.max_linear_vel:
			parent.jog_vel_sl.setMaximum(int(float(parent.max_linear_vel) * 60))
			if 'max_jog_vel_lb' in parent.child_names:
				parent.max_jog_vel_lb.setText(f'{int(float(parent.max_linear_vel) * 60)}')
		else:
			if parent.joints > 0:
				maxjv = []
				for i in range(parent.joints):
					maxjv.append(parent.inifile.find(f'JOINT_{i}', 'MAX_VELOCITY'))
				parent.max_jog_vel = min(maxjv)
				parent.jog_vel_sl.setMaximum(int(float(parent.max_jog_vel) * 60))
				title = 'Configuration Error'
				msg = ('The DISPLAY key MAX_LINEAR_VELOCITY or TRAJ MAX_LINEAR_VELOCITY '
				'was not found. The jog slider maximum will be set to the lowest joint '
				'maximum velocity')
				dialogs.error_msg_ok(parent, title, msg)

		if 'jog_vel_lb' in parent.child_names:
			parent.jog_vel_sl.valueChanged.connect(partial(utilities.update_jog_lb, parent))
			parent.jog_vel_lb.setText(f'{parent.jog_vel_sl.value()}')
			utilities.update_jog_lb(parent)

		# machine units are inch
		# do not convert in or inch
		# convert mil to inch mil * 0.001 = inch
		# convert cm to inch divide the value by 2.54
		# convert mm to inch divide the value by 25.4
		# convert um to inch divide the value by 25400

		# machine units are mm
		# convert inches to mm multiply the value by 25.4
		# convert mil to mm mil * 0.001 = inch multiply the value by 25.4
		# convert cm to mm multiply the length value by 10
		# no conversion for mm
		# convert um to mm divide the length value by 1000

		if 'jog_modes_cb' in parent.child_names:
			parent.jog_modes_cb.setView(QListView())
			parent.jog_modes_cb.addItem('Continuous', False)

			# setup the jog increment combo box items
			if parent.jog_increments:
				for item in parent.jog_increments.split(','):
					item = item.strip()
					text, data, suffix = utilities.is_valid_increment(parent, item)
					if data:
						jog_distance = conv_units(data, suffix.lower(), parent.units)
						parent.jog_modes_cb.addItem(text, jog_distance)
					else:
						title = 'Configuration Error'
						msg = (f'The DISPLAY INCREMENTS entry in the ini "{item}" is not '
						'a valid unit and will not be used. INCREMENTS must be comma '
						'seperated. See the Jogging section of the manual.')
						info = f'The "{item}" will not be used!'
						dialogs.error_msg_ok(parent, title, msg, info)

	# keyboard jog increment check that jog_modes_cb exists
	if parent.kb_jog_increment:
		if 'jog_modes_cb' not in parent.child_names:
			title = 'Configuration Error'
			msg = ('The keyboard jog increment setting requires the jog_modes_cb to '
			'work.')
			info = f'Keyboard Jog Increments will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.kb_jog_increment = False

def conv_units(value, suffix, units):
	if units == 'IN':
		if suffix == 'in' or suffix == 'inch':
			return float(value)
		elif suffix == 'mil':
			return float(value) * 0.001
		elif suffix == 'cm':
			return float(value) / 2.54
		elif suffix == 'mm':
			return float(value) / 25.4
		elif suffix == 'um':
			return float(value) / 25400

	elif units == 'MM':
		if suffix == 'in' or suffix == 'inch':
			return float(value) * 25.4
		elif suffix == 'mil':
			return float(value) * 0.0254
		elif suffix == 'cm':
			return float(value) * 10
		elif suffix == 'mm':
			return float(value)
		elif suffix == 'um':
			return float(value) / 1000

def setup_spindle(parent):
	#### emc reports at least 1 spindle no matter what
	# spindles are numbered 0-7 but parent.status.spindles reports 1-8

	# create spindle tuple
	parent.status_spindle = ()

	##### Check for old object names
	if 'spindle_actual_speed_lb' in parent.child_names: # verified
		title = 'Configuration Error'
		msg = ('The spindle speed label "spindle_actual_speed_lb" name has '
		'been changed to "spindle_speed_0_lb" to limit confustion about what the '
		'name implies. See the spindle documents for more information.')
		info = 'The label will be disabled!'
		dialogs.error_msg_ok(parent, title, msg, info)
		parent.spindle_actual_speed_lb.setEnabled(False)
		parent.spindle_actual_speed_lb.setText('Error!')

	##### Start of Multiple Spindle #####

	# check for number of spindles matches the number of status labels
	multi_spindle_labels = ['spindle_brake', 'spindle_enabled',
		'spindle_orient_state', 'spindle_orient_fault', 'spindle_override_enabled',
		'spindle_direction', 'spindle_speed', 'spindle_override',
		'spindle_cmd_speed']

	max_spindle = parent.status.spindles - 1

	parent.spindle_int = {}
	spindle_int = {
	'spindle_brake': 'brake',
	'spindle_enabled': 'enabled',
	'spindle_orient_state': 'orient_state',
	'spindle_orient_fault': 'orient_fault'
	}

	for key, value in spindle_int.items():
		for i in range(8):
			if f'{key}_{i}_lb' in parent.child_names:
				if i <= max_spindle:
					parent.spindle_int[f'{key}_{i}_lb'] = [i, value]
				else: # verified
					title = 'Configuration Error'
					msg = (f'The spindle status label "{key}_{i}_lb" is more than the '
					f'number of spindles')
					info = 'The label will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, f'{key}_{i}_lb').setText('Error!')
					getattr(parent, f'{key}_{i}_lb').setEnabled(False)

	parent.spindle_bool = {}
	for i in range(8):
		if f'spindle_override_enabled_{i}_lb' in parent.child_names:
			if i <= max_spindle:
				parent.spindle_bool[f'spindle_override_enabled_{i}_lb'] = [i, 'override_enabled']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_override_enabled_{i}_lb" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_override_enabled_{i}_lb').setText('Error!')
				getattr(parent, f'spindle_override_enabled_{i}_lb').setEnabled(False)

	parent.spindle_dir = {}
	for i in range(8):
		if f'spindle_direction_{i}_lb' in parent.child_names:
			if i <= max_spindle:
				parent.spindle_dir[f'spindle_direction_{i}_lb'] = [i, 'direction']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_direction_{i}_lb" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_direction_{i}_lb').setText('Error!')
				getattr(parent, f'spindle_direction_{i}_lb').setEnabled(False)

	parent.spindle_speed = {}
	for i in range(8):
		if f'spindle_speed_{i}_lb' in parent.child_names:
			if i <= max_spindle:
				parent.spindle_speed[f'spindle_speed_{i}_lb'] = [i, 'speed']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_speed_{i}_lb" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_speed_{i}_lb').setText('Error!')
				getattr(parent, f'spindle_speed_{i}_lb').setEnabled(False)

	parent.status_spindle_lcd = {}
	for i in range(8):
		if f'spindle_speed_{i}_lcd' in parent.child_names:
			if i <= max_spindle:
				parent.status_spindle_lcd[f'spindle_speed_{i}_lcd'] = [i, 'speed']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_speed_{i}_lcd" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_speed_{i}_lcd').setEnabled(False)

	parent.spindle_override = {}
	for i in range(8):
		if f'spindle_override_{i}_lb' in parent.child_names:
			if i <= max_spindle:
				parent.spindle_override[f'spindle_override_{i}_lb'] = [i, 'override']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_override_{i}_lb" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_override_{i}_lb').setText('Error!')
				getattr(parent, f'spindle_override_{i}_lb').setEnabled(False)

	parent.spindle_cmd_speed = {}
	for i in range(8):
		if f'spindle_cmd_speed_{i}_lb' in parent.child_names:
			if i <= max_spindle:
				parent.spindle_cmd_speed[f'spindle_cmd_speed_{i}_lb'] = [i, 'override']
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle status label "spindle_cmd_speed_{i}_lb" is '
				'more than the number of spindles')
				info = 'The label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_cmd_speed_{i}_lb').setText('Error!')
				getattr(parent, f'spindle_cmd_speed_{i}_lb').setEnabled(False)

	# check for number of spindles matches the number of controls
	multi_spindle_controls = ['spindle_fwd', 'spindle_rev', 'spindle_stop',
	'spindle_plus', 'spindle_minus', 'spindle_speed']

	# set up multiple spindle controls
	for i in range(8):
		for item in ['spindle_fwd', 'spindle_rev', 'spindle_stop', 'spindle_plus', 'spindle_minus']:
			if f'{item}_{i}_pb' in parent.child_names:
				if i <= max_spindle:
						action = item.split('_')[-1]
						getattr(parent, f'{item}_{i}_pb').clicked.connect(
						partial(commands.spindle_control, parent, i, action))
						parent.spindle_controls.append(f'{item}_{i}_pb')
				else: # verified
					title = 'Configuration Error'
					msg = (f'The spindle control "{item}_{i}_pb" is  more than the '
					'number of spindles.')
					info = 'The control will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, f'{item}_{i}_pb').setText('Error!')
					getattr(parent, f'{item}_{i}_pb').setEnabled(False)

	# set spindle S word
	for i in range(8):
		if f'set_speed_{i}_pb' in parent.child_names:
			if i <= max_spindle:
				action = 'set_s_word'
				getattr(parent, f'set_speed_{i}_pb').clicked.connect(
				partial(commands.spindle_control, parent, i, action))
				parent.mdi_controls.append(f'set_speed_{i}_pb')
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle control "set_speed_{i}_pb" is  more than the '
				'number of spindles.')
				info = 'The control will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'set_speed_{i}_pb').setText('Error!')
				getattr(parent, f'set_speed_{i}_pb').setEnabled(False)

	for i in range(8):
		if f'spindle_override_{i}_sl' in parent.child_names:
			if i <= max_spindle:
				min_override = getattr(parent, f'spindle_{i}_min_override')
				max_override = getattr(parent, f'spindle_{i}_max_override')
				getattr(parent, f'spindle_override_{i}_sl').blockSignals(True)
				getattr(parent, f'spindle_override_{i}_sl').setMinimum(min_override)
				getattr(parent, f'spindle_override_{i}_sl').setMaximum(max_override)
				if max_override >= 100:
					getattr(parent, f'spindle_override_{i}_sl').setValue(100)
				else:
					getattr(parent, f'spindle_override_{i}_sl').setValue(max_override)
				getattr(parent, f'spindle_override_{i}_sl').blockSignals(False)

				getattr(parent, f'spindle_override_{i}_sl').valueChanged.connect(
				partial(commands.spindle_override, parent, i))
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle control spindle_override_{i}_sl is '
				'more than the number of spindles')
				info = 'The slider will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_override_{i}_sl').setEnabled(False)

	# Spindle Speed Spin Boxes
	for i in range(8):
		if f'spindle_speed_{i}_sb' in parent.child_names:
			if i <= max_spindle:
				min_rpm = getattr(parent, f'spindle_{i}_min_fwd_rpm')
				max_rpm = getattr(parent, f'spindle_{i}_max_fwd_rpm')
				increment = getattr(parent, f'spindle_{i}_rpm_increment')
				getattr(parent, f'spindle_speed_{i}_sb').blockSignals(True)
				getattr(parent, f'spindle_speed_{i}_sb').setMaximum(max_rpm)
				getattr(parent, f'spindle_speed_{i}_sb').setMinimum(min_rpm)
				getattr(parent, f'spindle_speed_{i}_sb').setSingleStep(increment)
				def_rpm  = getattr(parent, f'spindle_rpm_{i}')
				getattr(parent, f'spindle_speed_{i}_sb').setValue(def_rpm)
				getattr(parent, f'spindle_speed_{i}_sb').blockSignals(False)

				getattr(parent, f'spindle_speed_{i}_sb').valueChanged.connect(
				partial(commands.spindle_control, parent, i, 'speed'))
				parent.spindle_controls.append(f'spindle_speed_{i}_sb')
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle control spindle_speed_{i}_sb is '
				'more than the number of spindles')
				info = 'The spinbox will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_speed_{i}_sb').setEnabled(False)

	# Spindle Speed Sliders spindle_speed_0_sl
	for i in range(8):
		if f'spindle_speed_{i}_sl' in parent.child_names:
			if i <= max_spindle:
				min_rpm = getattr(parent, f'spindle_{i}_min_fwd_rpm')
				max_rpm  = getattr(parent, f'spindle_{i}_max_fwd_rpm')
				default_rpm = getattr(parent, f'spindle_rpm_{i}')
				getattr(parent, f'spindle_speed_{i}_sl').blockSignals(True)
				getattr(parent, f'spindle_speed_{i}_sl').setRange(min_rpm, max_rpm)
				getattr(parent, f'spindle_speed_{i}_sl').setValue(default_rpm)
				getattr(parent, f'spindle_speed_{i}_sl').blockSignals(False)
				getattr(parent, f'spindle_speed_{i}_sl').valueChanged.connect(partial(
				commands.spindle_control, parent, i, 'speed'))
			else: # verified
				title = 'Configuration Error'
				msg = (f'The spindle control spindle_speed_{i}_sl is '
				'more than the number of spindles')
				info = 'The slider will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, f'spindle_speed_{i}_sl').setEnabled(False)

	# Spindle Speed Presets
	for i in range(8):
		for item in parent.child_names:
			if item.startswith(f'spindle_set_{i}'):
				if i <= max_spindle:
					min_rpm = getattr(parent, f'spindle_{i}_min_fwd_rpm')
					max_rpm  = getattr(parent, f'spindle_{i}_max_fwd_rpm')
					button = getattr(parent, item)
					value = item.split('_')[-1]
					if utilities.is_int(value):
						rpm = int(value)
						if min_rpm <= rpm <= max_rpm:
							button.clicked.connect(partial(commands.spindle_control, parent, i, 'preset', rpm))
						else: # verified
							title = 'Configuration Error'
							msg = (f'The RPM "{rpm}" of "{button.objectName()}" exceeds either '
							f'the spindle "{i}" Minimum Limit "{min_rpm}" RPM or the Maximum '
							f'Limit "{max_rpm}" RPM.')
							info = f'The Button "{button.objectName()}" will be disabled.'
							dialogs.error_msg_ok(parent, title, msg, info)
							button.setEnabled(False)
							button.setText('Error!')
				else: # verified
					title = 'Configuration Error'
					msg = (f'The spindle preset "{item}" is '
					'more than the number of spindles')
					info = 'The pushbutton will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					button.setEnabled(False)
					button.setText('Error!')

	# Spindle Override Presets spindle_percent_0_100
	for i in range(8):
		for item in parent.child_names:
			if item.startswith(f'spindle_percent_{i}') and len(item.split('_')) == 4:
				if i <= max_spindle:
					button = getattr(parent, item)
					value = item.split('_')[-1]
					if utilities.is_int(value):
						button.clicked.connect(partial(commands.spindle_override_preset, parent, i, int(value)))
					else: # verified
						title = 'Configuration Error'
						msg = (f'The spindle override preset button named "{item}" with the '
						f'button text of "{button.text()}" "{value}" did not evaluate to an '
						'integer.')
						info = 'The button will be disabled.'
						dialogs.error_msg_ok(parent, title, msg, info)
						button.setText('Error!')
						getattr(parent, item).setEnabled(False)
				else: # verified
					title = 'Configuration Error'
					msg = (f'The spindle override preset "{item}" is '
					'more than the number of spindles')
					info = 'The pushbutton will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, item).setEnabled(False)

	##### End of Multi Spindles #####

	##### Old Style Spindle Controls #####
	# test if new style and old style exist

	if 'spindle_speed_sl' in parent.child_names: # verified
		if 'spindle_speed_0_sl' in parent.child_names:
			title = 'Configuration Error'
			msg = ('The old style "spindle_speed_sl" was found and the new style '
			'"spindle_speed_0_sl" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.spindle_speed_sl.setEnabled(False)
		else: # only the old style is present
			min_rpm = parent.spindle_0_min_fwd_rpm
			max_rpm = parent.spindle_0_max_fwd_rpm
			parent.spindle_speed_sl.blockSignals(True)
			parent.spindle_speed_sl.setRange(min_rpm, max_rpm)
			parent.spindle_speed_sl.setValue(parent.spindle_rpm_0)
			parent.spindle_speed_sl.blockSignals(False)
			parent.spindle_speed_sl.valueChanged.connect(partial(
			commands.spindle_control, parent, 0, 'speed'))

	if 'spindle_fwd_pb' in parent.child_names: # verified
		if 'spindle_fwd_0_pb' in parent.child_names:
			title = 'Configuration Error'
			msg = ('The old style "spindle_fwd_pb" was found and the new style '
			'"spindle_fwd_0_pb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.spindle_fwd_pb.setEnabled(False)
		else: # only the old style is present
			parent.spindle_fwd_pb.clicked.connect(partial(commands.spindle_control, parent, 0, 'fwd'))
			parent.spindle_controls.append('spindle_fwd_pb')

	if 'spindle_rev_pb' in parent.child_names: # verified
		if 'spindle_rev_0_pb' in parent.child_names:
			title = 'Configuration Error'
			msg = ('The old style "spindle_rev_pb" was found and the new style '
			'"spindle_rev_0_pb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.spindle_rev_pb.setEnabled(False)
		else: # only the old style is present
			parent.spindle_rev_pb.clicked.connect(partial(commands.spindle_control, parent, 0, 'rev'))
			parent.spindle_controls.append('spindle_rev_pb')

	if 'spindle_stop_pb' in parent.child_names: # verified
		if 'spindle_stop_0_pb' in parent.child_names:
			parent.spindle_stop_pb.setEnabled(False)
			title = 'Configuration Error'
			msg = ('The old style "spindle_stop_pb" was found and the new style '
			'"spindle_stop_0_pb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
		else: # only the old style is present
			parent.spindle_stop_pb.clicked.connect(partial(commands.spindle_control, parent, 0, 'stop'))
			parent.spindle_controls.append('spindle_stop_pb')

	if 'spindle_plus_pb' in parent.child_names: # verified
		if 'spindle_plus_0_pb' in parent.child_names:
			title = 'Configuration Error'
			msg = ('The old style "spindle_plus_pb" was found and the new style '
			'"spindle_plus_0_pb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.spindle_plus_pb.setEnabled(False)
		else: # only the old style is present
			parent.spindle_plus_pb.clicked.connect(partial(commands.spindle_control, parent, 0, 'plus'))
			parent.spindle_controls.append('spindle_plus_pb')

	if 'spindle_minus_pb' in parent.child_names: # verified
		if 'spindle_minus_0_pb' in parent.child_names:
			title = 'Configuration Error'
			msg = ('The old style "spindle_minus_pb" was found and the new style '
			'"spindle_minus_0_pb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.spindle_minus_pb.setEnabled(False)
		else: # only the old style is present
			parent.spindle_minus_pb.clicked.connect(partial(commands.spindle_control, parent, 0, 'minus'))
			parent.spindle_controls.append('spindle_minus_pb')

	if 'spindle_override_sl' in parent.child_names: # verified
		if 'spindle_override_0_sl' in parent.child_names:
			parent.spindle_override_sl.setEnabled(False)
			title = 'Configuration Error'
			msg = ('The old style "spindle_override_sl" was foundand the new style '
			'"spindle_override_0_sl" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
		else: # only the old style is present
			parent.spindle_override_sl.valueChanged.connect(partial(
				commands.spindle_override, parent, 0))
			parent.spindle_override_sl.blockSignals(True)
			parent.spindle_override_sl.setMinimum(parent.spindle_0_min_override)
			parent.spindle_override_sl.setMaximum(parent.spindle_0_max_override)
			parent.spindle_override_sl.setValue(100)
			parent.spindle_override_sl.blockSignals(False)

	if 'spindle_speed_sb' in parent.child_names: # verified
		if 'spindle_speed_0_sb' in parent.child_names:
			parent.spindle_speed_sb.setEnabled(False)
			title = 'Configuration Error'
			msg = ('The old style "spindle_speed_sb" was found and the new style '
			'"spindle_speed_0_sb" was found.')
			info = 'The old style will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
		else: # only the old style is present
			parent.spindle_speed_sb.valueChanged.connect(partial(commands.spindle_control, parent, 0, 'speed'))
			parent.spindle_speed_sb.blockSignals(True)
			parent.spindle_speed_sb.setSingleStep(parent.spindle_0_rpm_increment)
			parent.spindle_speed_sb.setMinimum(parent.spindle_0_min_fwd_rpm)
			parent.spindle_speed_sb.setMaximum(parent.spindle_0_max_fwd_rpm)
			parent.spindle_speed_sb.setValue(parent.spindle_rpm_0)
			parent.spindle_speed_sb.blockSignals(False)

	# override preset buttons for Spindle 0 spindle_percent_100
	for item in parent.child_names:
		if item.startswith('spindle_percent_') and len(item.split('_')) == 3:
			button = getattr(parent, item)
			value = item.split('_')[-1]
			if utilities.is_int(value):
				button.clicked.connect(partial(commands.spindle_override_preset, parent, 0, int(value)))
			else: # verified
				title = 'Configuration Error'
				msg = (f'The button named "{item}" with the button text of '
				f'{button.text()}" "{value}" did not evaluate to an integer.')
				info = 'The button will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				button.setText('Error!')
				getattr(parent, item).setEnabled(False)

def setup_jog_selected(parent):
	parent.axes_group = QButtonGroup()
	for i in range(9):
		if f'axis_select_{i}' in parent.child_names:
			parent.axes_group.addButton(getattr(parent, f'axis_select_{i}'))
	if len(parent.axes_group.buttons()) > 0:
		parent.axes_group.buttons()[0].setChecked(True)
		if 'jog_selected_plus' in parent.child_names:
			parent.jog_selected_plus.pressed.connect(partial(commands.jog_selected, parent))
			parent.jog_selected_plus.released.connect(partial(commands.jog_selected, parent))
		if 'jog_selected_minus' in parent.child_names:
			parent.jog_selected_minus.pressed.connect(partial(commands.jog_selected, parent))
			parent.jog_selected_minus.released.connect(partial(commands.jog_selected, parent))

def setup_touchoff(parent): # touchoff an axis
	# check for required items touchoff_le touchoff_pb_{axis} touchoff_system_cb
	if 'touchoff_le' in parent.child_names:
		parent.touchoff_le.setText('0')
		if parent.touchoff_le.property('input') == 'number': # enable the number pad
			parent.touchoff_le.installEventFilter(parent)
			parent.number_le.append('touchoff_le')

	# setup touch off buttons, source is a QLineEdit for that button
	# source just needs to verify that the QLineEdit exists
	# also need to check to see if the axis is in the configuration
	for axis in AXES:
		item = f'touchoff_pb_{axis}'
		if item in parent.child_names:
			source = getattr(parent, item).property('source')
			if source is None:
				if 'touchoff_le' in parent.child_names: # check for touchoff_le
					getattr(parent, item).clicked.connect(partial(getattr(commands, 'touchoff'), parent))
					parent.axis_touchoff_controls.append(item)
				else: # verified
					title = 'Configuration Error'
					msg = ('The Touchoff Axis button requires a QLineEdit named '
					'touchoff_le or a Dynamic Property named source that '
					'has the name of the QLineEdit to be used.')
					info = f'The "{item}" button will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, item).setEnabled(False)
					getattr(parent, item).setText('Error!')
			else: # property source is found
				if source in parent.child_names:
					getattr(parent, item).clicked.connect(partial(getattr(commands, 'touchoff'), parent))
					parent.axis_touchoff_controls.append(item)
					getattr(parent, source).setText('0')
				else: # verified
					title = 'Configuration Error'
					msg = (f'The Tool Touchoff button source object name "{source}" for '
					f'button "{item}" was not found.')
					info = f'The QPushButton "{item}" will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, item).setEnabled(False)
					getattr(parent, item).setText('Error!')

def setup_tool_change(parent):
	tool_change_required = ['tool_change_pb', 'tool_change_cb']

	# if neither required is present just skip on by
	if set(tool_change_required).isdisjoint(parent.child_names):
		return

	# if either required is present check everything
	if not set(tool_change_required).isdisjoint(parent.child_names):
		# check that both required items are present
		if set(tool_change_required).issubset(parent.child_names):

			# check the tool table has tools
			for tool in parent.status.tool_table[1:]:
				if tool.id > 0:
					break
			else: # verified
				title = 'Configuration Error'
				msg = (f'Tool Change controls were found but no tools were found in the '
				f'tool table "{parent.tool_table}". Tool change controls are disabled '
				'if no tools are in the tool table')
				info = 'Would you like to add one?'
				result = dialogs.warn_msg_yes_no(parent, title, msg, info)
				if result:
					tool_table_file = os.path.join(parent.config_path, parent.tool_table)
					with open(tool_table_file, "w") as file:
						file.write(';\nT1 P1 ;Added by Flex GUI\n')
					# update the tool table
					parent.command.load_tool_table()
					parent.command.wait_complete()
					parent.status.poll()
				else:
					for item in tool_change_required:
						if item in parent.child_names:
							getattr(parent, item).setEnabled(False)
					return

		else:
			missing = ' '.join(list(set(tool_change_required) - set(parent.child_names)))
			found = ' '.join(list(set(tool_change_required) & set(parent.child_names)))
			title = 'Configuration Error'
			msg = ('Tool change requires both the "tool_change_cb" combo box and the '
			f'"tool_change_pb" push button. The "{missing}" item was not found.')
			info = f'The "{found}" item will be disabled!'
			dialogs.error_msg_ok(parent, title, msg, info)
			for item in tool_change_required:
				if item in parent.child_names:
					getattr(parent, item).setEnabled(False)
			return

	# if we get this far everything checks out ok
	parent.tool_change_pb.clicked.connect(partial(commands.tool_change, parent))
	parent.tool_change_controls.append('tool_change_pb')

	# tool change with description
	if parent.tool_change_cb.property('option') == 'description':
		parent.tool_change_cb.addItem('T0: No Tool in Spindle', 0)
		tools = os.path.join(parent.config_path, parent.tool_table)
		with open(tools, 'r') as t:
			tool_list = t.readlines()
		for line in tool_list:
			if line.find('T') >= 0:
				t = line.find('T')
				p = line.find('P')
				tool = line[t:p].strip()
				d = line.find(';')
				if d > 0:
					desc = line[d:]
				else:
					desc = 'No Description'
				number = int(line[t+1:p].strip())
				parent.tool_change_cb.addItem(f'{tool} {desc.strip()}', number)

	elif parent.tool_change_cb.property('prefix') is not None:
		prefix = parent.tool_change_cb.property('prefix')
		tool_len = len(parent.status.tool_table)
		parent.tool_change_cb.addItem(f'{prefix}0', 0)
		for i in range(1, tool_len):
			tool_id = parent.status.tool_table[i][0]
			parent.tool_change_cb.addItem(f'{prefix}{tool_id}', tool_id)

	else:
		tool_len = len(parent.status.tool_table)
		parent.tool_change_cb.addItem('Tool 0', 0)
		for i in range(1, tool_len):
			tool_id = parent.status.tool_table[i][0]
			parent.tool_change_cb.addItem(f'Tool {tool_id}', tool_id)

def setup_tool_change_buttons(parent): # Tool Change Buttons
	# tool change push buttons is a MDI command so power on and all homed
	tool_list = []
	parent.status.poll()
	for tool in parent.status.tool_table:
		if tool.id > 0:
			tool_list.append(tool.id)

	for i in range(100):
		item = f'tool_change_pb_{i}'
		if item in parent.child_names:
			if i == 0 or i in tool_list:
				getattr(parent, item).clicked.connect(partial(commands.tool_change, parent))
				parent.tool_change_controls.append(f'tool_change_pb_{i}')
			else:
				title = 'Configuration Error'
				msg = (f'The tool "{i}" for the tool change button is not in the Tool '
				'Table.')
				info = 'The Tool Change button will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				getattr(parent, item).setEnabled(False)
				getattr(parent, item).setText('Error')

def setup_manual_tool_change(parent):
	if parent.manual_tool_change:
		# verify the hal_manualtoolchange componen is not loaded
		if hal.component_exists('hal_manualtoolchange'):
			title = 'Configuration Error'
			msg = ('The Flex Manual Tool Change can not function with the '
			'"hal_manualtoolchange" component. You must find and remove the '
			'"hal_manualtoolchange" component! See the Docs for more info.')
			info = 'The Flex Manual Tool Change will be disabled!'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.manual_tool_change = False
			return

		# verify these pins are not connected
		tool_change_pins = ['iocontrol.0.tool-prepare', 'iocontrol.0.tool-prepared',
		'iocontrol.0.tool-prep-number', 'iocontrol.0.tool-change']
		for pin_name in tool_change_pins:
			if hal.pin_has_writer(pin_name):
				title = 'Configuration Error'
				msg = (f'The "{pin_name}" is connected in HAL. The Flex Manual Tool '
				'Change uses this pin so it can not be connected. See the Docs for '
				'more info.')
				info = 'The Flex Manual Tool Change will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				parent.manual_tool_change = False
				return

		parent.toolcomp.newpin('number', hal.HAL_S32, hal.HAL_IN)
		parent.toolcomp.newpin('change', hal.HAL_BIT, hal.HAL_IN)
		parent.toolcomp.newpin('changed', hal.HAL_BIT, hal.HAL_OUT)
		parent.toolcomp.ready()
		parent.tool_change = hal.get_value('tool-change.change')

		hal.new_sig('tool-prepare-loopback',hal.HAL_BIT)
		hal.connect('iocontrol.0.tool-prepare','tool-prepare-loopback')
		hal.connect('iocontrol.0.tool-prepared','tool-prepare-loopback')

		hal.new_sig('tool-number',hal.HAL_S32)
		hal.connect('iocontrol.0.tool-prep-number','tool-number')
		hal.connect('tool-change.number','tool-number')

		hal.new_sig('tool-change',hal.HAL_BIT)
		hal.connect('iocontrol.0.tool-change','tool-change')
		hal.connect('tool-change.change','tool-change')

def setup_tool_touchoff(parent):
	if 'tool_touchoff_le' in parent.child_names:
		parent.tool_touchoff_le.setText('0')
		if parent.tool_touchoff_le.property('input') == 'number': # enable the number pad
			parent.tool_touchoff_le.installEventFilter(parent)
			parent.number_le.append('tool_touchoff_le')

def setup_tool_touchoff_selected(parent):
	# Axis style tool touch off
	if 'tool_touchoff_selected_pb' in parent.child_names:
		 # check to see if at least one axis select radio button is there
		for joint in range(9):
			item = f'axis_select_{joint}'
			if item in parent.child_names:
				parent.tool_touchoff_selected_pb.clicked.connect(partial(dialogs.tool_touchoff_selected, parent))
				parent.tool_touchoff_controls.append(item)
				break
		else: # verified
			title = 'Configuration Error'
			msg = ('The "tool_touchoff_selected_pb" was found '
			'but no axis_select radio buttons were found.')
			info = 'The "tool_touchoff_selected_pb" will be disabled!'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.tool_touchoff_selected_pb.setEnabled(False)

def setup_touchoff_selected(parent):
	# setup Axis style touch off buttons
	if 'touchoff_selected_pb' in parent.child_names:
		for i in range(9):
			if f'axis_select_{i}' in parent.child_names:
				parent.touchoff_selected_pb.clicked.connect(partial(dialogs.touchoff_selected, parent))
				parent.axis_touchoff_controls.append('touchoff_selected_pb')
				break
		else: # verified
			title = 'Configuration Error'
			msg = ('The "touchoff_selected_pb" was found '
			'but no axis_select radio buttons were found.')
			info = 'The push button "touchoff_selected_pb" will be disabled.'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.touchoff_selected_pb.setEnabled(False)

	for axis in AXES:
		item = f'tool_touchoff_{axis}'
		if item in parent.child_names:
			source = getattr(parent, item).property('source')
			if source is None: # check for tool_touchoff_le
				if 'tool_touchoff_le' in parent.child_names:
					getattr(parent, item).clicked.connect(partial(getattr(commands, 'tool_touchoff'), parent))
					parent.tool_touchoff_controls.append(item)
				else: # verified
					title = 'Configuration Error'
					msg = ('The Tool Touchoff Button requires the Tool Offset Line Edit '
					'"tool_touchoff_le" or a Dynamic Property named "source" that '
					'has the object name of the Line Edit to be used.')
					info = 'The Tool Touch Off Button will be disabled'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, item).setEnabled(False)
					getattr(parent, item).setText('Error!')
			else: # property source is found
				if source in parent.child_names:
					getattr(parent, item).clicked.connect(partial(getattr(commands, 'tool_touchoff'), parent))
					parent.tool_touchoff_controls.append(item)
				else: # the source was not found # verified
					title = 'Configuration Error'
					msg = (f'The Tool Touch Off line edit "{source}" for "{item}" was not found.')
					info = f'The push button "{item}" will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, item).setEnabled(False)
					getattr(parent, item).setText('Error!')

def setup_sliders(parent):
	if 'feed_override_sl' in parent.child_names:
		parent.feed_override_sl.valueChanged.connect(partial(utilities.feed_override, parent))
		parent.feed_override_sl.blockSignals(True)
		parent.feed_override_sl.setMaximum(int(float(parent.max_feed_override) * 100))
		parent.feed_override_sl.setValue(100)
		parent.feed_override_sl.blockSignals(False)

	if 'rapid_override_sl' in parent.child_names:
		parent.rapid_override_sl.valueChanged.connect(partial(utilities.rapid_override, parent))
		parent.rapid_override_sl.blockSignals(True)
		parent.rapid_override_sl.setMaximum(100)
		parent.rapid_override_sl.setValue(100)
		parent.rapid_override_sl.blockSignals(False)

	if 'max_vel_sl' in parent.child_names:
		if parent.max_linear_vel:
			parent.max_vel_sl.valueChanged.connect(partial(utilities.max_velocity, parent))
			max_units_min = int(float(parent.max_linear_vel) * 60)
			parent.max_vel_sl.blockSignals(True)
			parent.max_vel_sl.setMaximum(max_units_min)
			parent.max_vel_sl.setValue(max_units_min)
			parent.max_vel_sl.blockSignals(False)
		else: # verified
			title = 'Configuration Error'
			msg = ('The [TRAJ] section key MAX_LINEAR_VELOCITY was not found.')
			info = 'The max_linear_vel slider will be disabled\n'
			dialogs.error_msg_ok(parent, title, msg, info)
			parent.max_vel_sl.setEnabled(False)

def setup_overrides(parent): # jog limit switch override checkbox
	if 'override_limits_cb' in parent.child_names:
		parent.override_limits_cb.setEnabled(False)

def setup_defaults(parent):
	if 'optional_stop_pb' in parent.child_names:
		if parent.optional_stop_pb.isChecked():
			parent.command.set_optional_stop(True)
		else:
			parent.command.set_optional_stop(False)

	if parent.open_file and parent.open_file != '""':
		actions.load_file(parent, parent.open_file)

def setup_probing(parent):
	# any object name that starts with probe_ is disabled
	for child in parent.child_names:
		if child.startswith('probe_'):
			if isinstance(parent.findChild(QWidget, child), QPushButton):
				getattr(parent, child).setEnabled(False)
				if 'probing_enable_pb' in parent.child_names:
					parent.probe_controls.append(child)
				else: # verified
					title = 'Configuration Error'
					msg = (f'The Probe Control "{child}" was found but the Probing Enable '
					'Push Button "probing_enable_pb" was not found. Probe controls '
					'require the "probing_enable_pb" to function.')
					info = f'The "{child}" will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					getattr(parent, child).setText('Error!')

	if len(parent.probe_controls) > 0:
		if 'probing_enable_pb' in parent.child_names:
			if not parent.probing_enable_pb.isCheckable():
				parent.probing_enable_pb.setCheckable(True)
			parent.probing_enable_pb.toggled.connect(partial(probe.toggle, parent))
			parent.probe_enable.append('probing_enable_pb')

			on_text = parent.probing_enable_pb.property('on_text')
			off_text = parent.probing_enable_pb.property('off_text')
			if None not in [on_text, off_text]:
				parent.probing_enable_pb.setText(off_text)
			#if parent.probe_enable_off_color:
			#	parent.probing_enable_pb.setStyleSheet(parent.probe_enable_off_color)

def setup_set_var(parent):
	# variables are floats so only put them in a QDoubleSpinBox
	var_file = os.path.join(parent.config_path, parent.var_file)
	with open(var_file, 'r') as f:
		var_list = f.readlines()

	parent.set_var = {}
	for child in parent.findChildren(QDoubleSpinBox):
		if child.property('function') == 'set_var':
			obj_name = child.objectName()
			var = child.property('variable')
			if var not in ['', None]:
				for line in var_list:
					if line.startswith(var):
						child.setValue(float(line.split()[1]))
						found = True
						child.valueChanged.connect(partial(utilities.var_value_changed, parent))
						parent.set_var[obj_name] = var
						parent.homed_controls.append(obj_name)
						break
				else: # verified
					title = 'Configuration Error'
					msg = (f'The set parameter Dynamic Property "variable" "{var}" for '
					f'"{obj_name}" was not found in the parameters file '
					f'"{parent.var_file}".')
					info = f'The "{obj_name}"" will be disabled'
					dialogs.error_msg_ok(parent, title, msg, info)
					child.setEnabled(False)
			else: # verified
				title = 'Configuration Error'
				msg = (f'The set parameter Dynamic Property "variable" for '
				f'"{obj_name}" was not found or it is blank.')
				info = f'The "{obj_name}" will be disabled'
				dialogs.error_msg_ok(parent, title, msg, info)
				child.setEnabled(False)

def setup_watch_var(parent):
	parent.watch_var = {}
	for child in parent.findChildren(QLabel):
		if child.property('function') == 'watch_var':
			var = child.property('variable')
			prec = child.property('precision')
			prec = prec if prec is not None else 6
			obj_name = child.objectName()
			parent.watch_var[obj_name] = [var, prec]

	if len(parent.watch_var) > 0: # update the labels
		var_file = os.path.join(parent.config_path, parent.var_file)
		with open(var_file, 'r') as f:
			var_list = f.readlines()
		for key, value in parent.watch_var.items():
			for line in var_list:
				if line.startswith(value[0]):
					getattr(parent, key).setText(f'{float(line.split()[1]):.{value[1]}f}')

def setup_hal(parent):
	hal_labels = []
	hal_avr_f_labels = [] # average float labels
	hal_avr_i_labels = [] # average int labels
	hal_ms_labels = [] # multi state labels
	hal_buttons = []
	hal_spinboxes = []
	hal_dbl_spinboxes = []
	hal_sliders = []
	hal_lcds = []
	hal_progressbar = []
	parent.hal_io_check = {}
	parent.hal_io_int = {}
	parent.hal_io_float = {}
	parent.hal_avr_float = {}
	parent.hal_avr_int = {}
	parent.hal_readers = {}
	parent.hal_ms_labels = {}
	parent.hal_bool_labels = {}
	parent.hal_integer_labels = {}
	parent.hal_float_labels = {}
	parent.hal_float_lcds = {}
	parent.hal_progressbars = {}

	var_file = os.path.join(parent.config_path, parent.var_file)
	with open(var_file, 'r') as f:
		var_list = f.readlines()

	##### HAL LED #####
	# These are not QLabel but Indicator
	# All validity checks are done when the Indicator is created
	for label in parent.findChildren(Indicator):
		if label.property('function') == 'hal_led':
			pin_name = label.property('pin_name')
			hal_type = getattr(hal, 'HAL_BIT')
			hal_dir = getattr(hal, f'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))

	##### HAL_LED_LABELS #####
	# These are not QLabel but IndicatorLabel
	# All validity checks are done when the IndicatorLabel is created
	for label in parent.findChildren(IndicatorLabel):
		if label.property('function') == 'hal_led_label':
			pin_name = label.property('pin_name')
			hal_type = getattr(hal, 'HAL_BIT')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))

	##### HAL_LED_BUTTONS ##### 
	# these are not QPushButtons but LEDButton
	# All validity checks are done when the LEDButton is created
	for button in parent.findChildren(LEDButton):

		if button.property('function') == 'hal_led_button':
			pin_name = button.property('pin_name')
			hal_type = getattr(hal, 'HAL_BIT')
			hal_dir = getattr(hal, 'HAL_OUT')

			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			pin = getattr(parent, f'{pin_name}')

			if button.isCheckable():
				button.toggled.connect(lambda checked, pin=pin: (pin.set(checked)))
				# set the hal pin default
				setattr(parent.halcomp, pin_name, button.isChecked())
			else:
				button.pressed.connect(lambda pin=pin: (pin.set(True)))
				button.released.connect(lambda pin=pin: (pin.set(False)))

			set_hal_enables(parent, button)

	##### HAL_IO #####
	io_errors = {}
	for child in parent.findChildren(QWidget):
		if not isdeleted(child):  
			if child.property('function') == 'hal_io':
				obj_name = child.objectName()
				pin_name = child.property('pin_name')

				if pin_name in [None, '']: # verified
					title = 'Configuration Error'
					msg = (f'The HAL I/O "{obj_name}" pin name is blank or missing '
					'The HAL pin can not be created.')
					info = f'The HAL I/O "{obj_name}" will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					child.setEnabled(False)
					continue

				if pin_name in dir(parent): # verified
					title = 'Configuration Error'
					msg = (f'HAL I/O "{obj_name}" pin name "{pin_name}" is already used '
					'in Flex GUI. The HAL pin can not be created.')
					info = f'The HAL I/O "{obj_name}" will be disabled.'
					dialogs.error_msg_ok(parent, title, msg, info)
					child.setEnabled(False)
					continue

				if isinstance(child, QCheckBox):
					setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal.HAL_BIT, hal.HAL_IO))
					child.stateChanged.connect(partial(utilities.update_hal_io, parent))
					parent.hal_io_check[obj_name] = pin_name

				elif isinstance(child, QPushButton):
					if child.isCheckable():
						setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal.HAL_BIT, hal.HAL_IO))
						child.toggled.connect(partial(utilities.update_hal_io, parent))
						parent.hal_io_check[obj_name] = pin_name
					else: # verified
						title = 'Configuration Error'
						msg = (f'The push button "{obj_name}" must be '
						'set to checkable to be a I/O button.')
						info = 'The push button will be disabled.'
						dialogs.error_msg_ok(parent, title, msg, info)
						child.setEnabled(False)
						child.setText('Error!')
						continue

				elif isinstance(child, QRadioButton):
					setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal.HAL_BIT, hal.HAL_IO))
					child.toggled.connect(partial(utilities.update_hal_io, parent))
					parent.hal_io_check[obj_name] = pin_name

				elif isinstance(child, QSpinBox) or isinstance(child, QSlider):
					hal_type = child.property('hal_type')
					if hal_type in ['HAL_S32', 'HAL_U32']:
						hal_type = getattr(hal, f'{hal_type}')
						setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal.HAL_IO))
						child.valueChanged.connect(partial(utilities.update_hal_io, parent))
						parent.hal_io_int[obj_name] = pin_name
					else:
						child.setEnabled(False)
						if isinstance(child, QSpinBox):
							obj_type = 'QSpinBox'
						else: # verified
							obj_type = 'QSlider'
						title = 'Configuration Error'
						msg = (f'The "{obj_type}" "{obj_name}" hal_type must be HAL_S32 or '
						'HAL_U32.')
						info = f'The "{obj_type}" will be disabled'
						dialogs.error_msg_ok(parent, title, msg, info)
						continue

				elif isinstance(child, QDoubleSpinBox):
					setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal.HAL_FLOAT, hal.HAL_IO))
					child.valueChanged.connect(partial(utilities.update_hal_io, parent))
					parent.hal_io_float[obj_name] = pin_name

				set_hal_enables(parent, child)

	for key, value in io_errors.items():
		dialogs.error_msg_ok(parent, value, 'Error')

	for child in parent.findChildren(QWidget):
		if child.property('function') == 'hal_pin':
			if isinstance(child, QAbstractButton): # QCheckBox, QPushButton, QRadioButton, and QToolButton
				hal_buttons.append(child)
			elif isinstance(child, QSpinBox):
				hal_spinboxes.append(child)
			elif isinstance(child, QDoubleSpinBox):
				hal_dbl_spinboxes.append(child)
			elif isinstance(child, QSlider):
				hal_sliders.append(child)
			elif isinstance(child, QLabel):
				hal_labels.append(child)
			elif isinstance(child, QProgressBar):
				hal_progressbar.append(child)
			elif isinstance(child, QLCDNumber):
				hal_lcds.append(child)
		elif child.property('function') == 'hal_avr_f':
			if isinstance(child, QLabel):
				hal_avr_f_labels.append(child)
		elif child.property('function') == 'hal_avr_i':
			if isinstance(child, QLabel):
				hal_avr_i_labels.append(child)
		elif child.property('function') == 'hal_msl':
			if isinstance(child, QLabel):
				hal_ms_labels.append(child)

	##### HAL BUTTON & CHECKBOX & RADIO BUTTON #####
	if len(hal_buttons) > 0:
		for button in hal_buttons:
			obj_name = button.objectName()
			pin_name = button.property('pin_name')
			state_off = button.property('state_off')
			home_required = button.property('required')
			if isinstance(button, QPushButton) or isinstance(button, QCheckBox):
				confirm = button.property('confirm')
			else:
				confirm = False

			controls = ['open_pb', 'edit_pb', 'reload_pb', 'edit_tool_table_pb',
			'edit_ladder_pb', 'reload_tool_table_pb', 'save_pb', 'save_as_pb',
			'quit_pb', 'estop_pb', 'power_pb', 'run_pb', 'run_from_line_pb',
			'step_pb', 'pause_pb', 'resume_pb', 'stop_pb', 'home_all_pb',
			'unhome_all_pb', 'manual_mode_pb', 'flood_pb', 'mist_pb',
			'clear_errors_pb', 'copy_errors_pb', 'clear_info_pb', 'show_hal_pb',
			'hal_meter_pb', 'hal_scope_pb', 'about_pb', 'quick_reference_pb']
			for i in range(9):
				controls.append(f'home_pb_{i}')
				controls.append(f'unhome_pb_{i}')
			for axis in AXES:
				controls.append(f'clear_{axis}_pb')
			if obj_name in controls: # verified
				title = 'Configuration Error'
				msg = (f'The control "{obj_name}" can not be a HAL pin.')
				info = 'The HAL pin will not be created!'
				dialogs.error_msg_ok(parent, title, msg, info)
				continue

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Button "{obj_name}" with the text "{button.text()}" '
				f'pin name is blank or missing The HAL pin can not be created.')
				info = f'The button "{obj_name}" will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				button.setEnabled(False)
				button.setText('Error !')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'The HAL button "{obj_name}" with the pin name "{pin_name}" '
				'is already used in Flex GUI. The HAL pin can not be created.')
				info = f'The button "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				button.setEnabled(False)
				button.setText('Error !')
				continue

			hal_type = getattr(hal, 'HAL_BIT')
			hal_dir = getattr(hal, 'HAL_OUT')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			pin = getattr(parent, f'{pin_name}')

			if button.isCheckable() and not confirm:
				button.toggled.connect(lambda checked, pin=pin: (pin.set(checked)))
				# set the hal pin default
				setattr(parent.halcomp, pin_name, button.isChecked())
			elif button.isCheckable() and confirm:
				button.toggled.connect(partial(utilities.hal_confirm, parent))
			else:
				button.pressed.connect(lambda pin=pin: (pin.set(True)))
				button.released.connect(lambda pin=pin: (pin.set(False)))

			set_hal_enables(parent, button)

	##### HAL SPINBOX #####
	if len(hal_spinboxes) > 0:
		valid_types = ['HAL_S32', 'HAL_U32']
		for spinbox in hal_spinboxes:
			obj_name = spinbox.objectName()
			pin_name = spinbox.property('pin_name')
			hal_type = spinbox.property('hal_type')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL Spinbox "{obj_name}" pin name is blank or missing '
				'The HAL pin can not be created.')
				info = f'The spinbox "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				spinbox.setEnabled(False)
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Spinbox "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI The HAL pin can not be created.')
				info = f'The spinbox "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				spinbox.setEnabled(False)
				continue

			if hal_type not in valid_types: # verified
				title = 'Configuration Error'
				msg = (f'The HAL type "{hal_type}" is not valid for a HAL spinbox, '
				'only HAL_S32 or HAL_U32 are valid for a HAL Spinbox')
				info = f'The "{obj_name}" spinbox will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				spinbox.setEnabled(False)
				continue

			hal_type = getattr(hal, f'{hal_type}')
			hal_dir = getattr(hal, 'HAL_OUT')
			parent.halcomp.newpin(pin_name, hal_type, hal_dir)
			# set the default value of the spin box to the hal pin
			setattr(parent.halcomp, pin_name, spinbox.value())
			spinbox.valueChanged.connect(partial(utilities.update_hal_spinbox, parent))

			set_hal_enables(parent, spinbox)

	##### HAL Double Spinboxes #####
	if len(hal_dbl_spinboxes) > 0:
		for spinbox in hal_dbl_spinboxes:
			obj_name = spinbox.objectName()
			pin_name = spinbox.property('pin_name')

			if pin_name in [None, '']: # verified
				spinbox.setEnabled(False)
				title = 'Configuration Error'
				msg = (f'The HAL Double Spinbox "{obj_name}" pin name is blank or '
				'missing. The HAL pin can not be created.')
				info = f'The spinbox "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				continue

			if pin_name in dir(parent): # verified
				spinbox.setEnabled(False)
				title = 'Configuration Error'
				msg = (f'The HAL Double Spinbox "{obj_name}" pin name "{pin_name}" is '
				'already  used in Flex GUI. The HAL pin can not be created.')
				info = f'The spinbox "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				continue

			hal_type = getattr(hal, 'HAL_FLOAT')
			hal_dir = getattr(hal, 'HAL_OUT')
			parent.halcomp.newpin(pin_name, hal_type, hal_dir)
			# set the default value of the spin box to the hal pin
			setattr(parent.halcomp, pin_name, spinbox.value())
			spinbox.valueChanged.connect(partial(utilities.update_hal_spinbox, parent))

			set_hal_enables(parent, spinbox)

	##### HAL SLIDERS #####
	if len(hal_sliders) > 0:
		valid_types = ['HAL_S32', 'HAL_U32']
		for slider in hal_sliders:
			obj_name = slider.objectName()
			pin_name = slider.property('pin_name')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL SLIDER "{obj_name}" pin name is blank or missing.'
				'The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				slider.setEnabled(False)
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Slider "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI. The HAL pin can not be created.')
				info = f'The slider "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				slider.setEnabled(False)
				continue

			hal_type = slider.property('hal_type')
			if hal_type not in valid_types: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Type "{hal_type}" is not valid for a HAL slider, only '
				'HAL_S32 or HAL_U32 are valid HAL Types for a slider')
				info = f'The slider "{obj_name}" will be disabled.\n'
				dialogs.error_msg_ok(parent, title, msg, info)
				slider.setEnabled(False)
				continue

			hal_type = getattr(hal, f'{hal_type}')
			hal_dir = getattr(hal, 'HAL_OUT')
			parent.halcomp.newpin(pin_name, hal_type, hal_dir)
			# set the default value of the spin box to the hal pin
			setattr(parent.halcomp, pin_name, slider.value())
			slider.valueChanged.connect(partial(utilities.update_hal_slider, parent))

			set_hal_enables(parent, slider)

	##### HAL LCD #####
	if len(hal_lcds) > 0:
		valid_types = ['HAL_FLOAT', 'HAL_S32', 'HAL_U32']
		for lcd in hal_lcds:
			obj_name = lcd.objectName()
			pin_name = lcd.property('pin_name')
			hal_type = lcd.property('hal_type')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL LCD "{obj_name}" pin name is blank or missing.'
				'The HAL pin can not be created.')
				info = f'The HAL LCD "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				lcd.setEnabled(False)
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL LCD "{obj_name}" pin name "{pin_name}" is already used '
				'in Flex GUI. The HAL pin can not be created.')
				info = f'The HAL LCD "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				lcd.setEnabled(False)
				continue

			if hal_type not in valid_types: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Type "{hal_type}" is not a valid type for a HAL LCD, '
				'only HAL_FLOAT or HAL_S32 or HAL_U32 can be used.')
				info = f'The HAL LCD "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				lcd.setEnabled(False)
				continue

			hal_type = getattr(hal, f'{hal_type}')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			# if hal type is float add it to hal_float with precision
			if hal_type == 2: # HAL_FLOAT
				p = lcd.property('precision')
				p = p if p is not None else parent.default_precision
				parent.hal_float_lcds[f'{obj_name}'] = [pin_name, p] # lcd ,status item, precision
			else:
				integer_digits = lcd.property('integer_digits')
				parent.hal_readers[obj_name] = [pin_name, integer_digits]

	##### HAL LABEL #####
	if len(hal_labels) > 0:
		valid_types = ['HAL_BIT', 'HAL_FLOAT', 'HAL_S32', 'HAL_U32']
		for label in hal_labels:
			obj_name = label.objectName()
			pin_name = label.property('pin_name')
			hal_type = label.property('hal_type')
			true_text = label.property('true_text')
			false_text = label.property('false_text')
			hal_dir = getattr(hal, 'HAL_IN')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'The HAL LABEL "{obj_name}" pin name is blank or missing '
				'The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			# the pin_name can not be the same as a built in variable or object name
			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Label "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			if hal_type not in valid_types: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Type "{hal_type}" is not valid type for a HAL Label. '
				'Valid types are HAL_BIT, HAL_FLOAT, HAL_S32 or HAL_U32.')
				info = f'The "{obj_name}" label will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			##### HAL BIT Label #####
			if hal_type == 'HAL_BIT':
				if true_text is None or true_text.strip() == '':
					true_text = 'True'
				if false_text is None or false_text.strip() == '':
					false_text = 'False'
				parent.hal_bool_labels[obj_name] = [pin_name, true_text, false_text]
				hal_type = getattr(hal, 'HAL_BIT')
				setattr(parent, pin_name, parent.halcomp.newpin(pin_name, hal_type, hal_dir))
				continue

			##### HAL S32/U32 Label #####
			if hal_type in ['HAL_S32', 'HAL_U32']:
				if label.property('integer_digits'): # verified
					title = 'Configuration Error'
					msg = ('The Dynamic Property "integer_digits" has been replaced with '
					'"zero_padding" which better describes what the property is for.')
					info = 'The "integer_digits" is no longer used.'
					dialogs.error_msg_ok(parent, title, msg, info)
				zero_padding = label.property('zero_padding')
				if zero_padding in [None, '']:
					zero_padding = 00
				parent.hal_integer_labels[obj_name] = [pin_name, zero_padding]
				hal_type = getattr(hal, hal_type)
				setattr(parent, pin_name, parent.halcomp.newpin(pin_name, hal_type, hal_dir))
				continue

			##### HAL FLOAT Label #####
			if hal_type == 'HAL_FLOAT':
				p = label.property('precision')
				p = p if p is not None else parent.default_precision
				parent.hal_float_labels[obj_name] = [pin_name, p] # label ,status item, precision
				hal_type = getattr(hal, 'HAL_FLOAT')
				setattr(parent, pin_name, parent.halcomp.newpin(pin_name, hal_type, hal_dir))

	##### HAL AVERAGE FLOAT LABEL #####
	if len(hal_avr_f_labels) > 0:
		for label in hal_avr_f_labels:
			obj_name = label.objectName()
			pin_name = label.property('pin_name')
			s = label.property('samples') or 10
			r = label.property('rounding') or 0
			if r > 0:
				r = -r

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL Average Float Label "{obj_name}" pin name is blank or '
				'missing. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Average Float Label "{obj_name}" pin name "{pin_name}" '
				'is already used in Flex GUI. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			hal_type = getattr(hal, 'HAL_FLOAT')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))

			p = label.property('precision')
			p = p if p is not None else parent.default_precision

			parent.hal_avr_float[obj_name] = [pin_name, deque([0], maxlen=s), p, r]

	##### HAL AVERAGE INT LABEL #####
	if len(hal_avr_i_labels) > 0:
		valid_types = ['HAL_S32', 'HAL_U32']
		for label in hal_avr_i_labels:
			obj_name = label.objectName()
			pin_name = label.property('pin_name')
			s = label.property('samples') or 10

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL Average Integer Label "{obj_name}" pin name is blank or '
				'missing The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Average Integer Label "{obj_name}" pin name "{pin_name}" '
				'is already used in Flex GUI. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			hal_type = label.property('hal_type')
			if hal_type not in valid_types: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Type "{hal_type}" is not valid for a HAL Average '
				'Integer Label, only HAL_S32 or HAL_U32 can be used.')
				info = f'The "{obj_name}" label will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			hal_type = getattr(hal, f'{hal_type}')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			parent.hal_avr_int[obj_name] = [pin_name, deque([0], maxlen=s)]

	##### HAL MULTI STATE LABEL #####
	if len(hal_ms_labels) > 0:
		for label in hal_ms_labels:
			obj_name = label.objectName()
			pin_name = label.property('pin_name')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL Multi State Label "{obj_name}" pin name is blank or '
				'missing. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL Multi-State Label "{obj_name}" pin name "{pin_name}" '
				'is already used in Flex GUI. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			hal_type = getattr(hal, 'HAL_U32')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}"', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			# 1. Get the list of all dynamic property names (as QByteArray)
			prop_names = label.dynamicPropertyNames()
			# 2. Iterate through them, decode, and fetch values
			dynamic_props = {}
			for name in prop_names:
				prop_name = name.data().decode("utf-8")
				prop_value = label.property(prop_name)
				# Store in a dictionary
				dynamic_props[prop_name] = prop_value
			text_dict = {}

			# test for at least one key
			if not any(key.startswith('text_') for key in dynamic_props.keys()):
				title = 'Configuration Error'
				msg = (f'The HAL Multi State Label requires at least one Dynamic '
				'Property that starts with "text_".')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setEnabled(False)
				label.setText('Error!')
				continue

			for key, value in dynamic_props.items():
				if key.startswith('text_'):
					num = key.split('_')[-1]
					if utilities.is_int(num):
						text_dict[int(num)] = value
					else: # verified
						title = 'Configuration Error'
						msg = (f'HAL Multi State Label "{obj_name}" Dynamic Property '
						f'"{key}" suffix "{num}" did not evaluate to an integer. The HAL '
						'pin can not be created.')
						info = f'The "{obj_name}" will be disabled.'
						dialogs.error_msg_ok(parent, title, msg, info)
						label.setEnabled(False)
						label.setText('Error!')
						continue

			parent.hal_ms_labels[obj_name] = [pin_name, text_dict]

	##### HAL PROGRESSBAR #####
	if len(hal_progressbar) > 0:
		for progressbar in hal_progressbar:
			obj_name = progressbar.objectName()
			pin_name = progressbar.property('pin_name')

			if pin_name in [None, '']: # verified
				title = 'Configuration Error'
				msg = (f'HAL PROGRESSBAR "{obj_name}" pin name is blank or missing. '
				'The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				progressbar.setEnabled(False)
				continue

			if pin_name in dir(parent): # verified
				title = 'Configuration Error'
				msg = (f'HAL PROGRESSBAR "{obj_name}" pin name "{pin_name}" is already '
				'used in Flex GUI. The HAL pin can not be created.')
				info = f'The "{obj_name}" will be disabled.'
				dialogs.error_msg_ok(parent, title, msg, info)
				progressbar.setEnabled(False)
				continue

			hal_type = getattr(hal, 'HAL_U32')
			hal_dir = getattr(hal, 'HAL_IN')
			setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
			parent.hal_progressbars[obj_name] = pin_name

	##### HAL TOOL CHANGE #####
	#setattr(parent, f'{pin_name}', parent.halcomp.newpin(pin_name, hal_type, hal_dir))
	setattr(parent, 'tc_ok', parent.halcomp.newpin('tc-ok', hal.HAL_BIT, hal.HAL_IN))
	#parent.tc_ok = parent.halcomp.newpin("my-callback-pin", hal.HAL_BIT, hal.HAL_IN)
	# Wrap the pin with hal_glib to enable signals
	parent.pin_watcher = hal_glib.GPin(parent.tc_ok)

	parent.halcomp.ready()
	if 'hal_comp_name_lb' in parent.child_names:
		parent.hal_comp_name_lb.setText(f'{parent.halcomp}')

def setup_hal_io_state(parent):
	# key is the object name value is the hal pin name
	for key, value in parent.hal_io_check.items():
		checked_state = getattr(parent, key).isChecked()
		hal_state = getattr(parent.halcomp, value)
		if checked_state != hal_state:
			setattr(parent.halcomp, value, checked_state)

	for key, value in parent.hal_io_int.items():
		obj_value = getattr(parent, key).value()
		hal_value = getattr(parent.halcomp, value)
		if obj_value != hal_value:
			setattr(parent.halcomp, value, obj_value)

	for key, value in parent.hal_io_float.items():
		obj_value = getattr(parent, key).value()
		hal_value = getattr(parent.halcomp, value)
		if obj_value != hal_value:
			setattr(parent.halcomp, value, obj_value)

def setup_hal_watch(parent):
	parent.hal_watch_bit = {}
	parent.hal_watch_int = {}
	parent.hal_watch_float = {}
	parent.hal_watch_time_hm = {}
	parent.hal_watch_time_hms = {}

	for label in parent.findChildren(QLabel):
		if label.property('function') == 'hal_watch_bit':
			obj_name = label.objectName()
			pin = label.property('pin_name')
			try:
				hal.get_value(pin)
				parent.hal_watch_bit[obj_name] = pin
			except Exception: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Watch Label "{obj_name}" HAL pin "{pin}" was not '
				'found.')
				info = 'The Label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setText('Error!')
				label.setEnabled(False)

		elif label.property('function') == 'hal_watch_int':
			obj_name = label.objectName()
			pin = label.property('pin_name')
			try:
				hal.get_value(pin)
				parent.hal_watch_int[obj_name] = pin
			except Exception: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Watch Label "{obj_name}" HAL pin "{pin}" was not '
				'found.')
				info = 'The Label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setText('Error!')
				label.setEnabled(False)

		elif label.property('function') == 'hal_watch_float':
			obj_name = label.objectName()
			pin = label.property('pin_name')
			p = label.property('precision')
			p = p if p is not None else parent.default_precision
			try:
				hal.get_value(pin)
				parent.hal_watch_float[obj_name] = [pin, p]
			except Exception: # verified
				title = 'Configuration Error'
				msg = (f'The HAL Watch Label "{obj_name}" HAL pin "{pin}" was not '
				'found.')
				info = 'The Label will be disabled!'
				dialogs.error_msg_ok(parent, title, msg, info)
				label.setText('Error!')
				label.setEnabled(False)

		elif label.property('function') == 'hal_watch_time_hm':
			obj_name = label.objectName()
			hr_pin = label.property('hours')
			min_pin = label.property('minutes')
			test = False
			for pin in [hr_pin, min_pin]:
				try:
					hal.get_value(pin)
					test = True
				except Exception: # verified
					title = 'Configuration Error'
					msg = (f'The HAL Watch Label "{obj_name}" HAL pin "{pin}" was '
					'not found.')
					info = 'The Label will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					test = False
					label.setText('Error!')
					label.setEnabled(False)
					break

			if test:
				parent.hal_watch_time_hm[obj_name] = [hr_pin, min_pin]

		elif label.property('function') == 'hal_watch_time_hms':
			obj_name = label.objectName()
			hr_pin = label.property('hours')
			min_pin = label.property('minutes')
			sec_pin = label.property('seconds')
			test = False
			for pin in [hr_pin, min_pin, sec_pin]:
				try:
					hal.get_value(pin)
					test = True
				except Exception: # verified
					title = 'Configuration Error'
					msg = (f'The HAL Watch Label "{obj_name}" HAL pin "{pin}" was '
					'not found.')
					info = 'The Label will be disabled!'
					dialogs.error_msg_ok(parent, title, msg, info)
					test = False
					label.setText('Error!')
					label.setEnabled(False)
					break

			if test:
				parent.hal_watch_time_hms[obj_name] = [hr_pin, min_pin, sec_pin]

def setup_toolbar(parent):
	if 'flex_E_Stop' in parent.child_names:
		parent.flex_E_Stop.setStyleSheet(parent.selected_style)

def setup_plot(parent):
	if 'plot_widget' in parent.child_names:
		# add the plotter to the container
		from libflexgui import flexplot
		parent.plotter = flexplot.emc_plot(parent)
		layout = QVBoxLayout(parent.plot_widget)
		layout.addWidget(parent.plotter)

		parent.plotter._font = f'monospace bold {parent.dro_font_size}'

		if parent.plot_background_color:
			parent.plotter.background_color = parent.plot_background_color

		# set view in plotter to default view
		parent.plotter.current_view = parent.default_view

		# set view push button for current view selected
		match parent.default_view:
			case 'p' if 'flex_View_P' in parent.child_names:
				parent.flex_View_P.setStyleSheet(parent.selected_style)
			case 'x' if 'flex_View_X' in parent.child_names:
				parent.flex_View_X.setStyleSheet(parent.selected_style)
			case 'y' if 'flex_View_Y' in parent.child_names:
				parent.flex_View_Y.setStyleSheet(parent.selected_style)
			case 'y2' if 'flex_View_Y2' in parent.child_names:
				parent.flex_View_Y2.setStyleSheet(parent.selected_style)
			case 'z' if 'flex_View_Z' in parent.child_names:
				parent.flex_View_Z.setStyleSheet(parent.selected_style)
			case 'z2' if 'flex_View_Z2' in parent.child_names:
				parent.flex_View_Z2.setStyleSheet(parent.selected_style)

		#key object name, value[0] function, value[1] plot function
		plot_actions = {
		'actionDRO': ['action_toggle_dro', 'enable_dro'],
		'actionLimits': ['action_toggle_limits', 'show_limits'],
		'actionExtents_Option': ['action_toggle_extents_option', 'show_extents_option'],
		'actionLive_Plot': ['action_toggle_live_plot', 'show_live_plot'],
		'actionVelocity': ['action_toggle_velocity', 'show_velocity'],
		'actionMetric_Units': ['action_toggle_metric_units', 'metric_units'],
		'actionProgram': ['action_toggle_program', 'show_program'],
		'actionRapids': ['action_toggle_rapids', 'show_rapids'],
		'actionTool': ['action_toggle_tool', 'show_tool'],
		'actionLathe_Radius': ['action_toggle_lathe_radius', 'show_lathe_radius'],
		'actionDTG': ['action_toggle_dtg', 'show_dtg'],
		'actionOffsets': ['action_toggle_offsets', 'show_offsets'],
		'actionOverlay': ['action_toggle_overlay', 'show_overlay']
		}

		for key, value in plot_actions.items():
			if key in parent.child_names:
				getattr(parent, f'{key}').triggered.connect(partial(getattr(actions, f'{value[0]}'), parent))
				getattr(parent, key).setCheckable(True)
				if parent.settings.contains(f'PLOT/{key}'):
					state = True if parent.settings.value(f'PLOT/{key}') == 'true' else False
				else: # add it and set to default
					state = getattr(parent.plotter, value[1])
					parent.settings.beginGroup('PLOT')
					parent.settings.setValue(key, state)
					parent.settings.endGroup()
				getattr(parent, key).setChecked(state)
				setattr(parent.plotter, value[1], state)

		view_checkboxes = {
			'view_dro_cb': ['action_toggle_dro', 'enable_dro'],
			'view_limits_cb': ['action_toggle_limits', 'show_limits'],
			'view_extents_option_cb': ['action_toggle_extents_option', 'show_extents_option'],
			'view_live_plot_cb': ['action_toggle_live_plot', 'show_live_plot'],
			'view_velocity_cb': ['action_toggle_velocity', 'show_velocity'],
			'view_metric_units_cb': ['action_toggle_metric_units', 'metric_units'],
			'view_program_cb': ['action_toggle_program', 'show_program'],
			'view_rapids_cb': ['action_toggle_rapids', 'show_rapids'],
			'view_tool_cb': ['action_toggle_tool', 'show_tool'],
			'view_lathe_radius_cb': ['action_toggle_lathe_radius', 'show_lathe_radius'],
			'view_dtg_cb': ['action_toggle_dtg', 'show_dtg'],
			'view_offsets_cb': ['action_toggle_offsets', 'show_offsets'],
			'view_overlay_cb': ['action_toggle_overlay', 'show_overlay']
		}

		# if a checkbox is found connect it to the function
		for key, value in view_checkboxes.items():
			if key in parent.child_names:
				getattr(parent, f'{key}').clicked.connect(partial(getattr(actions, f'{value[0]}'), parent))
				if parent.settings.contains(f'PLOT/{key}'):
					state = True if parent.settings.value(f'PLOT/{key}') == 'true' else False
				else: # add it and set to default
					state = getattr(parent.plotter, value[1])
					parent.settings.beginGroup('PLOT')
					parent.settings.setValue(key, state)
					parent.settings.endGroup()
				getattr(parent, key).setChecked(state)
				setattr(parent.plotter, value[1], state)

		view_pushbuttons = {
			'view_dro_pb': ['action_toggle_dro', 'enable_dro'],
			'view_limits_pb': ['action_toggle_limits', 'show_limits'],
			'view_extents_option_pb': ['action_toggle_extents_option', 'show_extents_option'],
			'view_live_plot_pb': ['action_toggle_live_plot', 'show_live_plot'],
			'view_velocity_pb': ['action_toggle_velocity', 'show_velocity'],
			'view_metric_units_pb': ['action_toggle_metric_units', 'metric_units'],
			'view_program_pb': ['action_toggle_program', 'show_program'],
			'view_rapids_pb': ['action_toggle_rapids', 'show_rapids'],
			'view_tool_pb': ['action_toggle_tool', 'show_tool'],
			'view_lathe_radius_pb': ['action_toggle_lathe_radius', 'show_lathe_radius'],
			'view_dtg_pb': ['action_toggle_dtg', 'show_dtg'],
			'view_offsets_pb': ['action_toggle_offsets', 'show_offsets'],
			'view_overlay_pb': ['action_toggle_overlay', 'show_overlay']
		}

		# if a pushbutton is found connect it to the function
		for key, value in view_pushbuttons.items():
			if key in parent.child_names:
				getattr(parent, f'{key}').clicked.connect(partial(getattr(actions, f'{value[0]}'), parent))
				getattr(parent, f'{key}').setCheckable(True)
				if parent.settings.contains(f'PLOT/{key}'):
					state = True if parent.settings.value(f'PLOT/{key}') == 'true' else False
				else: # add it and set to default
					state = getattr(parent.plotter, value[1])
					parent.settings.beginGroup('PLOT')
					parent.settings.setValue(key, state)
					parent.settings.endGroup()
				getattr(parent, key).setChecked(state)
				setattr(parent.plotter, value[1], state)

		if parent.auto_plot_units: # disable metric units
			if 'view_metric_units_cb' in parent.child_names: # verified
				title = 'Configuration Error'
				msg = ('The INI entry PLOT_UNITS = True in the [FLEXGUI] section '
				'disables any metric unit plotter controls.')
				info = 'The "view_metric_units_cb" will be disabled'
				dialogs.error_msg_ok(parent, title, msg, info)
				parent.view_metric_units_cb.setEnabled(False)

				bitch = True
			if 'view_metric_units_pb' in parent.child_names: # verified
				parent.view_metric_units_pb.setEnabled(False)
				title = 'Configuration Error'
				msg = ('The INI entry PLOT_UNITS = True in the [FLEXGUI] section '
				'disables any metric unit plotter controls.')
				info = 'The "view_metric_units_pb" will be disabled'
				dialogs.error_msg_ok(parent, title, msg, info)
				parent.view_metric_units_pb.setEnabled(False)

			if 'actionMetric_Units' in parent.child_names: # verified
				title = 'Configuration Error'
				msg = ('The INI entry PLOT_UNITS = True in the [FLEXGUI] section '
				'disables any metric unit plotter controls.')
				info = 'The "actionMetric_Units" will be disabled'
				dialogs.error_msg_ok(parent, title, msg, info)
				parent.actionMetric_Units.setEnabled(False)

		parent.plotter.update()

		view_controls = {
			'view_rotate_up_pb': ('rotateView', 0, -5),
			'view_rotate_down_pb': ('rotateView', 0, 5),
			'view_rotate_left_pb': ('rotateView', 5, 0),
			'view_rotate_right_pb': ('rotateView', -5, 0),
			'view_pan_up_pb': ('panView', 0, -5),
			'view_pan_down_pb': ('panView', 0, 5),
			'view_pan_left_pb': ('panView', -5, 0),
			'view_pan_right_pb': ('panView', 5, 0),
			'view_zoom_in_pb': ('zoomin',),
			'view_zoom_out_pb': ('zoomout',),
			'view_clear_pb': ('clear_live_plotter',)
		}

		for key, value in view_controls.items():
			if key in parent.child_names:
				button = getattr(parent, key)
				if len(value) == 3:
					method, vertical, horizontal = value
					button.clicked.connect(lambda _, m=method, v=vertical, h=horizontal: (
						getattr(parent.plotter, m)(vertical=v, horizontal=h)
					))
				elif len(value) == 1:
					method = value[0]
					button.clicked.connect(lambda _, m=method: (
						getattr(parent.plotter, m)()
					))

		views = {
			'view_p_pb': 'p',
			'view_x_pb': 'x',
			'view_y_pb': 'y',
			'view_y2_pb': 'y2',
			'view_z_pb': 'z',
			'view_z2_pb': 'z2'
		}

		# this connects the view buttons to the plotter
		for key, value in views.items():
			if key in parent.child_names:
				button = getattr(parent, key)
				button.clicked.connect(lambda _, v=value: (
					parent.plotter.makeCurrent(),
					setattr(parent.plotter, 'current_view', v),
					parent.plotter.set_current_view()
				))

		action_view_controls = {
			'actionView_Zoom_In': 'zoomin',
			'actionView_Zoom_Out': 'zoomout',
			'actionView_Clear': 'clear_live_plotter'
		}

		for key, value in action_view_controls.items():
			if key in parent.child_names:
				action = getattr(parent, key)
				action.triggered.connect(lambda _, m=value: (
					getattr(parent.plotter, m)()))

		# toolbar view actions
		view_actions = {
		'actionView_P': 'p',
		'actionView_X': 'x',
		'actionView_Y': 'y',
		'actionView_Y2': 'y2',
		'actionView_Z': 'z',
		'actionView_Z2': 'z2',
		}

		for key, value in view_actions.items():
			if key in parent.child_names:
				action = getattr(parent, key)
				action.triggered.connect(lambda _, v=value: (
					parent.plotter.makeCurrent(),
					setattr(parent.plotter, 'current_view', v),
					parent.plotter.set_current_view(),
					utilities.sync_toolbuttons(parent, v)
				))

		# Setup GRIDS submenu
		# Set defaults if no INI
		default_grids = "0.5 in, 1 in, 2 in, 3 in, 4 in"\
			if parent.units == "INCH" else "10 mm, 20 mm, 50 mm, 100 mm, 250 mm"

		# Handle both a QMenu and QAction submenus
		menu = parent.findChild(QAction, 'actionGrids') or parent.findChild(QMenu, 'actionGrids')
		if parent.grids and not menu: # verified
			# If an INI setting and no GRIDS menu, show an error
			title = 'Configuration Error'
			msg = (f'The Plottter GRIDS configuration was found in the INI file. '
			'Plotter grids requires a menu selector for grids. '
			'No Grids menu was found to configure.')
			dialogs.error_msg_ok(parent, title, msg)
		elif menu:
			if not isinstance(menu, QMenu):
				# If this action is in a submenu, for example inside "View"
				if menu.menu():
					menu = menu.menu()
				else:
					# Create and attach menu
					new_menu = QMenu(menu.parent())
					menu.setMenu(new_menu)
					menu = new_menu

			default_has_been_set = False 
			grid_settings = (parent.grids or default_grids).split(',')
			for index, item in enumerate(grid_settings):
				item = item.strip()
				text, data, suffix = utilities.is_valid_increment(parent, item)
				if data:
					grid_size = conv_units(data, suffix.lower(), parent.units)
				else: # verified
					title = 'Configuration Error'
					msg = (f'The FLEXGUI PLOT_GRID entry "{item}" is not a '
					'valid unit and will not be used.')
					dialogs.error_msg_ok(parent, title, msg)
					continue

				# If no default has been set by the end, it means the first
				# item in the list is 0.0 or it's not a valid entry and the 'None'
				# option is the default.

				if grid_size: # If we have a valid grid_size and it is not 0.0
					new_action = QAction(text, parent)
					new_action.setData(grid_size)
					new_action.setCheckable(True)
					new_action.triggered.connect(partial(utilities.update_grid_size, parent, grid_size))
					menu.addAction(new_action)
					if index == 0:
						new_action.setChecked(True)
						parent.plotter.grid_size = grid_size
						parent.plotter.update()
						default_has_been_set = True

			current_actions = menu.actions()
			if len(current_actions) > 0:
				new_action = QAction("None", parent)
				new_action.setData(0.0)
				new_action.setCheckable(True)
				new_action.triggered.connect(partial(utilities.update_grid_size, parent, 0.0))
				menu.insertAction(current_actions[0], new_action)
				if not default_has_been_set:
					parent.plotter.grid_size = grid_size
					parent.plotter.update()
					new_action.setChecked(True)

def setup_fsc(parent): # mill feed and speed calculator
	if 'fsc_container' in parent.child_names:
		from libflexgui import fsc
		parent.fsc_calc = fsc.fs_calc(parent)
		layout = QVBoxLayout(parent.fsc_container)
		layout.addWidget(parent.fsc_calc)
		if parent.fsc_container.property('input') == 'number':
			fsc_items = ['fsc_diameter_le', 'fsc_rpm_le', 'fsc_flutes_le', 'fsc_feed_le', 'fsc_chip_load_le']
			for item in fsc_items:
				getattr(parent.fsc_calc, f'{item}').installEventFilter(parent)
				parent.number_le.append(item)

def setup_dsf(parent): # drill speed and feed calculator
	if 'dsf_container' in parent.child_names:
		from libflexgui import dsf
		parent.dsf_calc = dsf.dsf_calc(parent)
		layout = QVBoxLayout(parent.dsf_container)
		layout.addWidget(parent.dsf_calc)
		if parent.dsf_container.property('input') == 'number':
			dsf_items = ['dfs_diameter_le', 'dfs_surface_speed_le']
			for item in dsf_items:
				getattr(parent.dsf_calc, f'{item}').installEventFilter(parent)
				parent.number_le.append(item)

def setup_tpc(parent): # three point center calculator
	if 'tpc_container' in parent.child_names:
		from libflexgui import tpc
		parent.tpc_calc = tpc.tpc_calc(parent)
		layout = QVBoxLayout(parent.tpc_container)
		layout.addWidget(parent.tpc_calc)

def setup_import(parent):
	modules = parent.inifile.findall('FLEXGUI', 'IMPORT_PYTHON') or False
	if modules:
		for module_name in modules:
			_, ext = os.path.splitext(module_name)
			if bool(ext): # verified
				title = 'Configuration Error'
				msg = (f'The INI entry for "IMPORT_PYTHON" "{module_name}" has an '
				'extension. The INI entry is the name only of the python file.')
				info = 'The python module will not be loaded!'
				dialogs.error_msg_ok(parent, title, msg, info)
				continue

			module_path = os.path.join(parent.config_path, f'{module_name}.py')
			if os.path.exists(module_path):
				try:
					sys.path.append(parent.config_path)
					module = importlib.import_module(module_name)
					module.startup(parent)
				except Exception as e: # verified
					print(traceback.format_exc())
					title = 'Import Failed'
					msg = (f'The python file {module_path} has an error in the module '
					'code.\n'
					f'{traceback.format_exc()}')
					info = 'The python module will not be loaded!'
					dialogs.error_msg_ok(parent, title, msg, info)
			else: # verified
				title = 'Import Failed'
				msg = (f'The python file "{module_path}" was not found.\n')
				info = 'The python module will not be loaded!'
				dialogs.error_msg_ok(parent, title, msg, info)

def setup_help(parent):
	children = parent.findChildren(QPushButton)
	for child in children:
		if child.property('function') == 'help':
			child.clicked.connect(partial(dialogs.help_dialog, parent))

def setup_tabs(parent):
	# Pull focus away from other controls (QLineEdits)
	# When a tab is changed.
	for child in parent.findChildren(QTabWidget):
		child.tabBarClicked.connect(parent.setFocus)
