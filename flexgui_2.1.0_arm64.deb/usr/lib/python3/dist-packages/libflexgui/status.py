import math, statistics

from PyQt6.QtGui import QTextCursor
from PyQt6.QtWidgets import QLCDNumber

import linuxcnc as emc
import hal

from libflexgui import utilities
from libflexgui import dialogs

EXEC_STATES = {1: 'EXEC_ERROR', 2: 'EXEC_DONE', 3: 'EXEC_WAITING_FOR_MOTION',
	4: 'EXEC_WAITING_FOR_MOTION_QUEUE', 5: 'EXEC_WAITING_FOR_IO',
	7: 'EXEC_WAITING_FOR_MOTION_AND_IO', 8: 'EXEC_WAITING_FOR_DELAY',
	9: 'EXEC_WAITING_FOR_SYSTEM_CMD', 10: 'EXEC_WAITING_FOR_SPINDLE_ORIENTED', }

INTERP_STATES = {1: 'INTERP_IDLE', 2: 'INTERP_READING', 3: 'INTERP_PAUSED',
	4: 'INTERP_WAITING'}

INTERPRETER_ERRCODES = {0: 'INTERP_OK', 1: 'INTERP_EXIT',
	2: 'INTERP_EXECUTE_FINISH', 3 :'INTERP_ENDFILE', 4 :'INTERP_FILE_NOT_OPEN',
	5 :'INTERP_ERROR'}

MOTION_MODES = {1: 'TRAJ_MODE_FREE', 2: 'TRAJ_MODE_COORD', 3: 'TRAJ_MODE_TELEOP'}

MOTION_TYPES = {0: 'MOTION_TYPE_NONE', 1: 'MOTION_TYPE_TRAVERSE',
	2: 'MOTION_TYPE_FEED', 3: 'MOTION_TYPE_ARC', 4: 'MOTION_TYPE_TOOLCHANGE',
	5: 'MOTION_TYPE_PROBING', 6: 'MOTION_TYPE_INDEXROTARY'}

STATES = {1: 'RCS_DONE', 2: 'RCS_EXEC', 3: 'RCS_ERROR'}

TASK_MODES = {1: 'MODE_MANUAL', 2: 'MODE_AUTO', 3: 'MODE_MDI'}

TASK_STATES = {1: 'STATE_ESTOP', 2: 'STATE_ESTOP_RESET', 3: 'STATE_OFF',
	4: 'STATE_ON'}

# Axes
X = 0
Y = 1
Z = 2
A = 3
B = 4
C = 5
U = 6
V = 7
W = 8
R = 9

def update(parent):
	parent.status.poll()
	changed = False
	print_changes = False

	# **** EXEC STATE ****
	# exec_state EXEC_ERROR, EXEC_DONE, EXEC_WAITING_FOR_MOTION,
	# EXEC_WAITING_FOR_MOTION_QUEUE, EXEC_WAITING_FOR_IO,
	# EXEC_WAITING_FOR_MOTION_AND_IO, EXEC_WAITING_FOR_DELAY,
	# EXEC_WAITING_FOR_SYSTEM_CMD, EXEC_WAITING_FOR_SPINDLE_ORIENTED.
	if parent.exec_state != parent.status.exec_state:
		if print_changes:
			print(f'EXEC STATE: {EXEC_STATES[parent.status.exec_state]}')
			changed = True
		if 'exec_state_lb' in parent.child_names: # update the label
			parent.exec_state_lb.setText(EXEC_STATES[parent.status.exec_state])

		if parent.status.exec_state == emc.EXEC_DONE:
			utilities.update_controls(parent)

		parent.exec_state = parent.status.exec_state

	# **** INTERP STATE ****
	# interp_state INTERP_IDLE, INTERP_READING, INTERP_PAUSED, INTERP_WAITING
	if parent.interp_state != parent.status.interp_state:
		if print_changes:
			print(f'INTERP STATE: {INTERP_STATES[parent.status.interp_state]}')
			changed = True
		if 'interp_state_lb' in parent.child_names: # update the label
			parent.interp_state_lb.setText(INTERP_STATES[parent.status.interp_state])

		utilities.update_controls(parent)

		parent.interp_state = parent.status.interp_state

	# **** INTERPRETER ERRCODE ****
	# interpreter_errcode INTERP_OK INTERP_EXIT INTERP_EXECUTE_FINISH
	# INTERP_ENDFILE INTERP_FILE_NOT_OPEN INTERP_ERROR
	if parent.interpreter_errcode != parent.status.interpreter_errcode:
		if print_changes:
			print(f'INTERPRETER ERRCODE: {INTERPRETER_ERRCODES[parent.status.interpreter_errcode]}')
			changed = True
		if 'interpreter_errcode_lb' in parent.child_names: # update the label
			parent.interpreter_errcode_lb.setText(INTERPRETER_ERRCODES[parent.status.interpreter_errcode])

		parent.interpreter_errcode = parent.status.interpreter_errcode

	# **** MOTION MODE ****
	# motion_mode TRAJ_MODE_COORD, TRAJ_MODE_FREE, TRAJ_MODE_TELEOP
	if parent.motion_mode != parent.status.motion_mode:
		if print_changes:
			print(f'MOTION MODE: {MOTION_MODES[parent.status.motion_mode]}')
			changed = True
		if 'motion_mode_lb' in parent.child_names: # update the label
			parent.motion_mode_lb.setText(MOTION_MODES[parent.status.motion_mode])

		parent.motion_mode = parent.status.motion_mode

	# **** MOTION TYPE ****
	# motion_type MOTION_TYPE_NONE, MOTION_TYPE_TRAVERSE,
	# MOTION_TYPE_FEED, MOTION_TYPE_ARC, MOTION_TYPE_TOOLCHANGE,
	# MOTION_TYPE_PROBING, MOTION_TYPE_INDEXROTARY,
	if parent.motion_type != parent.status.motion_type:
		if print_changes:
			print(f'MOTION TYPE: {MOTION_TYPES[parent.status.motion_type]}')
			changed = True
		if 'motion_type_lb' in parent.child_names: # update the label
			parent.motion_type_lb.setText(MOTION_TYPES[parent.status.motion_type])

		utilities.update_controls(parent)

		parent.motion_type = parent.status.motion_type

	# **** STATE ****
	# state RCS_DONE, RCS_EXEC, RCS_ERROR
	if parent.state != parent.status.state:
		if print_changes:
			print(f'STATE: {STATES[parent.status.state]}')
			changed = True
		if 'state_lb' in parent.child_names: # update the label
			parent.state_lb.setText(STATES[parent.status.state])

		if (parent.status.state == emc.RCS_DONE
			and parent.status.task_mode == emc.MODE_AUTO
			and parent.status.interp_state == emc.INTERP_IDLE):
			parent.command.mode(emc.MODE_MANUAL)

		utilities.update_controls(parent)

		# this is needed for MDI commands that use motion
		if parent.status.state == emc.RCS_DONE:
			if parent.status.task_mode == emc.MODE_MDI:
				utilities.update_mdi(parent)
			parent.command.mode(emc.MODE_MANUAL)

		parent.state = parent.status.state

	# **** TASK MODE ****
	# task_mode MODE_MDI, MODE_AUTO, MODE_MANUAL
	if parent.task_mode != parent.status.task_mode:
		if print_changes:
			print(f'TASK MODE: {TASK_MODES[parent.status.task_mode]}')
			changed = True
		if 'task_mode_lb' in parent.child_names: # update the label
			parent.task_mode_lb.setText(TASK_MODES[parent.status.task_mode])

		if 'run_pb' in parent.child_names and hasattr(parent.run_pb, 'state'):
			if (parent.status.task_mode == emc.MODE_AUTO or
					parent.status.task_mode == emc.MODE_MDI):
				parent.run_pb.state = True
			elif parent.status.task_mode == emc.MODE_MANUAL:
				parent.run_pb.state = False

		# this is needed for MDI commands that do not use motion
		if (parent.status.interp_state == emc.INTERP_IDLE
			and parent.status.task_mode == emc.MODE_MDI):
			parent.command.mode(emc.MODE_MANUAL)
			utilities.update_mdi(parent)

		utilities.update_home_controls(parent)
		utilities.update_controls(parent)

		parent.task_mode = parent.status.task_mode

	# **** TASK STATE ****
	# task_state STATE_ESTOP, STATE_ESTOP_RESET, STATE_ON, STATE_OFF
	if parent.task_state != parent.status.task_state:
		if print_changes:
			print(f'TASK STATE: {TASK_STATES[parent.status.task_state]}')
			changed = True
		if 'task_state_lb' in parent.child_names: # update the label
			parent.task_state_lb.setText(TASK_STATES[parent.status.task_state])

		# estop open
		if parent.status.task_state == emc.STATE_ESTOP:
			#print('status update STATE_ESTOP')
			for key, value in parent.state_estop_names.items():
				getattr(parent, key).setText(value)
			if 'estop_pb' in parent.child_names and hasattr(parent.estop_pb, 'state'):
				parent.estop_pb.state = False
			if 'power_pb' in parent.child_names:
				parent.power_pb.setChecked(False)
				if hasattr(parent.power_pb, 'state'):
					parent.power_pb.state = False

		# estop closed power off
		if parent.status.task_state == emc.STATE_ESTOP_RESET:
			#print('status update STATE_ESTOP_RESET')
			if 'estop_pb' in parent.child_names and hasattr(parent.estop_pb, 'state'):
				parent.estop_pb.state = True

			if 'power_pb' in parent.child_names:
				parent.power_pb.setChecked(False)
				if hasattr(parent.power_pb, 'state'):
					parent.power_pb.state = False
			if 'probing_enable_pb' in parent.child_names:
				parent.probing_enable_pb.setChecked(False)
			for key, value in parent.state_estop_reset_names.items():
				getattr(parent, key).setText(value)

		# estop closed power on
		if parent.status.task_state == emc.STATE_ON:
			#print('status update STATE_ON')
			for key, value in parent.state_on_names.items():
				getattr(parent, key).setText(value)
			if 'power_pb' in parent.child_names and hasattr(parent.power_pb, 'state'):
				parent.power_pb.state = True

		utilities.update_home_controls(parent)
		utilities.update_controls(parent)

		parent.task_state = parent.status.task_state

	# **** FILE CHANGE ****
	if parent.file != parent.status.file:
		utilities.update_controls(parent)

		parent.file = parent.status.file

	# **** HOMED CHANGE ****
	if parent.homed != parent.status.homed:
		utilities.update_home_controls(parent)
		utilities.update_controls(parent)

		parent.homed = parent.status.homed

	# **** MOTION LINE CHANGE ****
	if parent.motion_line != parent.status.motion_line:
		#print(parent.status.motion_line)
		if 'gcode_pte' in parent.child_names: # update the cursor position
			cursor = parent.gcode_pte.textCursor()
			cursor = QTextCursor(parent.gcode_pte.document().findBlockByNumber(parent.motion_line))
			cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock, QTextCursor.MoveMode.MoveAnchor)
			parent.gcode_pte.setTextCursor(cursor)

		parent.motion_line = parent.status.motion_line

	# **** NC CODES CHANGE ****
	if parent.g_codes != parent.status.gcodes:
		g_codes = []
		for i in parent.status.gcodes[1:]:
			if i == -1: continue
			if i % 10 == 0:
				g_codes.append(f'G{(i/10):.0f}')
			else:
				g_codes.append(f'G{(i/10):.0f}.{i%10}')

		if 'gcodes_lb' in parent.child_names:
			parent.gcodes_lb.setText(f'{" ".join(g_codes)}')

		if 'G20' in g_codes:
			parent.program_units = 'IN'
		else:
			parent.program_units = 'MM'
		
		for units_lb_name in parent.program_units_labels:
			getattr(parent, units_lb_name).setText(parent.program_units)

		parent.g_codes = parent.status.gcodes

	# **** M CODES CHANGE ****
	if parent.m_codes != parent.status.mcodes:
		if 'mcodes_lb' in parent.child_names:
			m_codes = []
			for i in parent.status.mcodes[1:]:
				if i == -1: continue
				m_codes.append(f'M{i}')
			parent.mcodes_lb.setText(f'{" ".join(m_codes)}')

		parent.m_codes = parent.status.mcodes

	# **** PROGRAM UNITS CHANGE ****
	if parent.auto_plot_units and parent.program_units != parent.plot_units:
		if parent.program_units == 'IN': # inch program units
			parent.plotter.metric_units = False
		elif parent.program_units == 'MM': # metric program units
			parent.plotter.metric_units = True
		parent.plotter.update()
		parent.plot_units = parent.program_units

	# **** TOOL CHANGE ****
	if parent.manual_tool_change:
		if parent.tool_change != hal.get_value('tool-change.change'):
			if hal.get_value('iocontrol.0.tool-changed'):
				hal.set_p('iocontrol.0.tool-changed','false')
			else:
				dialogs.manual_tool_change(parent)

			parent.tool_change = hal.get_value('tool-change.change')

	# **** TOOL IN SPINDLE CHANGE ****
	if parent.tool_in_spindle != parent.status.tool_in_spindle:
		tool = parent.status.tool_in_spindle
		if 'touchoff_selected_tool_pb' in parent.child_names:
			if tool > 0:
				parent.touchoff_selected_tool_pb.setEnabled(True)
			else:
				parent.touchoff_selected_tool_pb.setEnabled(False)

		parent.tool_in_spindle = parent.status.tool_in_spindle

	# **** FLOOD CHANGE **** 
	if parent.flood_state != parent.status.flood:
		if 'flood_pb' in parent.child_names:
			if parent.status.flood == emc.FLOOD_OFF:
				parent.flood_pb.setChecked(False)
				if hasattr(parent.flood_pb, 'state'):
					parent.flood_pb.state = False
			elif parent.status.flood == emc.FLOOD_ON:
				parent.flood_pb.setChecked(True)
				if hasattr(parent.flood_pb, 'state'):
					parent.flood_pb.state = True

		parent.flood_state = parent.status.flood

	# **** MIST CHANGE	 ****
	if parent.mist_state != parent.status.mist:
		if 'mist_pb' in parent.child_names: 
			if parent.status.mist == emc.MIST_OFF:
				parent.mist_pb.setChecked(False)
				if hasattr(parent.mist_pb, 'state'):
					parent.mist_pb.state = False
			elif parent.status.mist == emc.MIST_ON:
				parent.mist_pb.setChecked(True)
				if hasattr(parent.mist_pb, 'state'):
					parent.mist_pb.state = True

		parent.mist_state = parent.status.mist

	# **** SPINDLE CHANGE ****
	# spindle status
	if parent.status_spindle != parent.status.spindle:

		# spindle speed key is label value is spindle and speed
		for key, value in parent.spindle_speed.items():
			getattr(parent, key).setText(f'{abs(parent.status.spindle[value[0]][value[1]]):.0f}')

		# spindle lcd
		for key, value in parent.status_spindle_lcd.items():
			getattr(parent, key).display(f'{abs(parent.status.spindle[value[0]][value[1]]):.0f}')

		# spindle override enabled key is label value is spindle and speed
		for key, value in parent.spindle_bool.items():
			getattr(parent, key).setText(f'{parent.status.spindle[value[0]][value[1]]}')

		# spindle direction key is label value is spindle and direction
		# forward = 1, reverse = -1, off = 0
		spindle_dir = {-1: 'CCW', 0: 'Off', 1: 'CW'}
		for key, value in parent.spindle_dir.items():
			getattr(parent, key).setText(f'{spindle_dir[parent.status.spindle[value[0]][value[1]]]}')

		# spindle status key is label value is spindle and status item
		spindle_int = {0: 'Off', 1: 'On'}
		for key, value in parent.spindle_int.items():
			getattr(parent, key).setText(f'{spindle_int[parent.status.spindle[value[0]][value[1]]]}')

		# spindle override key is label value is spindle and override
		for key, value in parent.spindle_override.items():
			getattr(parent, key).setText(f'{parent.status.spindle[value[0]][value[1]]:.0%}')

		# spindle commanded speed key is label value is spindle and commanded speed
		for key, value in parent.spindle_cmd_speed.items():
			override = parent.status.spindle[value[0]]['override']
			speed = parent.status.spindle[value[0]]['speed']
			getattr(parent, key).setText(f'{speed * override:.0f}')

		parent.status_spindle = parent.status.spindle

	# **** STATUS LABELS ****
	# key is label and value is status item
	for key, value in parent.status_labels.items(): # update all status labels
		if value in parent.stat_dict:
			stat_value = getattr(parent.status, f'{value}')
			if stat_value in parent.stat_dict[value]:
				getattr(parent, f'{key}').setText(f'{parent.stat_dict[value][stat_value]}')
		else:
			getattr(parent, f'{key}').setText(f'{getattr(parent.status, f"{value}")}')

	# status exponent labels key is the label and value is the status item
	for key, value in parent.status_exponent_labels.items():
		getattr(parent, f'{key}').setText(f'{getattr(parent.status, value):e}')

	# status float labels
	for key, value in parent.status_float_labels.items():
		getattr(parent, f'{key}_lb').setText(f'{getattr(parent.status, key):.{value}f}')

	# joint status items
	for key, value in parent.status_joints.items():
		getattr(parent, f'{key}').setText(f'{getattr(parent, "status").joint[0][value]}')

	# joint status items with precision key is item value is [joint, precision]
	for key, value in parent.status_joint_prec.items():
		getattr(parent, f'joint_{value[0]}_{key}_lb').setText(f'{getattr(parent, "status").joint[value[0]][key]:.{value[1]}f}')

	# update hal average float labels key is label name and value is pin name
	# [pin_name, deque([0], maxlen=samples), p, r]
	for key, value in parent.hal_avr_float.items():
		cur_val = hal.get_value(f'flexhal.{value[0]}')
		value[1].append(cur_val)
		stat = statistics.fmean(value[1])
		rounding = value[3]
		getattr(parent, key).setText(f'{round(stat, rounding):.{value[2]}f}')

	# update hal average int labels key is label name and value is pin name
	# [pin_name, deque([0], maxlen=samples)]
	for key, value in parent.hal_avr_int.items():
		cur_val = hal.get_value(f'flexhal.{value[0]}')
		value[1].append(cur_val)
		stat = statistics.fmean(value[1])
		getattr(parent, key).setText(f'{round(stat)}')

	# update multi state labels
	# key is label name and value[0] is the pin name value[1] is dict int, text
	for key, value in parent.hal_ms_labels.items():
		state = hal.get_value(f'flexhal.{value[0]}')
		if state in value[1].keys():
			getattr(parent, key).setText(f'{value[1][state]}')
		else:
			getattr(parent, key).setText(f'Unknown {state}')

	# update hal bool labels
	# key is label name, value[0] is pin name, value[1] is true text, value[2] is false text
	for key, value in parent.hal_bool_labels.items():
		state = hal.get_value(f'flexhal.{value[0]}')
		if state:
			getattr(parent, key).setText(value[1])
		else:
			getattr(parent, key).setText(value[2])

	# update hal integer labels
	# key is label name, value[0] is pin name, value[1] is zero padding
	for key, value in parent.hal_integer_labels.items():
		hal_value = hal.get_value(f'flexhal.{value[0]}')
		getattr(parent, key).setText(f'{hal_value:0{value[1]}d}')

	# update hal float labels
	# key is label name, value[0] is pin name, value[1] is precision
	for key, value in parent.hal_float_labels.items():
		hal_value = hal.get_value(f'flexhal.{value[0]}')
		getattr(parent, key).setText(f'{hal_value:.{value[1]}f}')

	# update hal float lcds
	# key is lcd name, value[0] is pin name, value[1] is precision
	for key, value in parent.hal_float_lcds.items():
		hal_value = hal.get_value(f'flexhal.{value[0]}')
		getattr(parent, key).display(f'{hal_value:.{value[1]}f}')

	# update hal labels key is label name and value[0] is pin name value[1] is digits
	for key, value in parent.hal_readers.items():
		state = hal.get_value(f'flexhal.{value[0]}')
		if value[1] is not None:
			state = f"{state:0{value[1]}d}"
		if isinstance(getattr(parent, key), QLCDNumber):
			getattr(parent, key).display(f'{state}')
		else: # it's a HAL Label
			getattr(parent, key).setText(f'{state}')

	# update hal progressbars key is the progressbar name and value is the pin name
	for key, value in parent.hal_progressbars.items():
		value = hal.get_value(f'flexhal.{value}')
		getattr(parent, key).setValue(int(value))

	# update hal leds
	for key, value in parent.hal_leds.items():
		getattr(parent, key).state = hal.get_value(f'flexhal.{value}')

	# update hal text led labels
	for key, value in parent.hal_led_text_labels.items():
		getattr(parent, key).state = hal.get_value(f'flexhal.{value}')

	# update hal led labels
	for key, value in parent.hal_led_labels.items():
		getattr(parent, key).state = hal.get_value(f'flexhal.{value}')

	# axis position no offsets
	for key, value in parent.status_position.items(): # key is label value precision
		machine_position = getattr(parent, "status").position[value[0]]
		# metric linear units with inch program units
		if parent.status.linear_units == 1 and parent.program_units == 'IN' and parent.auto_dro_units:
			getattr(parent, f'{key}').setText(f'{machine_position * 0.03937007874015748:.4f}')
		# inch linear units with metric program units
		elif parent.status.linear_units != 1 and parent.program_units == 'MM' and parent.auto_dro_units:
			getattr(parent, f'{key}').setText(f'{machine_position * 25.4:.3f}')
		# linear units and program units are the same
		else:
			getattr(parent, f'{key}').setText(f'{machine_position:.{value[1]}f}')

	positions = parent.status.position
	positions = [(i-j) for i, j in zip(positions, parent.status.tool_offset)]
	positions = [(i-j) for i, j in zip(positions, parent.status.g5x_offset)]
	t = -parent.status.rotation_xy
	t = math.radians(t)
	_x = positions[X]
	_y = positions[Y]
	positions[X] = _x * math.cos(t) - _y * math.sin(t)
	positions[Y] = _x * math.sin(t) + _y * math.cos(t)
	positions = [(i-j) for i, j in zip(positions, parent.status.g92_offset)]

	# label, tuple position & precision
	for key, value in parent.status_dro.items(): # key is label value list position & precision
		position = positions[value[0]]

		# metric linear units with inch program units
		if parent.status.linear_units == 1 and parent.program_units == 'IN' and parent.auto_dro_units:
			getattr(parent, f'{key}').setText(f'{position * 0.03937007874015748:.4f}')
		# inch linear units with metric program units
		elif parent.status.linear_units != 1 and parent.program_units == 'MM' and parent.auto_dro_units:
			getattr(parent, f'{key}').setText(f'{position * 25.4:.3f}')
		# linear units and program units are the same
		else:
			getattr(parent, f'{key}').setText(f'{position:.{value[1]}f}')

	# axis g5x offset
	for key, value in parent.status_g5x_offset.items(): # key is label value tuple position & precision
		getattr(parent, f'{key}').setText(f'{getattr(parent, "status").g5x_offset[value[0]]:.{value[1]}f}')

	# axis g92 offset
	for key, value in parent.status_g92.items(): # key is label value tuple position & precision
		getattr(parent, f'{key}').setText(f'{getattr(parent, "status").g92_offset[value[0]]:.{value[1]}f}')

	# axis DTG
	for key, value in parent.status_dtg.items(): # key is label value tuple position & precision
		getattr(parent, f'{key}').setText(f'{getattr(parent, "status").dtg[value[0]]:.{value[1]}f}')

	# axis s.axis[0]['velocity'] parent.status.axis[0]['velocity']
	for key, value in parent.status_axes.items():
		getattr(parent, f'{key}').setText(f'{getattr(parent, "status").axis[value[0]][value[1]]:.{value[2]}f}')

	# joint velocity parent.status.joint[0]['velocity'] key label value joint precision
	for key, value in parent.joint_vel_sec.items():
		getattr(parent, key).setText(f'{abs(getattr(parent, "status").joint[value[0]]["velocity"]):.{value[1]}f}')
	for key, value in parent.joint_vel_min.items():

		getattr(parent, key).setText(f'{abs(getattr(parent, "status").joint[value[0]]["velocity"]) * 60:.{value[1]}f}')

	# two joint velocity
	for key, value in parent.two_vel.items():
		vel_0 = getattr(parent, 'status').joint[value[0]]['velocity']
		vel_1 = getattr(parent, 'status').joint[value[1]]['velocity']
		vel = math.sqrt((vel_0 * vel_0) + (vel_1 * vel_1))
		getattr(parent, key).setText(f'{vel * 60:.{value[2]}f}')

	# three joint velocity
	for key, value in parent.three_vel.items():
		vel_0 = getattr(parent, 'status').joint[value[0]]['velocity']
		vel_1 = getattr(parent, 'status').joint[value[1]]['velocity']
		vel_2 = getattr(parent, 'status').joint[value[2]]['velocity']
		vel = math.sqrt((vel_0 * vel_0) + (vel_1 * vel_1) + (vel_2 * vel_2))
		getattr(parent, key).setText(f'{vel * 60:.{value[3]}f}')

	# override items label : status item
	for key, value in parent.overrides.items():
		getattr(parent, key).setText(f'{getattr(parent.status, f"{value}") * 100:.0f}%')

	# dio din_0_lb din[0] dout_0_lb dout[0]
	for key, value in parent.status_dio.items():
		state = getattr(parent.status, f"{value[0]}")[value[1]]
		item = f'{value[0]}[{value[1]}]'
		getattr(parent, f'{key}').setText(f'{parent.stat_dict[item][state]}')

	# aio ain_0_lb aout_0_lb aio[0] aout[0]
	for key, value in parent.status_aio.items():
		getattr(parent, f'{key}').setText(f'{getattr(parent.status, f"{value[0]}")[value[1]]:.{value[2]}f}')

	# current tool info
	if parent.current_tool_info != parent.status.tool_table[0]:
		for key, value in parent.current_tool_intergers.items():
			tr = parent.status.tool_table[0]
			getattr(parent, key).setText(f'{getattr(tr, value)}')

		for key, value in parent.current_tool_floats.items():
			tr = parent.status.tool_table[0]
			getattr(parent, key).setText(f'{getattr(tr, value[0]):.{value[1]}f}')

		parent.current_tool_info = parent.status.tool_table[0]

	# HAL Watch Pins
	for key, value in parent.hal_watch_bit.items():
		getattr(parent, key).setText(f'{hal.get_value(value)}')

	for key, value in parent.hal_watch_int.items():
		getattr(parent, key).setText(f'{hal.get_value(value)}')

	for key, value in parent.hal_watch_float.items():
		getattr(parent, key).setText(f'{hal.get_value(value[0]):.{value[1]}f}')

	for key, value in parent.hal_watch_time_hm.items():
		hrs = hal.get_value(value[0])
		mins = hal.get_value(value[1])
		getattr(parent, key).setText(f'{hrs:02}:{mins:02}')

	for key, value in parent.hal_watch_time_hms.items():
		hrs = hal.get_value(value[0])
		mins = hal.get_value(value[1])
		secs = hal.get_value(value[2])
		getattr(parent, key).setText(f'{hrs:02}:{mins:02}:{secs:02}')

	# **** HANDLE ERRORS ****
	error = parent.error.poll()
	if error:
		kind, text = error
		if kind in (emc.NML_ERROR, emc.OPERATOR_ERROR):
			error_type = 'Error'
		else:
			error_type = 'Info'
		if 'override_limits_cb' in parent.child_names:
			if 'limit switch error' in text:
				parent.override_limits_cb.setEnabled(True)
		if error_type == 'Info':
			if 'info_pte' in parent.child_names:
				parent.info_pte.appendPlainText(error_type)
				parent.info_pte.appendPlainText(text)
			elif 'errors_pte' in parent.child_names:
				parent.errors_pte.appendPlainText(error_type)
				parent.errors_pte.appendPlainText(text)
				parent.errors_pte.setFocus()
		elif error_type == 'Error':
			if 'errors_pte' in parent.child_names:
				parent.errors_pte.appendPlainText(error_type)
				parent.errors_pte.appendPlainText(text)
				parent.errors_pte.setFocus()
				if 'statusbar' in parent.child_names:
					parent.statusbar.showMessage('Error', 10000)
			if parent.status.task_mode ==  emc.MODE_MDI:
				utilities.update_mdi(parent)

	if changed:
		print('End of changes\n')
		changed = False

