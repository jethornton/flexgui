import os, subprocess, shutil
from functools import partial

from PyQt6.QtWidgets import QApplication, QFileDialog, QMenu

import linuxcnc as emc

from libflexgui import dialogs
from libflexgui import utilities

def load_file(parent, nc_code_file=None):
	# File load buttons don't pass a file name it has to be read from the property
	load_file_btn = False
	if not nc_code_file: # function called by a file load button
		if parent.sender() is not None:
			if parent.sender().property('function') == 'load_file':
				nc_code_file = parent.sender().property('filename')
				if nc_code_file in ['', None]:
					title = 'Configuration Error'
					msg = ('The property "filename" was not found or it was blank.')
					info = 'Loading aborted!'
					dialogs.error_msg_ok(parent, title, msg, info)

	if '~' in nc_code_file:
		nc_code_file = os.path.expanduser(nc_code_file)
	elif not os.path.isfile(nc_code_file): # try adding the nc code dir path to the file name
		nc_code_file = os.path.join(parent.nc_code_dir, nc_code_file)

	if os.path.isfile(nc_code_file):
		parent.command.program_open(nc_code_file)
		parent.command.wait_complete()

		if 'gcode_pte' in parent.child_names:
			text = open(nc_code_file).read()
			parent.gcode_pte.setPlainText(text)

		if 'file_lb' in parent.child_names:
			base = os.path.basename(nc_code_file)
			parent.file_lb.setText(base)

		# update controls
		for item in parent.file_edit_controls:
			getattr(parent, item).setEnabled(True)

		for item in parent.file_save_controls:
			getattr(parent, item).setEnabled(True)

		if 'start_line_lb' in parent.child_names:
			parent.start_line_lb.setText('0')

		if not load_file_btn: # called by menu or file open button
			# get recent files from settings
			keys = parent.settings.allKeys()
			file_list = []
			for key in keys:
				if key.startswith('recent_files'):
					file_list.append(parent.settings.value(key))
			# if the g code file is in the list remove it
			if nc_code_file in file_list:
				file_list.remove(nc_code_file)
			# insert the g code file at the top of the list
			file_list.insert(0, nc_code_file)
			# trim the list to 10
			file_list = file_list[:10]

			# add files back into settings
			parent.settings.beginGroup('recent_files')
			parent.settings.remove('')
			for i, item in enumerate(file_list):
				parent.settings.setValue(str(i), item)
			parent.settings.endGroup()

			# clear recent menu
			if parent.findChild(QMenu, 'menuRecent'):
				parent.menuRecent.clear()
				# add the recent files from settings
				keys = parent.settings.allKeys()
				for key in keys:
					if key.startswith('recent_files'):
						path = parent.settings.value(key)
						name = os.path.basename(path)
						a = parent.menuRecent.addAction(name)
						a.triggered.connect(partial(load_file, parent, path))

		if 'save_pb' in parent.child_names:
			if hasattr(parent.save_pb, 'state'):
				parent.save_pb.state = False
		if 'save_as_pb' in parent.child_names:
			if hasattr(parent.save_as_pb, 'state'):
				parent.save_as_pb.state = False
		if 'reload_pb' in parent.child_names:
			if hasattr(parent.reload_pb, 'state'):
				parent.reload_pb.state = False

	else:
		title = 'File Missing'
		msg = (f'The file {nc_code_file} was not found.')
		info = 'Loading aborted!'
		dialogs.error_msg_ok(parent, title, msg, info)

def file_selector(parent): # touch screen file selector
	item = parent.file_lw.currentItem().text()

	if item.startswith('/'):
		return
	elif item == 'Open Parent Directory': # move up one directory
		parent.nc_code_dir = os.path.abspath(os.path.join(parent.nc_code_dir, os.pardir))
		utilities.read_dir(parent)
	elif item.endswith('...'): # a subdirectory
		parent.nc_code_dir = os.path.join(parent.nc_code_dir, item.replace(' ...', ''))
		utilities.read_dir(parent)
	else: # must be a file name
		load_file(parent, os.path.join(parent.nc_code_dir, item))

def action_open(parent): # actionOpen
	nc_code_file = utilities.file_chooser(parent, 'Open File', 'open')
	if nc_code_file: load_file(parent, nc_code_file)

def action_edit(parent): # actionEdit
	parent.status.poll
	nc_code_file = parent.status.file

	if parent.editor:
		if shutil.which(parent.editor.lower()) is not None:
			subprocess.Popen([parent.editor, nc_code_file])
		else:
			dialogs.select_editor(parent, nc_code_file)
	else:
		dialogs.select_editor(parent, nc_code_file)

def action_reload(parent): # actionReload
	parent.status.poll()
	nc_code_file = parent.status.file or False
	if nc_code_file:
		parent.command.program_open(nc_code_file)
		if 'plot_widget' in parent.child_names:
			parent.plotter.clear_live_plotter()
			parent.plotter.update()
			parent.plotter.load(nc_code_file)
		if 'gcode_pte' in parent.child_names:
			with open(nc_code_file) as f:
				parent.gcode_pte.setPlainText(f.read())
				parent.file_changed = False

		# This updates the LED
		if 'save_pb' in parent.child_names:
			if hasattr(parent.save_pb, 'state'):
				parent.save_pb.state = False
		if 'save_as_pb' in parent.child_names:
			if hasattr(parent.save_as_pb, 'state'):
				parent.save_as_pb.state = False
		if 'reload_pb' in parent.child_names:
			if hasattr(parent.reload_pb, 'state'):
				parent.reload_pb.state = False

	elif not parent.gcode_pte.document().isEmpty():
		action_save_as(parent)

def action_save(parent): # actionSave requires the QPlainTextEdit gcode_pte
	nc_code_file = parent.status.file or False
	text = parent.gcode_pte.toPlainText()
	nc_code = text.splitlines()
	if nc_code_file:
		with open(nc_code_file, 'w') as f:
			f.writelines(line + "\n" for line in nc_code)
			parent.file_changed = False
	else:
		action_save_as(parent)

	if 'plot_widget' in parent.child_names:
		parent.plotter.clear_live_plotter()
		parent.plotter.update()
		parent.plotter.load(nc_code_file)

		# This updates the LED
	if 'save_pb' in parent.child_names:
		if hasattr(parent.save_pb, 'state'):
			parent.save_pb.state = False
	if 'save_as_pb' in parent.child_names:
		if hasattr(parent.save_as_pb, 'state'):
			parent.save_as_pb.state = False
	if 'reload_pb' in parent.child_names:
		if hasattr(parent.reload_pb, 'state'):
			parent.reload_pb.state = True

def action_save_as(parent): # actionSave_As requires the QPlainTextEdit gcode_pte
	current_nc_code_file = parent.status.file
	if os.path.isdir(os.path.expanduser('~/linuxcnc/nc_files')):
		gcode_dir = os.path.expanduser('~/linuxcnc/nc_files')
	else:
		gcode_dir = os.path.expanduser('~/')
	new_nc_code_file, file_type = QFileDialog.getSaveFileName(None,
	caption="Save As", directory=gcode_dir,
	filter='G code Files (*.ngc *.NGC);;All Files (*)', options=QFileDialog.Option.DontUseNativeDialog,)
	if new_nc_code_file:
		nc_code = parent.gcode_pte.toPlainText()
		with open(new_nc_code_file, 'w', encoding='utf-8') as f:
			f.write(nc_code)
		load_file(parent, new_nc_code_file)
		parent.file_changed = False

def action_edit_tool_table(parent): # actionEdit_Tool_Table
	tool_table_file = os.path.join(parent.config_path, parent.tool_table)
	if os.path.isfile(tool_table_file):
		file_size = os.path.getsize(tool_table_file)
		if file_size == 0:
			title = 'Empty Tool Table!'
			msg = ('Can not edit an empty tool file. The tool file must have at '
			'least one entry with a Tool number and a Pocket number.')
			info = 'Would you like that line added for you?'
			result = dialogs.warn_msg_yes_no(parent, title, msg, info)
			if result:
				with open(tool_table_file, "w") as file:
					file.write(';\nT1 P1 ;Added by Flex GUI\n')
			else:
				return

		args = []
		if parent.tool_editor:
			args.extend(parent.tool_editor.split()[1:])
		else:
			for axis in parent.axis_letters:
				args.append(axis)
			args.append('diam')
		args.append(f'{parent.config_path}/{parent.tool_table}')
		# Start the process (non-blocking)
		# Pass the program name and a list of arguments
		parent.tool_edit_process.start('tooledit', args)

def action_reload_tool_table(parent): # actionReload_Tool_Table
	parent.command.load_tool_table()
	parent.command.wait_complete()
	parent.status.poll()
	tool_in_spindle = parent.status.tool_in_spindle

	if 'tool_change_cb' in parent.child_names:
		parent.tool_change_cb.clear()
		# tool change with description
		if parent.tool_change_cb.property('option') == 'description':
			parent.tool_change_cb.addItem('T0: No Tool in Spindle', 0)
			tools = os.path.join(parent.config_path, parent.tool_table)
			with open(tools, 'r') as t:
				tool_list = t.readlines()
			for line in tool_list:
				if line.find('T') >= 0:
					t = line.find('T')
					p = line.find('P')
					tool = line[t:p].strip()
					desc = line.split(";")[-1]
					number = int(line[t+1:p].strip())
					parent.tool_change_cb.addItem(f'{tool} {desc.strip()}', number)

		elif parent.tool_change_cb.property('prefix') is not None:
			prefix = parent.tool_change_cb.property('prefix')
			tool_len = len(parent.status.tool_table)
			parent.tool_change_cb.addItem(f'{prefix} 0', 0)
			for i in range(1, tool_len):
				tool_id = parent.status.tool_table[i][0]
				parent.tool_change_cb.addItem(f'{prefix} {tool_id}', tool_id)

		else:
			tool_len = len(parent.status.tool_table)
			parent.tool_change_cb.addItem('Tool 0', 0)
			for i in range(1, tool_len):
				tool_id = parent.status.tool_table[i][0]
				parent.tool_change_cb.addItem(f'Tool {tool_id}', tool_id)

		index = parent.tool_change_cb.findData(tool_in_spindle)
		if index > 0:
			parent.tool_change_cb.setCurrentIndex(index)

def action_ladder_editor(parent): # actionLadder_Editor
	p = os.popen("classicladder  &", "w")

def action_quit(parent): # actionQuit
	parent.close()

def action_estop(parent): # actionEstop
	if parent.status.task_state == emc.STATE_ESTOP:
		parent.command.state(emc.STATE_ESTOP_RESET)
		parent.command.wait_complete()
	else:
		parent.command.state(emc.STATE_ESTOP)
		parent.command.wait_complete()

def action_power(parent): # actionPower
	if parent.status.task_state == emc.STATE_ESTOP_RESET:
		if 'override_limits_cb' in parent.child_names:
			if parent.override_limits_cb.isChecked():
				parent.command.override_limits()
		parent.command.state(emc.STATE_ON)
		parent.command.wait_complete()
	else:
		parent.command.state(emc.STATE_OFF)
		parent.command.wait_complete()

def action_run(parent, start=0): # actionRun
	if parent.status.task_state == emc.STATE_ON:
		if parent.status.task_mode != emc.MODE_AUTO:
			parent.command.mode(emc.MODE_AUTO)
			parent.command.wait_complete()
		parent.command.auto(emc.AUTO_RUN, start)
		utilities.update_qcode_pte(parent)

def action_run_from_line(parent): # actionRun_from_Line
	if 'gcode_pte' in parent.child_names:
		cursor = parent.gcode_pte.textCursor()
		selected_block = cursor.blockNumber() # get current block number
		action_run(parent, selected_block)

def action_step(parent): # actionStep
	if parent.status.task_state == emc.STATE_ON:
		if parent.status.task_mode != emc.MODE_AUTO:
			parent.command.mode(emc.MODE_AUTO)
			parent.command.wait_complete()
		parent.command.auto(emc.AUTO_STEP)
		parent.step = True

def action_pause(parent): # actionPause
	if parent.status.task_mode == emc.MODE_AUTO: # program is running
		parent.command.auto(emc.AUTO_PAUSE)

def action_resume(parent): # actionResume
	if parent.status.paused:
		parent.command.auto(emc.AUTO_RESUME)
		parent.step = False

def action_stop(parent): # actionStop
	parent.command.abort()
	parent.stop = True
	parent.step = False

def action_clear_mdi(parent): # actionClear_MDI_History
	parent.mdi_history_lw.clear()
	path = os.path.dirname(parent.status.ini_filename)
	mdi_file = os.path.join(path, 'mdi_history.txt')
	with open(mdi_file, 'w') as f:
		f.write('')

def action_copy_mdi(parent): # actionCopy_MDI
	if parent.mdi_history_lw.count() > 0:
		items = [parent.mdi_history_lw.item(x) for x in range(parent.mdi_history_lw.count())]
		mdi_list = []
		for item in items:
			mdi_list.append(item.text())
		qclip = QApplication.clipboard()
		qclip.setText('\n'.join(mdi_list))
	else:
		title = 'No History'
		msg = ('There is no MDI history to copy.')
		dialogs.error_msg_ok(parent, title, msg)

def action_save_mdi(parent): # actionSave_MDI
	if parent.mdi_history_lw.count() > 0:
		mdi_history_file = os.path.join(parent.config_path, 'mdi_history.txt')
		# Add a newline character to the end of every item
		#history = [parent.mdi_history_lw.item(i).text() + '\n' for i in range(parent.mdi_history_lw.count())]
		#history = [parent.mdi_history_lw.item(i).text() for i in range(parent.mdi_history_lw.count())]
		history = []
		for i in range(parent.mdi_history_lw.count()):
			history.append(parent.mdi_history_lw.item(i).text() + '\n')

		with open(mdi_history_file, 'w') as file:
			file.writelines(history)
	else:
		title = 'No History'
		msg = ('There is no MDI history to save.')
		dialogs.error_msg_ok(parent, title, msg)

def action_toggle_dro(parent):
	if parent.sender().isChecked():
		parent.plotter.enable_dro = True
	else:
		parent.plotter.enable_dro = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_dro_cb':
		utilities.sync_checkboxes(parent, 'view_dro_cb', 'actionDRO')
		utilities.sync_checkboxes(parent, 'view_dro_cb', 'view_dro_pb')
	elif name == 'view_dro_pb':
		utilities.sync_checkboxes(parent, 'view_dro_pb', 'actionDRO')
		utilities.sync_checkboxes(parent, 'view_dro_pb', 'view_dro_cb')
	elif name == 'actionDRO':
		utilities.sync_checkboxes(parent, 'actionDRO', 'view_dro_cb')
		utilities.sync_checkboxes(parent, 'actionDRO', 'view_dro_pb')

def action_toggle_limits(parent):
	if parent.sender().isChecked():
		parent.plotter.show_limits = True
	else:
		parent.plotter.show_limits = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_limits_cb':
		utilities.sync_checkboxes(parent, 'view_limits_cb', 'actionLimits')
		utilities.sync_checkboxes(parent, 'view_limits_cb', 'view_limits_pb')
	elif name == 'view_limits_pb':
		utilities.sync_checkboxes(parent, 'view_limits_pb', 'actionLimits')
		utilities.sync_checkboxes(parent, 'view_limits_pb', 'view_limits_cb')
	elif name == 'actionLimits':
		utilities.sync_checkboxes(parent, 'actionLimits', 'view_limits_cb')
		utilities.sync_checkboxes(parent, 'actionLimits', 'view_limits_pb')

def action_toggle_extents_option(parent):
	if parent.sender().isChecked():
		parent.plotter.show_extents_option = True
	else:
		parent.plotter.show_extents_option = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_extents_option_cb':
		utilities.sync_checkboxes(parent, 'view_extents_option_cb', 'actionExtents_Option')
		utilities.sync_checkboxes(parent, 'view_extents_option_cb', 'view_extents_option_pb')
	elif name == 'view_extents_option_pb':
		utilities.sync_checkboxes(parent, 'view_extents_option_pb', 'actionExtents_Option')
		utilities.sync_checkboxes(parent, 'view_extents_option_pb', 'view_extents_option_cb')
	elif name == 'actionExtents_Option':
		utilities.sync_checkboxes(parent, 'actionExtents_Option', 'view_extents_option_cb')
		utilities.sync_checkboxes(parent, 'actionExtents_Option', 'view_extents_option_pb')

def action_toggle_live_plot(parent):
	if parent.sender().isChecked():
		parent.plotter.show_live_plot = True
	else:
		parent.plotter.show_live_plot = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_live_plot_cb':
		utilities.sync_checkboxes(parent, 'view_live_plot_cb', 'actionLive_Plot')
		utilities.sync_checkboxes(parent, 'view_live_plot_cb', 'view_live_plot_pb')
	elif name == 'view_live_plot_pb':
		utilities.sync_checkboxes(parent, 'view_live_plot_pb', 'actionLive_Plot')
		utilities.sync_checkboxes(parent, 'view_live_plot_pb', 'view_live_plot_cb')
	elif name == 'actionLive_Plot':
		utilities.sync_checkboxes(parent, 'actionLive_Plot', 'view_live_plot_cb')
		utilities.sync_checkboxes(parent, 'actionLive_Plot', 'view_live_plot_pb')

def action_toggle_velocity(parent):
	if parent.sender().isChecked():
		parent.plotter.show_velocity = True
	else:
		parent.plotter.show_velocity = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_velocity_cb':
		utilities.sync_checkboxes(parent, 'view_velocity_cb', 'actionVelocity')
		utilities.sync_checkboxes(parent, 'view_velocity_cb', 'view_velocity_pb')
	elif name == 'view_velocity_pb':
		utilities.sync_checkboxes(parent, 'view_velocity_pb', 'actionVelocity')
		utilities.sync_checkboxes(parent, 'view_velocity_pb', 'view_velocity_cb')
	elif name == 'actionVelocity':
		utilities.sync_checkboxes(parent, 'actionVelocity', 'view_velocity_cb')
		utilities.sync_checkboxes(parent, 'actionVelocity', 'view_velocity_pb')

def action_toggle_metric_units(parent):
	if not parent.auto_plot_units:
		if parent.sender().isChecked():
			parent.plotter.metric_units = True
		else:
			parent.plotter.metric_units = False
		parent.plotter.update()

		name = parent.sender().objectName()
		if name == 'view_metric_units_cb':
			utilities.sync_checkboxes(parent, 'view_metric_units_cb', 'actionMetric_Units')
			utilities.sync_checkboxes(parent, 'view_metric_units_cb', 'view_metric_units_pb')
		elif name == 'view_metric_units_pb':
			utilities.sync_checkboxes(parent, 'view_metric_units_pb', 'actionMetric_Units')
			utilities.sync_checkboxes(parent, 'view_metric_units_pb', 'view_metric_units_cb')
		elif name == 'actionMetric_Units':
			utilities.sync_checkboxes(parent, 'actionMetric_Units', 'view_metric_units_cb')
			utilities.sync_checkboxes(parent, 'actionMetric_Units', 'view_metric_units_pb')

def action_toggle_program(parent):
	if parent.sender().isChecked():
		parent.plotter.show_program = True
	else:
		parent.plotter.show_program = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_program_cb':
		utilities.sync_checkboxes(parent, 'view_program_cb', 'actionProgram')
		utilities.sync_checkboxes(parent, 'view_program_cb', 'view_program_pb')
	elif name == 'view_program_pb':
		utilities.sync_checkboxes(parent, 'view_program_pb', 'actionProgram')
		utilities.sync_checkboxes(parent, 'view_program_pb', 'view_program_cb')
	elif name == 'actionProgram':
		utilities.sync_checkboxes(parent, 'actionProgram', 'view_program_cb')
		utilities.sync_checkboxes(parent, 'actionProgram', 'view_program_pb')

def action_toggle_rapids(parent):
	if parent.sender().isChecked():
		parent.plotter.show_rapids = True
	else:
		parent.plotter.show_rapids = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_rapids_cb':
		utilities.sync_checkboxes(parent, 'view_rapids_cb', 'actionRapids')
		utilities.sync_checkboxes(parent, 'view_rapids_cb', 'view_rapids_pb')
	elif name == 'view_rapids_pb':
		utilities.sync_checkboxes(parent, 'view_rapids_pb', 'actionRapids')
		utilities.sync_checkboxes(parent, 'view_rapids_pb', 'view_rapids_cb')
	elif name == 'actionRapids':
		utilities.sync_checkboxes(parent, 'actionRapids', 'view_rapids_cb')
		utilities.sync_checkboxes(parent, 'actionRapids', 'view_rapids_pb')

def action_toggle_tool(parent):
	if parent.sender().isChecked():
		parent.plotter.show_tool = True
	else:
		parent.plotter.show_tool = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_tool_cb':
		utilities.sync_checkboxes(parent, 'view_tool_cb', 'actionTool')
		utilities.sync_checkboxes(parent, 'view_tool_cb', 'view_tool_pb')
	elif name == 'view_tool_pb':
		utilities.sync_checkboxes(parent, 'view_tool_pb', 'actionTool')
		utilities.sync_checkboxes(parent, 'view_tool_pb', 'view_tool_cb')
	elif name == 'actionTool':
		utilities.sync_checkboxes(parent, 'actionTool', 'view_tool_cb')
		utilities.sync_checkboxes(parent, 'actionTool', 'view_tool_pb')

def action_toggle_lathe_radius(parent):
	if parent.sender().isChecked():
		parent.plotter.show_lathe_radius = True
	else:
		parent.plotter.show_lathe_radius = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_lathe_radius_cb':
		utilities.sync_checkboxes(parent, 'view_lathe_radius_cb', 'actionLathe_Radius')
		utilities.sync_checkboxes(parent, 'view_lathe_radius_cb', 'view_lathe_radius_pb')
	elif name == 'view_lathe_radius_pb':
		utilities.sync_checkboxes(parent, 'view_lathe_radius_pb', 'actionLathe_Radius')
		utilities.sync_checkboxes(parent, 'view_lathe_radius_pb', 'view_lathe_radius_cb')
	elif name == 'actionLathe_Radius':
		utilities.sync_checkboxes(parent, 'actionLathe_Radius', 'view_lathe_radius_cb')
		utilities.sync_checkboxes(parent, 'actionLathe_Radius', 'view_lathe_radius_pb')

def action_toggle_dtg(parent):
	if parent.sender().isChecked():
		parent.plotter.show_dtg = True
	else:
		parent.plotter.show_dtg = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_dtg_cb':
		utilities.sync_checkboxes(parent, 'view_dtg_cb', 'actionDTG')
		utilities.sync_checkboxes(parent, 'view_dtg_cb', 'view_dtg_pb')
	elif name == 'view_dtg_pb':
		utilities.sync_checkboxes(parent, 'view_dtg_pb', 'actionDTG')
		utilities.sync_checkboxes(parent, 'view_dtg_pb', 'view_dtg_cb')
	elif name == 'actionDTG':
		utilities.sync_checkboxes(parent, 'actionDTG', 'view_dtg_cb')
		utilities.sync_checkboxes(parent, 'actionDTG', 'view_dtg_pb')

def action_toggle_offsets(parent):
	if parent.sender().isChecked():
		parent.plotter.show_offsets = True
	else:
		parent.plotter.show_offsets = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_offsets_cb':
		utilities.sync_checkboxes(parent, 'view_offsets_cb', 'actionOffsets')
		utilities.sync_checkboxes(parent, 'view_offsets_cb', 'view_offsets_pb')
	elif name == 'view_offsets_pb':
		utilities.sync_checkboxes(parent, 'view_offsets_pb', 'actionOffsets')
		utilities.sync_checkboxes(parent, 'view_offsets_pb', 'view_offsets_cb')
	elif name == 'actionOffsets':
		utilities.sync_checkboxes(parent, 'actionOffsets', 'view_offsets_cb')
		utilities.sync_checkboxes(parent, 'actionOffsets', 'view_offsets_pb')

def action_toggle_overlay(parent):
	if parent.sender().isChecked():
		parent.plotter.show_overlay = True
	else:
		parent.plotter.show_overlay = False
	parent.plotter.update()

	name = parent.sender().objectName()
	if name == 'view_overlay_cb':
		utilities.sync_checkboxes(parent, 'view_overlay_cb', 'actionOverlay')
		utilities.sync_checkboxes(parent, 'view_overlay_cb', 'view_overlay_pb')
	elif name == 'view_overlay_pb':
		utilities.sync_checkboxes(parent, 'view_overlay_pb', 'actionOverlay')
		utilities.sync_checkboxes(parent, 'view_overlay_pb', 'view_overlay_cb')
	elif name == 'actionOverlay':
		utilities.sync_checkboxes(parent, 'actionOverlay', 'view_overlay_cb')
		utilities.sync_checkboxes(parent, 'actionOverlay', 'view_overlay_pb')

def action_clear_live_plot(parent):
	parent.plotter.clear_live_plotter()

def action_show_hal(parent): # actionShow_HAL
	subprocess.Popen('halshow', cwd=parent.config_path)

def action_hal_meter(parent): # actionHal_Meter
	subprocess.Popen('halmeter', cwd=parent.config_path)

def action_hal_scope(parent): # actionHal_Scope
	subprocess.Popen('halscope', cwd=parent.config_path)

def action_about(parent): # actionAbout
	dialogs.about_dialog(parent)

def action_quick_reference(parent): # actionQuick_Reference
	dialogs.quick_reference_dialog(parent)


