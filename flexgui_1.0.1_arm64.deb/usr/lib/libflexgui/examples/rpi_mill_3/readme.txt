Copy the .ngc files

zero_material_xy.ngc
zero_vise_xy.ngc

to the /user/linuxcnc/nc_files folder for the MDI_COMMAND buttons to work.
the EdgeFinder buttons demonstrate this feature with the saved halshow.preferences file

in the ini [DISPLAY] section choose one of these three GUI:

QSS = rpi_mill_3.qss
QSS = rpi_mill_3_touch.qss
QSS = rpi_mill_3_touch_dark.qss
